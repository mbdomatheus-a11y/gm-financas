import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import {
  AlertTriangle,
  ArrowLeftRight,
  Calculator,
  CheckCircle2,
  ChevronDown,
  CreditCard,
  EllipsisVertical,
  List as ListIcon,
  Pencil,
  Plus,
  Search,
  Trash2,
  TrendingDown,
  X,
  Receipt,
  RotateCcw,
} from "lucide-react";
import { FaturaMesDialog } from "@/components/FaturaMesDialog";
import { IndiceReajusteField } from "@/components/IndiceReajusteField";
import { toast } from "sonner";
import { excluirDespesaSerie } from "@/lib/exclusao-recorrente";
import { vencimentoDaFatura } from "@/lib/fatura-ciclo";
import { ExcluirRecorrenteDialog } from "@/components/ExcluirRecorrenteDialog";
import { z } from "zod";

import { Checkbox } from "@/components/ui/checkbox";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { correspondeBuscaComValor } from "@/lib/busca";
import { PrimeiraCategoriaGuia } from "@/components/PrimeiraCategoriaGuia";
import { AppLayout } from "@/components/AppLayout";
import { BarraSoma, useSelecaoSoma } from "@/components/BarraSoma";
import { usePersistedState } from "@/hooks/usePersistedState";
import { usePrivacidadeValores } from "@/hooks/usePrivacidadeValores";
import { Field } from "@/routes/_authenticated/receitas";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import {
  RESPONSAVEIS_EXTRA,
  useBancos,
  useCartoes,
  useCategorias,
  useDespesas,
  useReceitas,
  useFaturasMes,
  useProfilesList,
} from "@/hooks/useFinance";
import { lembrarClassificacao } from "@/lib/classificacao-lembrada";
import { SelectBusca } from "@/components/SelectBusca";
import { NavegadorMes } from "@/components/NavegadorMes";
import { usePermissoes, useSession } from "@/hooks/useAuthData";
import {
  competenciaDe,
  lancamentosPorCompetencias,
  PERIODICIDADES,
  projetarCompetencias,
  somarMeses,
  type Periodicidade,
  type RecorrenciaFixa,
} from "@/lib/recorrencia";
import { useCotacao } from "@/hooks/useCotacao";
import {
  addMonths,
  dividirParcelas,
  formatBRL,
  formatDate,
  formatUSD,
  identificacaoDespesa,
  monthKey,
  monthLabelLong,
  parseDate,
  toBRL,
  toISODate,
} from "@/lib/format";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/despesas")({
  validateSearch: (
    s: Record<string, unknown>,
  ): {
    cartao?: string;
    modo?: "lista" | "cartao";
    mes?: string;
    economia?: boolean;
    novo?: boolean;
    busca?: string;
  } => ({
    ...(s["novo"] === true || s["novo"] === "true" || s["novo"] === 1 ? { novo: true } : {}),
    ...(typeof s["cartao"] === "string" && s["cartao"] ? { cartao: s["cartao"] } : {}),
    ...(s["modo"] === "cartao" || s["modo"] === "lista" ? { modo: s["modo"] } : {}),
    ...(typeof s["mes"] === "string" && s["mes"] ? { mes: s["mes"] } : {}),
    // Bloco 3 (plano-mega-2026-09-14.md): o card "Economia Conquistada" da
    // Início usa isso pra levar direto aos lançamentos que geraram a economia.
    ...(s["economia"] === true ? { economia: true } : {}),
    // "Quero cancelar" em /para-onde-vai abre esta tela já filtrando o gasto.
    ...(typeof s["busca"] === "string" && s["busca"] ? { busca: s["busca"] } : {}),
  }),
  head: () => ({
    meta: [
      { title: "Despesas — Control ALL" },
      {
        name: "description",
        content:
          "Despesas fixas e variáveis com parcelamento automático, alerta de duplicidade e controle de parcelas pagas.",
      },
      { property: "og:title", content: "Despesas — Control ALL" },
      {
        property: "og:description",
        content: "Controle de despesas fixas, variáveis e parcelamentos do casal.",
      },
    ],
  }),
  component: DespesasPage,
});

const schema = z.object({
  descricao: z.string().trim().min(2, "Descrição obrigatória").max(120),
  valor_total: z.number().positive("Valor deve ser maior que zero"),
  moeda: z.enum(["BRL", "USD"]),
  categoria: z.string().min(1, "Selecione a categoria"),
  tipo: z.enum(["fixa", "variavel"]),
  data_compra: z.string().min(10, "Informe a data"),
  total_parcelas: z.number().int().min(1, "Número de parcelas obrigatório (mínimo 1)"),
  data_primeira_parcela: z.string().min(10, "Informe a data da 1ª parcela"),
  responsavel: z.string().min(1, "Informe o responsável"),
  observacoes: z.string().max(500).nullable(),
  economia_conquistada: z.boolean(),
});

function novoForm(tipo: "fixa" | "variavel") {
  return {
    descricao: "",
    valor_total: "",
    moeda: "BRL",
    categoria: "",
    tipo,
    data_compra: toISODate(new Date()),
    pagamento: "",
    total_parcelas: "1",
    parcela_atual: "1",
    data_primeira_parcela: toISODate(new Date()),
    responsavel: "",
    observacoes: "",
    economia_conquistada: false,
    recorrencia_duracao: "sem_prazo",
    recorrencia_meses: "12",
    reajuste_tipo: "nenhum",
    reajuste_percentual: "",
    reajuste_periodicidade: "anual",
    reajuste_indice: "",
    reajuste_inicio: "",
  };
}

/** Horizonte de competências geradas para uma despesa fixa sem prazo. */
const HORIZONTE_SEM_PRAZO = 36;

function DespesasPage() {
  const qc = useQueryClient();
  const cotacao = useCotacao();
  const { user } = useSession();
  const { can } = usePermissoes();
  const { data: despesas = [] } = useDespesas();
  const { data: receitas = [] } = useReceitas();
  const { data: faturasMes = [] } = useFaturasMes();
  const { data: categorias = [] } = useCategorias("despesa");
  const { data: cartoes = [] } = useCartoes();
  const { data: bancos = [] } = useBancos();
  const { data: perfis = [] } = useProfilesList();
  const { formatar } = usePrivacidadeValores();

  const search = Route.useSearch();
  const navigate = Route.useNavigate();

  // Item 3 (backlog 2026-09-27): aba e filtros de categoria/banco/responsável
  // são lembrados por sessão (localStorage) e restaurados quando o usuário
  // volta pra tela. `filtroMes` e `modoLista` ficam de fora de propósito —
  // eles já têm sua própria lógica de default (mês atual / `?mes=`/`?modo=`
  // vindos de outras telas, ex. o card "Dívida total" do dashboard), e
  // persistir por localStorage entraria em conflito com esse comportamento.
  const [tab, setTab] = usePersistedState<"total" | "fixa" | "variavel">("despesas.tab", "total");
  const [open, setOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  // Bloco 6 (plano-mega 2026-09-14): simulação visual de corte em despesas
  // fixas — desmarcar itens aqui só recalcula o total exibido na hora,
  // nunca grava nada no banco. Estado local, puro "e se", reseta ao trocar
  // de aba/mês ou sair da tela.
  const [simulandoCortes, setSimulandoCortes] = useState(false);
  // Item 2 (2026-10-05): modo "Somar itens" (marcar lançamentos e ver a soma na hora).
  const soma = useSelecaoSoma();
  const [idsExcluidosSimulacao, setIdsExcluidosSimulacao] = useState<Set<string>>(new Set());
  const [form, setForm] = useState<any>(novoForm("fixa"));
  const [duplicata, setDuplicata] = useState<any | null>(null);
  const [busca, setBusca] = useState(search.busca ?? "");
  // `mes=todos` na URL (ex.: vindo do card "Dívida total em aberto" do
  // dashboard) abre a página já mostrando a dívida completa, não só a do
  // mês atual.
  const [filtroMes, setFiltroMes] = useState(search.mes ?? monthKey(new Date()));
  const [filtroBanco, setFiltroBanco] = usePersistedState("despesas.filtroBanco", "todos");
  const [filtroCategoria, setFiltroCategoria] = usePersistedState(
    "despesas.filtroCategoria",
    "todos",
  );
  const [filtroResponsavel, setFiltroResponsavel] = usePersistedState(
    "despesas.filtroResponsavel",
    "todos",
  );
  /** Item 3 (plano de 2026-10-02, Frente 3): distinguir lançamentos diretos
   * (avulsos, inclui os feitos por IA) dos vindos de fatura/importação,
   * usando o campo `origem` que já existe em `despesas` — nenhuma coluna
   * nova. */
  const [filtroOrigem, setFiltroOrigem] = usePersistedState("despesas.filtroOrigem", "todos");
  const [filtroEconomia, setFiltroEconomia] = useState(search.economia ?? false);
  // `modo=cartao` na URL (ex.: vindo do card "Parcelas mensalizadas" do
  // dashboard) abre a página já na visão "Por cartão".
  // 2026-10-10: a visão por cartão é o padrão e a escolha do usuário fica
  // guardada. O estado é SEMPRE o salvo — um `?modo=` vindo de outra tela só
  // o ajusta uma vez, ao abrir, e some da URL em seguida. Antes o `?modo=`
  // ficava mandando o tempo todo: clicar na aba não trocava nada e a
  // preferência parecia não salvar.
  const [modoLista, setModoLista] = usePersistedState<"lista" | "cartao">(
    "despesas.modoLista",
    "cartao",
  );
  const modoDaUrl = search.modo;
  useEffect(() => {
    if (!modoDaUrl) return;
    setModoLista(modoDaUrl);
    void navigate({
      search: (atual: Record<string, unknown>) => {
        const { modo: _modo, ...resto } = atual;
        return resto;
      },
      replace: true,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [modoDaUrl]);
  const [expandida, setExpandida] = useState<string | null>(null);
  const [grupoExpandido, setGrupoExpandido] = useState<string | null>(null);
  const [filtroResumo, setFiltroResumo] = useState<null | "pago" | "aberto" | "proximo">(null);

  const filtroCartao = search.cartao ?? "todos";
  const setFiltroCartao = (v: string) =>
    navigate({
      search: (s: any) => ({ ...s, cartao: v === "todos" ? undefined : v }),
      replace: true,
    });

  const responsaveis = [...perfis.map((p: any) => p.nome), RESPONSAVEIS_EXTRA];

  const valorDigitado = Number(String(form.valor_total).replace(",", ".")) || 0;
  const parcelasInformadas = Math.max(1, Number(form.total_parcelas) || 1);
  const ehFixa = form.tipo === "fixa";
  const semPrazo = ehFixa && form.recorrencia_duracao === "sem_prazo";
  const mesesPrazo = Math.max(1, Number(form.recorrencia_meses) || 1);
  const percentualReajuste = Number(String(form.reajuste_percentual).replace(",", ".")) || 0;

  /** Recorrência configurada no formulário (somente para despesas fixas). */
  const recorrencia: RecorrenciaFixa | null = ehFixa
    ? {
        valor: valorDigitado,
        inicio: form.data_primeira_parcela || form.data_compra,
        semPrazo,
        meses: semPrazo ? null : mesesPrazo,
        reajuste:
          form.reajuste_tipo === "composto" && percentualReajuste !== 0
            ? {
                percentual: percentualReajuste,
                periodicidade: form.reajuste_periodicidade as Periodicidade,
                inicio: form.reajuste_inicio || null,
                indice: form.reajuste_indice || null,
              }
            : null,
      }
    : null;

  /** Competências geradas para a recorrência (horizonte limitado quando sem prazo). */
  const projecao = useMemo(() => {
    if (!recorrencia || valorDigitado <= 0 || !recorrencia.inicio) return [];
    const inicio = competenciaDe(recorrencia.inicio);
    const qtd = recorrencia.semPrazo ? HORIZONTE_SEM_PRAZO : (recorrencia.meses ?? 1);
    return projetarCompetencias(recorrencia, inicio, somarMeses(inicio, qtd - 1));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    valorDigitado,
    ehFixa,
    semPrazo,
    mesesPrazo,
    form.data_primeira_parcela,
    form.data_compra,
    form.reajuste_tipo,
    percentualReajuste,
    form.reajuste_periodicidade,
    form.reajuste_inicio,
  ]);

  const nParcelas = ehFixa ? Math.max(1, projecao.length) : parcelasInformadas;
  // Fixa: o valor gravado é o valor mensal. Variável: valor da parcela x parcelas.
  const valorNum = ehFixa ? valorDigitado : Number((valorDigitado * nParcelas).toFixed(2));
  const previewParcela = valorDigitado;
  const ultimaCompetencia = projecao.at(-1);

  const possivelDuplicata = useMemo(() => {
    if (editId) return null;
    if (!form.descricao && !valorNum) return null;
    const [tipoPg, idPg] = String(form.pagamento).split(":");
    return (
      despesas.find((d: any) => {
        const mesmaDescricao =
          d.descricao.trim().toLowerCase() === String(form.descricao).trim().toLowerCase();
        const valorProximo = Math.abs(Number(d.valor_total) - valorNum) <= valorNum * 0.02;
        const diffDias =
          Math.abs(parseDate(d.data_compra).getTime() - parseDate(form.data_compra).getTime()) /
          86400000;
        const mesmoPagamento =
          (tipoPg === "cartao" && d.cartao_id === idPg) ||
          (tipoPg === "banco" && d.banco_id === idPg);
        return (mesmaDescricao || valorProximo) && diffDias <= 3 && (mesmoPagamento || !idPg);
      }) ?? null
    );
  }, [despesas, editId, form.descricao, form.data_compra, form.pagamento, valorNum]);

  useEffect(() => {
    if (!search.novo) return;
    setEditId(null);
    setForm(novoForm(tab === "total" ? "variavel" : tab));
    setOpen(true);
    void navigate({
      search: (p: Record<string, unknown>) => {
        const { novo: _n, ...resto } = p;
        return resto as never;
      },
      replace: true,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search.novo]);

  function abrirNova() {
    setEditId(null);
    setForm(novoForm(tab === "total" ? "variavel" : tab));
    setDuplicata(null);
    setOpen(true);
  }

  function abrirEdicao(d: any) {
    if (!can("despesas", "editar")) return;
    setEditId(d.id);
    setDuplicata(null);
    const n = Math.max(1, Number(d.total_parcelas) || 1);
    const fixa = (d.tipo ?? "fixa") === "fixa";
    // Fixa nova já grava o valor mensal; registros antigos guardavam o total.
    const mensal = d.recorrencia_inicio
      ? Number(d.valor_total ?? 0)
      : Number((Number(d.valor_total ?? 0) / n).toFixed(2));
    setForm({
      ...novoForm(d.tipo ?? "fixa"),
      descricao: d.descricao ?? "",
      valor_total: String(fixa ? mensal : Number((Number(d.valor_total ?? 0) / n).toFixed(2))),
      moeda: d.moeda ?? "BRL",
      categoria: d.categoria ?? "",
      tipo: d.tipo ?? "fixa",
      data_compra: d.data_compra,
      pagamento: d.cartao_id ? `cartao:${d.cartao_id}` : d.banco_id ? `banco:${d.banco_id}` : "",
      total_parcelas: fixa ? "1" : String(n),
      data_primeira_parcela: d.recorrencia_inicio ?? d.data_primeira_parcela,
      responsavel: d.responsavel ?? "",
      observacoes: d.observacoes ?? "",
      economia_conquistada: !!d.economia_conquistada,
      recorrencia_duracao: d.recorrencia_meses ? "prazo" : "sem_prazo",
      recorrencia_meses: String(d.recorrencia_meses ?? 12),
      reajuste_tipo: d.reajuste_percentual ? "composto" : "nenhum",
      reajuste_percentual: d.reajuste_percentual ? String(d.reajuste_percentual) : "",
      reajuste_periodicidade: d.reajuste_periodicidade ?? "anual",
      reajuste_indice: d.reajuste_indice ?? "",
      reajuste_inicio: d.reajuste_inicio ?? "",
    });

    setOpen(true);
  }

  const salvar = useMutation({
    mutationFn: async () => {
      const parsed = schema.parse({
        descricao: form.descricao,
        valor_total: valorNum,
        moeda: form.moeda,
        categoria: form.categoria,
        tipo: form.tipo,
        data_compra: form.data_compra,
        total_parcelas: nParcelas,
        data_primeira_parcela: form.data_primeira_parcela,
        responsavel: form.responsavel,
        observacoes: form.observacoes || null,
        economia_conquistada: !!form.economia_conquistada,
      });
      const [tipoPg, idPg] = String(form.pagamento).split(":");
      const vinculos = {
        cartao_id: tipoPg === "cartao" ? (idPg ?? null) : null,
        banco_id: tipoPg === "banco" ? (idPg ?? null) : null,
        recorrencia_inicio: ehFixa ? parsed.data_primeira_parcela : null,
        recorrencia_sem_prazo: ehFixa ? semPrazo : false,
        recorrencia_meses: ehFixa && !semPrazo ? mesesPrazo : null,
        reajuste_percentual: recorrencia?.reajuste?.percentual ?? null,
        reajuste_periodicidade: recorrencia?.reajuste?.periodicidade ?? null,
        reajuste_indice: recorrencia?.reajuste?.indice ?? null,
        reajuste_inicio: recorrencia?.reajuste?.inicio ?? null,
      };

      let despesaId = editId;
      if (editId) {
        const { error } = await supabase
          .from("despesas")
          .update({ ...parsed, ...vinculos })
          .eq("id", editId);
        if (error) throw error;
      } else {
        const { data: despesa, error } = await supabase
          .from("despesas")
          .insert({ ...parsed, ...vinculos, created_by: user?.id ?? null })
          .select()
          .single();
        if (error) throw error;
        despesaId = despesa.id;
      }

      const antigas = editId
        ? ((despesas.find((d: any) => d.id === editId)?.parcelas ?? []) as any[])
        : [];
      const pagasPorNumero = new Set<number>(
        antigas.filter((p: any) => p.paga).map((p: any) => p.numero),
      );
      // Na recorrência o pagamento pertence à competência, não ao número da parcela.
      const pagasPorCompetencia = new Map<string, string | null>(
        antigas
          .filter((p: any) => p.paga)
          .map((p: any) => [competenciaDe(p.vencimento), p.data_pagamento ?? null]),
      );
      if (editId) {
        const { error } = await supabase.from("parcelas").delete().eq("despesa_id", editId);
        if (error) throw error;
      }

      const parcelasPagasInformadas = Math.max(1, Number(form.parcela_atual) || 1);
      const dataInformada = parseDate(parsed.data_primeira_parcela);
      // Compra de cartão cai na fatura do ciclo (fechamento e vencimento do cadastro).
      const cartaoDaCompra = !ehFixa && tipoPg === "cartao" ? cartoes.find((c: any) => c.id === idPg) : undefined;
      const dataNaFatura =
        cartaoDaCompra?.dia_vencimento
          ? parseDate(
              vencimentoDaFatura(toISODate(dataInformada), {
                diaFechamento: cartaoDaCompra.dia_fechamento ?? null,
                diaVencimento: cartaoDaCompra.dia_vencimento,
              }),
            )
          : dataInformada;
      const base =
        !ehFixa && parsed.total_parcelas > 1 && parcelasPagasInformadas > 1
          ? addMonths(dataNaFatura, 1 - parcelasPagasInformadas)
          : dataNaFatura;

      const parcelas = ehFixa
        ? projecao.map((c, i) => ({
            despesa_id: despesaId!,
            numero: i + 1,
            total: projecao.length,
            valor: c.valor,
            moeda: parsed.moeda,
            vencimento: toISODate(addMonths(base, i)),
            paga: pagasPorCompetencia.has(c.competencia),
            data_pagamento: pagasPorCompetencia.get(c.competencia) ?? null,
          }))
        : dividirParcelas(parsed.valor_total, parsed.total_parcelas).map((valor, i) => {
            const numero = i + 1;
            const jaPaga =
              pagasPorNumero.has(numero) || (!editId && numero <= parcelasPagasInformadas);
            return {
              despesa_id: despesaId!,
              numero,
              total: parsed.total_parcelas,
              valor,
              moeda: parsed.moeda,
              vencimento: toISODate(addMonths(base, i)),
              paga: jaPaga,
              data_pagamento: jaPaga ? toISODate(addMonths(base, i)) : null,
            };
          });
      const { error: e2 } = await supabase.from("parcelas").insert(parcelas);
      if (e2) throw e2;
      // Guarda esta classificação para o mesmo estabelecimento: a próxima
      // importação (e a reimportação da mesma fatura) já vem com a categoria e
      // o tipo que você escolheu aqui, sem precisar corrigir de novo.
      await lembrarClassificacao({
        descricao: parsed.descricao,
        categoria: parsed.categoria,
        subcategoria: (parsed as { subcategoria?: string | null }).subcategoria ?? null,
        tipo: parsed.tipo,
        userId: user?.id ?? null,
      });
    },
    onSuccess: () => {
      toast.success(editId ? "Despesa atualizada" : "Despesa cadastrada com parcelas geradas");
      setOpen(false);
      setEditId(null);
      setDuplicata(null);
      setForm(novoForm(tab === "total" ? "variavel" : tab));
      qc.invalidateQueries();
    },
    onError: (e: any) => toast.error(e?.errors?.[0]?.message ?? e.message ?? "Erro ao salvar"),
  });

  const togglePaga = useMutation({
    mutationFn: async ({ id, paga }: { id: string; paga: boolean }) => {
      const { error } = await supabase
        .from("parcelas")
        .update({ paga, data_pagamento: paga ? toISODate(new Date()) : null })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries(),
  });

  const [despesaParaExcluir, setDespesaParaExcluir] = useState<any | null>(null);
  const [despesaFixaParaExcluir, setDespesaFixaParaExcluir] = useState<any | null>(null);
  const competenciaFiltrada = filtroMes !== "todos" ? filtroMes : monthKey(new Date());

  async function executarExclusaoComUndo(d: any) {
    const faturaVinculada = (faturasMes as any[]).find((f) => f.despesa_avulsa_id === d.id);
    const backupDespesa = { ...d };
    const backupParcelas = [...(d.parcelas ?? [])];
    const backupFatura = faturaVinculada ? { ...faturaVinculada } : null;

    const { error } = await supabase.from("despesas").delete().eq("id", d.id);
    if (error) {
      toast.error(error.message);
      return;
    }
    if (faturaVinculada) {
      await supabase
        .from("fatura_mes")
        .update({ despesa_avulsa_id: null, modo_calculo: "inclui_parcelas" })
        .eq("id", faturaVinculada.id);
    }
    qc.invalidateQueries();

    toast.success("Despesa excluída", {
      action: {
        label: "Desfazer",
        onClick: async () => {
          try {
            const { error: insErr } = await supabase.from("despesas").insert({
              id: backupDespesa.id,
              descricao: backupDespesa.descricao,
              valor_total: backupDespesa.valor_total,
              moeda: backupDespesa.moeda,
              categoria: backupDespesa.categoria,
              tipo: backupDespesa.tipo,
              data_compra: backupDespesa.data_compra,
              total_parcelas: backupDespesa.total_parcelas,
              data_primeira_parcela: backupDespesa.data_primeira_parcela,
              cartao_id: backupDespesa.cartao_id,
              banco_id: backupDespesa.banco_id,
              banco_nome: backupDespesa.banco_nome,
              cartao_final: backupDespesa.cartao_final,
              direcao: backupDespesa.direcao,
              origem: backupDespesa.origem,
              created_by: backupDespesa.created_by,
            });
            if (insErr) throw insErr;
            if (backupParcelas.length > 0) {
              await supabase.from("parcelas").insert(
                backupParcelas.map((p: any) => ({
                  id: p.id,
                  despesa_id: backupDespesa.id,
                  numero: p.numero,
                  total: p.total,
                  valor: p.valor,
                  moeda: p.moeda,
                  vencimento: p.vencimento,
                  paga: p.paga,
                  origem: p.origem,
                })),
              );
            }
            if (backupFatura) {
              await supabase
                .from("fatura_mes")
                .update({
                  despesa_avulsa_id: backupFatura.despesa_avulsa_id,
                  modo_calculo: backupFatura.modo_calculo,
                })
                .eq("id", backupFatura.id);
            }
            qc.invalidateQueries();
            toast.success("Exclusão desfeita com sucesso.");
          } catch (err: any) {
            toast.error("Não foi possível desfazer a exclusão: " + (err.message ?? ""));
          }
        },
      },
    });
  }

  const moverTipo = useMutation({
    mutationFn: async ({ id, tipo }: { id: string; tipo: "fixa" | "variavel" }) => {
      const { error } = await supabase.from("despesas").update({ tipo }).eq("id", id);
      if (error) throw error;
      return tipo;
    },
    onSuccess: (tipo) => {
      toast.success(`Despesa movida para ${tipo === "fixa" ? "fixas" : "variáveis"}`);
      qc.invalidateQueries();
    },
    onError: (e: any) => toast.error(e.message ?? "Não foi possível mover"),
  });

  /** Marca/desmarca em lote todas as parcelas de um conjunto de despesas na competência filtrada
   * (usado tanto para "marcar fatura importada como paga" quanto para lançamentos fixos/variáveis). */
  const marcarLote = useMutation({
    mutationFn: async ({ ids, paga }: { ids: string[]; paga: boolean }) => {
      if (ids.length === 0) return;
      const { error } = await supabase
        .from("parcelas")
        .update({ paga, data_pagamento: paga ? toISODate(new Date()) : null })
        .in("id", ids);
      if (error) throw error;
    },
    onSuccess: (_data, vars) => {
      toast.success(
        vars.paga
          ? `${vars.ids.length} lançamento(s) marcado(s) como pago(s)`
          : `${vars.ids.length} lançamento(s) marcado(s) como em aberto`,
      );
      qc.invalidateQueries();
    },
    onError: (e: any) => toast.error(e.message ?? "Não foi possível atualizar os lançamentos"),
  });

  const marcarParcelaPaga = useMutation({
    mutationFn: async ({ id, paga }: { id: string; paga: boolean }) => {
      const { error } = await supabase
        .from("parcelas")
        .update({ paga, data_pagamento: paga ? toISODate(new Date()) : null })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: (_, vars) => {
      toast.success(
        vars.paga ? "Lançamento marcado como pago" : "Lançamento marcado como em aberto",
      );
      qc.invalidateQueries();
    },
    onError: (e: any) => toast.error(e.message ?? "Não foi possível atualizar o lançamento"),
  });

  /** Ids reais de parcela (ignora ocorrências projetadas sem linha no banco ainda) das despesas
   * informadas, na competência filtrada, filtrando por status atual de pagamento. */
  function idsDoLote(despesasDoGrupo: any[], statusAlvo: "abertas" | "pagas"): string[] {
    if (filtroMes === "todos") return [];
    const ids: string[] = [];
    for (const d of despesasDoGrupo) {
      const parcelasDoMes = lancamentosDoFiltro.filter((p) => p.despesa_id === d.id);
      for (const p of parcelasDoMes) {
        if (p.projetada) continue;
        if (statusAlvo === "abertas" && p.paga) continue;
        if (statusAlvo === "pagas" && !p.paga) continue;
        ids.push(String(p.id));
      }
    }
    return ids;
  }

  function tentarSalvar() {
    if (possivelDuplicata && !duplicata) {
      setDuplicata(possivelDuplicata);
      return;
    }
    salvar.mutate();
  }

  const meses = useMemo(() => {
    const now = new Date();
    return Array.from({ length: 61 }, (_, i) =>
      monthKey(new Date(now.getFullYear(), now.getMonth() + 36 - i, 1)),
    );
  }, []);

  const lancamentosDoFiltro = useMemo(
    () => (filtroMes === "todos" ? [] : lancamentosPorCompetencias(despesas as any[], [filtroMes])),
    [despesas, filtroMes],
  );
  const lancamentoPorDespesa = useMemo(
    () => new Map(lancamentosDoFiltro.map((p) => [p.despesa_id, p])),
    [lancamentosDoFiltro],
  );

  const formaKey = (d: any) => (d.cartao_id ? `cartao:${d.cartao_id}` : "sem");
  const primeiroNome = (nome?: string | null) =>
    nome?.trim().split(/\s+/)[0] || "Titular não informado";

  function valorVisivel(d: any): number {
    if (filtroMes === "todos") return Number(d.valor_total ?? 0);
    return Number(lancamentoPorDespesa.get(d.id)?.valor ?? 0);
  }

  const lista = despesas.filter((d: any) => {
    if (tab !== "total" && d.tipo !== tab) return false;
    if (filtroMes !== "todos" && !lancamentoPorDespesa.has(d.id)) return false;
    if (filtroCartao !== "todos") {
      if (filtroCartao === "recorrente_fora") {
        if (d.cartao_id || (d.tipo !== "fixa" && d.tipo !== "recorrente")) return false;
      } else if (filtroCartao === "sem") {
        if (d.cartao_id || d.tipo === "fixa" || d.tipo === "recorrente") return false;
      } else if (d.cartao_id !== filtroCartao) {
        return false;
      }
    }
    if (filtroBanco !== "todos" && d.banco_id !== filtroBanco) return false;
    if (filtroCategoria !== "todos" && d.categoria !== filtroCategoria) return false;
    if (filtroResponsavel !== "todos" && d.responsavel !== filtroResponsavel) return false;
    if (filtroOrigem === "diretos" && d.origem && d.origem !== "manual") return false;
    if (filtroOrigem === "fatura" && (!d.origem || d.origem === "manual")) return false;
    if (filtroEconomia && !d.economia_conquistada) return false;
    if (
      busca &&
      !correspondeBuscaComValor(
        `${d.descricao ?? ""} ${d.categoria ?? ""} ${d.responsavel ?? ""}`,
        valorVisivel(d),
        busca,
      )
    )
      return false;
    return true;
  });

  const idsIgnoradosPorTotal = useMemo(() => {
    if (filtroMes === "todos") return new Set<string>();
    const ids = new Set<string>();
    for (const f of faturasMes as any[]) {
      if (f.competencia !== filtroMes || f.modo_calculo !== "somente_total") continue;
      for (const d of despesas as any[]) {
        if (d.cartao_id !== f.cartao_id) continue;
        const ehResumo = d.id === f.despesa_avulsa_id;
        if (f.status === "aberta" ? !ehResumo : ehResumo) ids.add(d.id);
      }
    }
    return ids;
  }, [faturasMes, despesas, filtroMes]);

  const listaVisivel = lista;

  const resumo = useMemo(() => {
    let total = 0;
    let pago = 0;
    let aberto = 0;
    let proximo: { data: string; valor: number; fixas: number; parcelados: number; outros: number } | null =
      null;
    const futuras: { data: string; valor: number; tipo: "fixa" | "parcelado" | "outro" }[] = [];
    const hoje = toISODate(new Date());
    for (const d of listaVisivel as any[]) {
      if (idsIgnoradosPorTotal.has(d.id)) continue;
      // Economia conquistada é neutra: continua visível na lista, mas não
      // soma nos totais do mês nem na conferência com a fatura (ela é o
      // gasto que deixou de existir, não um gasto a pagar).
      if (d.economia_conquistada) continue;
      const brl = (v: number) => toBRL(v, d.moeda, cotacao);
      const parcelasVisiveis =
        filtroMes === "todos"
          ? (d.parcelas ?? [])
          : lancamentosDoFiltro.filter((p) => p.despesa_id === d.id);
      total += brl(valorVisivel(d));
      for (const p of parcelasVisiveis) {
        if (p.paga) pago += brl(Number(p.valor));
        else {
          aberto += brl(Number(p.valor));
          if (p.vencimento >= hoje)
            futuras.push({
              data: p.vencimento,
              valor: brl(Number(p.valor)),
              tipo:
                d.tipo === "fixa"
                  ? "fixa"
                  : Number(d.total_parcelas ?? p.total ?? 1) > 1
                    ? "parcelado"
                    : "outro",
            });
        }
      }
    }
    // Próximo vencimento: soma de TUDO que vence na próxima data (antes mostrava só uma
    // parcela), separando despesas fixas e compras parceladas no cartão.
    const dataProxima = futuras.reduce<string | null>(
      (min, f) => (!min || f.data < min ? f.data : min),
      null,
    );
    if (dataProxima) {
      const doDia = futuras.filter((f) => f.data === dataProxima);
      const somaTipo = (tipo: string) =>
        doDia.filter((f) => f.tipo === tipo).reduce((s, f) => s + f.valor, 0);
      proximo = {
        data: dataProxima,
        valor: doDia.reduce((s, f) => s + f.valor, 0),
        fixas: somaTipo("fixa"),
        parcelados: somaTipo("parcelado"),
        outros: somaTipo("outro"),
      };
    }
    return { total, pago, aberto, proximo };
  }, [listaVisivel, cotacao, filtroMes, lancamentosDoFiltro, lancamentoPorDespesa, idsIgnoradosPorTotal]);

  // Lançamentos (parcelas) que compõem cada indicador do topo; ao clicar num indicador a lista mostra só eles.
  const lancamentosDoResumo = useMemo(() => {
    const itens: { despesa: any; parcela: any; valor: number }[] = [];
    if (!filtroResumo) return itens;
    for (const d of listaVisivel as any[]) {
      if (idsIgnoradosPorTotal.has(d.id) || d.economia_conquistada) continue;
      const parcelasVisiveis =
        filtroMes === "todos"
          ? (d.parcelas ?? [])
          : lancamentosDoFiltro.filter((p) => p.despesa_id === d.id);
      for (const p of parcelasVisiveis) {
        const casa = filtroResumo === "pago" ? !!p.paga : !p.paga;
        if (!casa) continue;
        if (filtroResumo === "proximo" && (!resumo.proximo || p.vencimento !== resumo.proximo.data))
          continue;
        itens.push({ despesa: d, parcela: p, valor: toBRL(Number(p.valor), d.moeda, cotacao) });
      }
    }
    return itens.sort((a, b) => String(a.parcela.vencimento).localeCompare(String(b.parcela.vencimento)));
  }, [filtroResumo, listaVisivel, idsIgnoradosPorTotal, filtroMes, lancamentosDoFiltro, resumo.proximo, cotacao]);
  const somaDoResumo = lancamentosDoResumo.reduce((s, i) => s + i.valor, 0);

  // Receitas do período, do mesmo jeito que a Home: pela data de recebimento e convertidas para BRL.
  const receitaDoFiltro = useMemo(
    () =>
      (receitas as any[])
        .filter((r) => filtroMes === "todos" || String(r.data_recebimento ?? "").slice(0, 7) === filtroMes)
        .reduce((s, r) => s + toBRL(Number(r.valor) || 0, r.moeda ?? "BRL", cotacao), 0),
    [receitas, filtroMes, cotacao],
  );
  // O saldo só faz sentido com a lista completa do período; com filtros, a despesa mostrada é parcial.
  const semFiltrosDeLista =
    tab === "total" &&
    filtroCartao === "todos" &&
    filtroBanco === "todos" &&
    filtroCategoria === "todos" &&
    filtroResponsavel === "todos" &&
    filtroOrigem === "todos" &&
    !filtroEconomia &&
    !busca;
  const saldoDoFiltro = receitaDoFiltro - resumo.total;

  // Bloco 6: sai da simulação sozinho ao trocar de aba/mês — os ids
  // excluídos de uma simulação não fazem sentido mais depois disso.
  useEffect(() => {
    setSimulandoCortes(false);
    setIdsExcluidosSimulacao(new Set());
    setFiltroResumo(null);
  }, [tab, filtroMes]);

  const simulacao = useMemo(() => {
    if (!simulandoCortes) return null;
    let economia = 0;
    for (const d of listaVisivel as any[]) {
      if (idsIgnoradosPorTotal.has(d.id)) continue;
      if (!idsExcluidosSimulacao.has(d.id)) continue;
      economia += toBRL(valorVisivel(d), d.moeda, cotacao);
    }
    return { totalSimulado: resumo.total - economia, economia };
  }, [simulandoCortes, listaVisivel, idsExcluidosSimulacao, idsIgnoradosPorTotal, cotacao, resumo.total]);

  /** Agrupa por cartão. Despesas fixas sem cartão ficam em 'Recorrente fora do cartão'. Demais sem cartão ficam em 'Sem atribuição'. */
  const gruposLista = useMemo(() => {
    if (modoLista === "lista")
      return [
        { key: "all", label: "", cor: "", itens: listaVisivel as any[], total: resumo.total },
      ];
    const mapa = new Map<
      string,
      { key: string; label: string; cor: string; itens: any[]; total: number }
    >();
    for (const d of listaVisivel as any[]) {
      const ehRecorrenteFora = !d.cartao_id && (d.tipo === "fixa" || d.tipo === "recorrente");
      const key = d.cartao_id ? `cartao:${d.cartao_id}` : (ehRecorrenteFora ? "recorrente_fora" : "sem");
      const label = d.cartoes
        ? `${d.cartoes.apelido || d.cartoes.bandeira || "Cartão"} •${d.cartoes.final ?? ""} · ${primeiroNome(d.cartoes.titular)}`
        : (ehRecorrenteFora ? "Recorrente fora do cartão" : "Sem atribuição");
      const cor = d.cartoes?.cor ?? "var(--muted-foreground)";
      const g = mapa.get(key) ?? { key, label, cor, itens: [] as any[], total: 0 };
      g.itens.push(d);
      if (!idsIgnoradosPorTotal.has(d.id)) {
        g.total += toBRL(valorVisivel(d), d.moeda, cotacao);
      }
      mapa.set(key, g);
    }
    return Array.from(mapa.values()).sort((a, b) => b.total - a.total);
  }, [listaVisivel, modoLista, cotacao, resumo.total, filtroMes, lancamentoPorDespesa, idsIgnoradosPorTotal]);

  const chips = [
    filtroCartao !== "todos" && {
      label:
        filtroCartao === "recorrente_fora"
          ? "Recorrente fora do cartão"
          : filtroCartao === "sem"
          ? "Sem atribuição"
          : (() => {
              const c: any = cartoes.find((c: any) => c.id === filtroCartao);
              return c
                ? `Cartão ${c.apelido ?? c.bandeira} •${c.final} · ${primeiroNome(c.titular)}`
                : "Cartão";
            })(),
      clear: () => setFiltroCartao("todos"),
    },
    filtroBanco !== "todos" && {
      label: `Banco ${(bancos.find((b: any) => b.id === filtroBanco) as any)?.nome ?? ""}`,
      clear: () => setFiltroBanco("todos"),
    },
    filtroCategoria !== "todos" && {
      label: filtroCategoria,
      clear: () => setFiltroCategoria("todos"),
    },
    filtroResponsavel !== "todos" && {
      label: filtroResponsavel,
      clear: () => setFiltroResponsavel("todos"),
    },
    filtroOrigem !== "todos" && {
      label: filtroOrigem === "diretos" ? "Lançamentos diretos" : "De fatura/importação",
      clear: () => setFiltroOrigem("todos"),
    },
    filtroEconomia && {
      label: "Economia conquistada",
      clear: () => setFiltroEconomia(false),
    },
    filtroMes !== "todos" && {
      label: monthLabelLong(filtroMes),
      clear: () => setFiltroMes("todos"),
    },
    !!busca && { label: `"${busca}"`, clear: () => setBusca("") },
  ].filter(Boolean) as { label: string; clear: () => void }[];

  function limparFiltros() {
    setFiltroCartao("todos");
    setFiltroBanco("todos");
    setFiltroCategoria("todos");
    setFiltroResponsavel("todos");
    setFiltroOrigem("todos");
    setFiltroMes("todos");
    setFiltroEconomia(false);
    setBusca("");
  }

  return (
    <AppLayout
      title="Despesas"
      description={`${lista.length} lançamento(s) · ${formatar(resumo.total)}`}
      actions={
        can("despesas", "editar") && (
          <div className="flex items-center gap-2">
            <FaturaMesDialog
              trigger={
                <Button size="sm" variant="outline">
                  <Receipt className="size-4" /> Fatura do mês
                </Button>
              }
            />
            <Button size="sm" onClick={abrirNova} data-tour="nova-despesa">
              <Plus className="size-4" /> Nova
            </Button>
          </div>
        )
      }
    >
      <div className="mb-3 grid grid-cols-2 gap-2 lg:grid-cols-3">
        {[
          { filtro: "total" as const, label: "Total despesas", valor: formatar(resumo.total), cor: "text-destructive", hint: "" },
          { filtro: null, label: "Receitas", valor: formatar(receitaDoFiltro), cor: "text-success", hint: "" },
          {
            filtro: null,
            label: "Saldo",
            valor: semFiltrosDeLista
              ? `${saldoDoFiltro >= 0 ? "+" : "-"} ${formatar(Math.abs(saldoDoFiltro))}`
              : "—",
            cor: saldoDoFiltro >= 0 ? "text-success" : "text-destructive",
            hint: semFiltrosDeLista ? "receitas − despesas" : "tire os filtros para ver o saldo",
          },
          { filtro: "pago" as const, label: "Pago", valor: formatar(resumo.pago), cor: "text-success", hint: "" },
          {
            filtro: "aberto" as const,
            label: "Em aberto",
            valor: formatar(resumo.aberto),
            cor: "text-destructive",
            hint: "",
          },
          {
            filtro: "proximo" as const,
            label: "Próximo vencimento",
            valor: resumo.proximo ? formatar(resumo.proximo.valor) : "—",
            cor: "text-warning",
            hint: resumo.proximo
              ? `${formatDate(resumo.proximo.data)} · fixas ${formatar(resumo.proximo.fixas)} · parcelados no cartão ${formatar(resumo.proximo.parcelados)}${resumo.proximo.outros > 0.004 ? ` · outros ${formatar(resumo.proximo.outros)}` : ""}`
              : "sem parcelas futuras",
          },
        ].map((k) => {
          const conteudo = (
            <>
              <p className="text-[11px] uppercase tracking-wide text-muted-foreground">{k.label}</p>
              <p className={cn("text-sm font-bold tabular-nums", k.cor)}>{k.valor}</p>
              {k.hint && <p className="text-[10px] text-muted-foreground">{k.hint}</p>}
            </>
          );
          if (!k.filtro)
            return (
              <div key={k.label} className="rounded-xl border bg-card px-3 py-2">
                {conteudo}
              </div>
            );
          const ativo = filtroResumo === k.filtro;
          return (
            <button
              key={k.label}
              type="button"
              aria-pressed={ativo}
              onClick={() =>
                setFiltroResumo(
                  k.filtro === "total" || ativo ? null : (k.filtro as "pago" | "aberto" | "proximo"),
                )
              }
              className={cn(
                "rounded-xl border bg-card px-3 py-2 text-left transition-colors hover:bg-muted/50",
                ativo && "ring-2 ring-primary",
              )}
            >
              {conteudo}
            </button>
          );
        })}
      </div>

      <BarraSoma
        qtd={soma.ids.size}
        total={(lista as any[])
          .filter((d) => soma.ids.has(d.id))
          .reduce((t, d) => t + toBRL(valorVisivel(d), d.moeda, cotacao), 0)}
        onLimpar={soma.limpar}
      />

      {/* Bloco 6 (plano-mega 2026-09-14): simular corte de despesas fixas —
          desmarcar itens aqui só recalcula o total na hora, nada é gravado
          no banco (estado local, reseta ao trocar de aba/mês ou sair). */}
      {tab === "fixa" && filtroMes !== "todos" && modoLista === "lista" && lista.length > 0 && (
        <div className="mb-3 space-y-2">
          <Button
            size="sm"
            variant={simulandoCortes ? "secondary" : "outline"}
            className="h-9 text-xs"
            onClick={() => setSimulandoCortes((v) => !v)}
          >
            <Calculator className="size-3.5" />
            {simulandoCortes ? "Sair da simulação" : "Simular cortes"}
          </Button>
          {simulandoCortes && simulacao && (
            <div className="flex flex-wrap items-center gap-3 rounded-lg border bg-muted/20 px-3 py-2 text-xs">
              <span className="text-muted-foreground">
                Desmarque abaixo os gastos que você cortaria — nada é salvo, é só pra visualizar.
              </span>
              <span className="font-semibold">
                Total simulado: {formatBRL(simulacao.totalSimulado)}
              </span>
              {simulacao.economia > 0 && (
                <span className="font-semibold text-success">
                  Economia: {formatBRL(simulacao.economia)}
                </span>
              )}
            </div>
          )}
        </div>
      )}

      <div className="mb-3 space-y-2">
        <div className="relative">
          <Search className="pointer-events-none absolute left-3.5 top-1/2 size-5 -translate-y-1/2 text-primary" aria-hidden="true" />
          <Input
            value={busca}
            onChange={(e) => setBusca(e.target.value)}
            placeholder="Buscar despesa por descrição, categoria ou responsável"
            aria-label="Buscar despesas"
            className="h-12 border-primary/50 bg-card pl-11 pr-11 text-base shadow-sm focus-visible:border-primary"
          />
          {busca && (
            <button
              type="button"
              onClick={() => setBusca("")}
              aria-label="Limpar busca"
              className="absolute right-2.5 top-1/2 flex size-8 -translate-y-1/2 items-center justify-center rounded-full text-muted-foreground hover:bg-muted hover:text-foreground"
            >
              <X className="size-4" />
            </button>
          )}
        </div>
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
          {/* Ajuste mobile (otimização para celulares, 2026-09-27): abas,
              busca e selects de filtro ganham altura/toque maiores (~40-44px)
              — os h-9/py-1 anteriores ficavam abaixo do mínimo recomendado
              de toque confortável no dedo. Só nesta tela e em Receitas por
              ora (telas apontadas como as mais usadas no celular). */}
          <Tabs value={tab} onValueChange={(v) => setTab(v as typeof tab)}>
            <TabsList className="h-10">
              <TabsTrigger value="total" className="px-3.5 py-2 text-xs">
                Total
              </TabsTrigger>
              <TabsTrigger value="fixa" className="px-3.5 py-2 text-xs">
                Fixas
              </TabsTrigger>
              <TabsTrigger value="variavel" className="px-3.5 py-2 text-xs">
                Variáveis
              </TabsTrigger>
            </TabsList>
          </Tabs>
          <Tabs value={modoLista} onValueChange={(v) => setModoLista(v as "lista" | "cartao")}>
            <TabsList className="h-10">
              <TabsTrigger value="lista" className="gap-1 px-3.5 py-2 text-xs">
                <ListIcon className="size-3.5" /> Lista
              </TabsTrigger>
              <TabsTrigger value="cartao" className="gap-1 px-3.5 py-2 text-xs">
                <CreditCard className="size-3.5" /> Por cartão
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        <NavegadorMes
          valor={filtroMes === "todos" ? null : filtroMes}
          onChange={setFiltroMes}
          className="mb-2"
        />

        <div className="grid grid-cols-2 gap-2 lg:grid-cols-5">
          <Select value={filtroCartao} onValueChange={setFiltroCartao}>
            <SelectTrigger className="h-11 text-xs">
              <SelectValue placeholder="Cartão" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todos">Todos os cartões</SelectItem>
              <SelectItem value="recorrente_fora">Recorrente fora do cartão</SelectItem>
              <SelectItem value="sem">Sem atribuição</SelectItem>
              {cartoes.map((c: any) => (
                <SelectItem key={c.id} value={c.id}>
                  {c.apelido ?? c.bandeira} •{c.final} · {primeiroNome(c.titular)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={filtroBanco} onValueChange={setFiltroBanco}>
            <SelectTrigger className="h-11 text-xs">
              <SelectValue placeholder="Banco" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todos">Todos os bancos</SelectItem>
              {bancos.map((b: any) => (
                <SelectItem key={b.id} value={b.id}>
                  {b.nome}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <SelectBusca
            className="h-11 text-xs"
            ariaLabel="Filtrar por categoria"
            placeholder="Categoria"
            valor={filtroCategoria}
            opcoes={[
              { valor: "todos", rotulo: "Todas as categorias" },
              ...categorias.map((c: any) => ({ valor: c.nome as string, rotulo: c.nome as string })),
            ]}
            onEscolher={setFiltroCategoria}
          />
          <Select value={filtroResponsavel} onValueChange={setFiltroResponsavel}>
            <SelectTrigger className="h-11 text-xs">
              <SelectValue placeholder="Responsável" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todos">Todos os responsáveis</SelectItem>
              {responsaveis.map((r) => (
                <SelectItem key={r} value={r}>
                  {r}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={filtroOrigem} onValueChange={setFiltroOrigem}>
            <SelectTrigger className="h-11 text-xs">
              <SelectValue placeholder="Origem" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todos">Diretos e de fatura</SelectItem>
              <SelectItem value="diretos">Só lançamentos diretos</SelectItem>
              <SelectItem value="fatura">Só de fatura/importação</SelectItem>
            </SelectContent>
          </Select>
          <Select value={filtroMes} onValueChange={setFiltroMes}>
            <SelectTrigger className="h-11 text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todos">Todos os meses</SelectItem>
              {meses.map((m) => (
                <SelectItem key={m} value={m}>
                  {monthLabelLong(m)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {chips.length > 0 && (
          <div className="flex flex-wrap items-center gap-1.5">
            {chips.map((c) => (
              <button
                key={c.label}
                onClick={c.clear}
                className="inline-flex items-center gap-1.5 rounded-full border bg-muted/50 px-3 py-1.5 text-[11px] font-medium hover:bg-muted"
              >
                {c.label}
                <X className="size-3" />
              </button>
            ))}
            <Button variant="ghost" size="sm" className="h-8 text-[11px]" onClick={limparFiltros}>
              Limpar filtros
            </Button>
          </div>
        )}
      </div>

      {modoLista === "lista" &&
        filtroMes !== "todos" &&
        can("despesas", "editar") &&
        lista.length > 0 && (
          <div className="mb-3 flex flex-wrap items-center gap-2 rounded-lg border bg-muted/20 px-3 py-2">
            <span className="text-xs text-muted-foreground">
              {tab === "total" ? "Todas" : tab === "fixa" ? "Fixas" : "Variáveis"} de{" "}
              {monthLabelLong(filtroMes)}:
            </span>
            <Button
              size="sm"
              variant="outline"
              className="h-9 text-xs"
              disabled={marcarLote.isPending || idsDoLote(lista, "abertas").length === 0}
              onClick={() => marcarLote.mutate({ ids: idsDoLote(lista, "abertas"), paga: true })}
            >
              <CheckCircle2 className="size-3.5" /> Marcar todas pagas
            </Button>
            <Button
              size="sm"
              variant="outline"
              className="h-9 text-xs"
              disabled={marcarLote.isPending || idsDoLote(lista, "pagas").length === 0}
              onClick={() => marcarLote.mutate({ ids: idsDoLote(lista, "pagas"), paga: false })}
            >
              Desfazer todas
            </Button>
          </div>
        )}

      {filtroResumo ? (
        <Card>
          <CardContent className="p-0">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b px-3 py-2">
              <p className="text-xs text-muted-foreground">
                {({ pago: "Pagos", aberto: "Em aberto", proximo: "Próximo vencimento" } as const)[filtroResumo]}
                {" · "}
                {lancamentosDoResumo.length} lançamento(s) · <span className="font-semibold text-foreground">{formatar(somaDoResumo)}</span>
              </p>
              <Button size="sm" variant="ghost" className="h-7 text-xs" onClick={() => setFiltroResumo(null)}>
                Limpar filtro
              </Button>
            </div>
            {lancamentosDoResumo.length === 0 ? (
              <p className="p-6 text-center text-sm text-muted-foreground">Nenhum lançamento neste filtro.</p>
            ) : (
              <div className="divide-y">
                {lancamentosDoResumo.map(({ despesa: d, parcela: p, valor }) => (
                  <button
                    key={`${d.id}-${p.id ?? p.numero}`}
                    type="button"
                    onClick={() => abrirEdicao(d)}
                    className="flex w-full items-center gap-3 px-3 py-2 text-left hover:bg-muted/40"
                  >
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium">{d.descricao}</p>
                      <p className="text-[11px] text-muted-foreground">
                        {formatDate(p.vencimento)} ·{" "}
                        {d.cartoes
                          ? `${d.cartoes.apelido || d.cartoes.bandeira || "Cartão"} •${d.cartoes.final ?? ""}`
                          : "Sem cartão"}
                        {d.total_parcelas > 1 ? ` · parcela ${p.numero}/${d.total_parcelas}` : ""}
                      </p>
                    </div>
                    <Badge variant={p.paga ? "secondary" : "outline"} className="text-[10px]">
                      {p.paga ? "Paga" : "Em aberto"}
                    </Badge>
                    <span className="shrink-0 text-sm font-semibold tabular-nums">{formatar(valor)}</span>
                  </button>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      ) : lista.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center gap-2 py-12 text-center">
            <TrendingDown className="size-8 text-muted-foreground" />
            <p className="text-sm text-muted-foreground">Nenhuma despesa encontrada.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {gruposLista.map((grupo) => (
            <div key={grupo.key} className="overflow-hidden rounded-xl border bg-card">
              {modoLista === "cartao" && (
                <div
                  role="button"
                  tabIndex={0}
                  className="flex w-full items-center gap-3 border-b bg-muted/30 px-3 py-2 text-left native:flex-wrap native:gap-y-2"
                  onClick={() => setGrupoExpandido(grupoExpandido === grupo.key ? null : grupo.key)}
                  onKeyDown={(e) =>
                    e.key === "Enter" &&
                    setGrupoExpandido(grupoExpandido === grupo.key ? null : grupo.key)
                  }
                >
                  <div
                    className="flex size-8 shrink-0 items-center justify-center rounded-lg"
                    style={{ backgroundColor: grupo.cor }}
                  >
                    <CreditCard className="size-4 text-white" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold">{grupo.label}</p>
                    <Progress
                      value={resumo.total > 0 ? (grupo.total / resumo.total) * 100 : 0}
                      className="mt-1 h-1.5"
                    />
                  </div>
                  <div className="shrink-0 text-right">
                    <p className="text-sm font-bold tabular-nums">{formatar(grupo.total)}</p>
                    <p className="text-[10px] text-muted-foreground">
                      {grupo.itens.length} lançamento(s) ·{" "}
                      {resumo.total > 0 ? ((grupo.total / resumo.total) * 100).toFixed(0) : 0}%
                    </p>
                  </div>
                  {can("despesas", "editar") &&
                    filtroMes !== "todos" &&
                    idsDoLote(grupo.itens, "abertas").length > 0 && (
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-9 shrink-0 text-xs native:order-last native:h-8 native:w-full"
                      disabled={
                        marcarLote.isPending || idsDoLote(grupo.itens, "abertas").length === 0
                      }
                      onClick={(e) => {
                        e.stopPropagation();
                        marcarLote.mutate({ ids: idsDoLote(grupo.itens, "abertas"), paga: true });
                      }}
                      aria-label="Marcar fatura importada como paga"
                    >
                      <CheckCircle2 className="size-3.5" /> Marcar fatura paga
                    </Button>
                  )}
                  {can("despesas", "editar") &&
                    filtroMes !== "todos" &&
                    idsDoLote(grupo.itens, "abertas").length === 0 &&
                    idsDoLote(grupo.itens, "pagas").length > 0 && (
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-9 shrink-0 text-xs native:order-last native:h-8 native:w-full"
                        disabled={marcarLote.isPending}
                        onClick={(e) => {
                          e.stopPropagation();
                          marcarLote.mutate({ ids: idsDoLote(grupo.itens, "pagas"), paga: false });
                        }}
                        aria-label="Marcar fatura como não paga"
                      >
                        <RotateCcw className="size-3.5" /> Marcar como não paga
                      </Button>
                    )}
                  <ChevronDown
                    className={cn(
                      "size-4 transition-transform",
                      grupoExpandido === grupo.key && "rotate-180",
                    )}
                  />
                </div>
              )}
              {(modoLista !== "cartao" || grupoExpandido === grupo.key) && (
                <div className="divide-y">
                  <label className="flex cursor-pointer items-center gap-3 bg-muted/20 px-3 py-1.5 text-[11px] text-muted-foreground">
                    <Checkbox
                      checked={soma.todosMarcados(grupo.itens.map((d: any) => d.id))}
                      onCheckedChange={() => soma.alternarVarios(grupo.itens.map((d: any) => d.id))}
                      aria-label="Selecionar todos para somar"
                    />
                    Selecionar todos ({grupo.itens.length}) para somar
                  </label>
                  {grupo.itens.map((d: any) => {
                    const parcelas = [
                      ...(filtroMes === "todos"
                        ? (d.parcelas ?? [])
                        : lancamentosDoFiltro.filter((p) => p.despesa_id === d.id)),
                    ].sort((a: any, b: any) => a.numero - b.numero);
                    const totalPagas = (d.parcelas ?? []).filter((p: any) => p.paga).length;
                    const pDoMes = filtroMes === "todos" ? null : lancamentoPorDespesa.get(d.id);
                    const aberta = expandida === d.id;
                    const ignoradaNoMes = idsIgnoradosPorTotal.has(d.id);
                    const faturaAvulsa = (faturasMes as any[]).find(
                      (f) => f.despesa_avulsa_id === d.id,
                    );
                    const ehTotalManual = !!faturaAvulsa;
                    return (
                      <div key={d.id}>
                        <div
                          onClick={() => abrirEdicao(d)}
                          className={cn(
                            "flex items-center gap-3 px-3 py-2.5 transition-colors hover:bg-muted/40 native:gap-2 native:active:bg-muted/50",
                            can("despesas", "editar") && "cursor-pointer",
                            (ignoradaNoMes ||
                              d.origem === "fatura_total_concluida" ||
                              d.economia_conquistada ||
                              (simulandoCortes && idsExcluidosSimulacao.has(d.id))) &&
                              "opacity-60 line-through bg-muted/20",
                          )}
                        >
                          <Checkbox
                            className="shrink-0"
                            checked={soma.ids.has(d.id)}
                            onClick={(e) => e.stopPropagation()}
                            onCheckedChange={() => soma.alternar(d.id)}
                            aria-label={`Somar ${d.descricao}`}
                          />
                          {simulandoCortes && tab === "fixa" && (
                            <Checkbox
                              className="shrink-0"
                              checked={!idsExcluidosSimulacao.has(d.id)}
                              onClick={(e) => e.stopPropagation()}
                              onCheckedChange={(checked) => {
                                setIdsExcluidosSimulacao((prev) => {
                                  const next = new Set(prev);
                                  if (checked) next.delete(d.id);
                                  else next.add(d.id);
                                  return next;
                                });
                              }}
                              aria-label={`Incluir ${d.descricao} na simulação`}
                            />
                          )}
                          <div
                            className="h-8 w-1 shrink-0 rounded-full"
                            style={{ backgroundColor: d.cartoes?.cor ?? "var(--muted-foreground)" }}
                          />
                          <div className="min-w-0 flex-1">
                            <div className="flex flex-wrap items-center gap-1.5">
                              <p className="truncate text-sm font-semibold leading-tight native:line-clamp-2 native:whitespace-normal">
                                {identificacaoDespesa(d) && (
                                  <span className="text-primary">{identificacaoDespesa(d)} · </span>
                                )}
                                {d.descricao}
                                {!!d.possivel_duplicidade && (
                                  <Badge variant="outline" className="ml-2 border-amber-500/40 align-middle text-[10px] text-amber-700 dark:text-amber-300" title="Mesmo valor de um lançamento manual em outra data. Confira se não é duplicidade.">Possível duplicidade</Badge>
                                )}
                              </p>
                              {ignoradaNoMes && (
                                <Badge
                                  variant="outline"
                                  className="border-amber-500/30 text-[10px] text-amber-600 dark:text-amber-400"
                                >
                                  Ignorado neste mês (total manual)
                                </Badge>
                              )}
                              {ehTotalManual && faturaAvulsa?.status === "aberta" && (
                                <Badge
                                  className="bg-amber-600 text-[10px] hover:bg-amber-700"
                                  title="Veio do totalizador de fatura (Fatura do mês), não de lançamento item a item."
                                >
                                  Total manual ativo
                                  {faturaAvulsa.tipo_lancamento === "temporario" &&
                                    faturaAvulsa.data_limite &&
                                    ` · até ${monthLabelLong(monthKey(faturaAvulsa.data_limite))}`}
                                </Badge>
                              )}
                              {ehTotalManual &&
                                faturaAvulsa?.status === "aberta" &&
                                faturaAvulsa.tipo_lancamento === "temporario" &&
                                faturaAvulsa.data_limite &&
                                monthKey(faturaAvulsa.data_limite) < monthKey(new Date()) && (
                                  <Badge
                                    variant="outline"
                                    className="border-destructive/40 text-[10px] text-destructive"
                                  >
                                    Prazo do total passou — considere detalhar item a item
                                  </Badge>
                                )}
                              {d.origem === "fatura_total_concluida" && (
                                <Badge variant="outline" className="text-[10px]">
                                  Total manual concluído
                                </Badge>
                              )}
                              {d.origem === "pluggy" && (
                                <Badge
                                  variant="outline"
                                  className="border-emerald-500/30 text-[10px] text-emerald-600 dark:text-emerald-400"
                                >
                                  Open Finance
                                </Badge>
                              )}
                              {d.origem && d.origem !== "manual" && d.origem !== "pluggy" && (
                                <Badge
                                  variant="outline"
                                  className="border-sky-500/30 text-[10px] text-sky-600 dark:text-sky-400"
                                >
                                  {d.origem.startsWith("fatura") ? "De fatura" : "Importado"}
                                </Badge>
                              )}
                              {d.economia_conquistada && (
                                <Badge
                                  variant="outline"
                                  className="border-emerald-500/30 text-[10px] text-emerald-600 dark:text-emerald-400"
                                >
                                  Economia conquistada
                                </Badge>
                              )}
                            </div>
                            <p className="truncate text-[11px] text-muted-foreground">
                              {formatDate(d.data_compra)} · {d.categoria}
                              {d.tipo === "fixa"
                                ? ` · ${filtroMes === "todos" ? "valor mensal" : monthLabelLong(filtroMes)}`
                                : d.total_parcelas > 1
                                  ? ` · ${d.total_parcelas}x de ${formatar(
                                      toBRL(
                                        Number(d.valor_total) / d.total_parcelas,
                                        d.moeda,
                                        cotacao,
                                      ),
                                    )}`
                                  : " · à vista"}
                            </p>
                          </div>
                          {d.tipo !== "fixa" && d.total_parcelas > 1 && (
                            <div className="hidden w-24 shrink-0 sm:block">
                              <Badge variant="secondary" className="text-[10px]">
                                {`${totalPagas}/${d.total_parcelas} pagas`}
                              </Badge>
                              <Progress
                                value={(totalPagas / d.total_parcelas) * 100}
                                className="mt-1 h-1"
                              />
                            </div>
                          )}

                          <div className="shrink-0 text-right">
                            <p className="text-sm font-bold tabular-nums">
                              {formatar(toBRL(valorVisivel(d), d.moeda, cotacao))}
                            </p>
                            {d.moeda === "USD" && (
                              <p className="text-[10px] text-muted-foreground">
                                {formatUSD(Number(d.valor_total))}
                              </p>
                            )}
                          </div>
                          {/* No app: um único botão de ações, como em app nativo. */}
                          <div className="hidden shrink-0 native:block">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="size-8 text-muted-foreground"
                                  onClick={(e) => e.stopPropagation()}
                                  aria-label={`Ações de ${d.descricao}`}
                                >
                                  <EllipsisVertical className="size-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end" onClick={(e) => e.stopPropagation()}>
                                {can("despesas", "editar") && (
                                  <DropdownMenuItem onSelect={() => abrirEdicao(d)}>
                                    <Pencil className="size-4" /> Editar
                                  </DropdownMenuItem>
                                )}
                                {can("despesas", "editar") && (
                                  <DropdownMenuItem
                                    onSelect={() =>
                                      moverTipo.mutate({
                                        id: d.id,
                                        tipo: d.tipo === "fixa" ? "variavel" : "fixa",
                                      })
                                    }
                                  >
                                    <ArrowLeftRight className="size-4" />
                                    {d.tipo === "fixa" ? "Mover para variável" : "Mover para fixa"}
                                  </DropdownMenuItem>
                                )}
                                {parcelas.length > 0 && (
                                  <DropdownMenuItem onSelect={() => setExpandida(aberta ? null : d.id)}>
                                    <ChevronDown className="size-4" />
                                    {aberta ? "Ocultar parcelas" : "Ver parcelas"}
                                  </DropdownMenuItem>
                                )}
                                {can("despesas", "excluir") && (
                                  <DropdownMenuItem
                                    className="text-destructive focus:text-destructive"
                                    onSelect={() => {
                                      if (d.tipo === "fixa" && !d.cartao_id) setDespesaFixaParaExcluir(d);
                                      else setDespesaParaExcluir(d);
                                    }}
                                  >
                                    <Trash2 className="size-4" /> Excluir
                                  </DropdownMenuItem>
                                )}
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                          <div className="flex shrink-0 items-center native:hidden">
                            {can("despesas", "editar") && (
                              <Button
                                variant="ghost"
                                size="icon"
                                className="size-8 text-muted-foreground hover:text-primary"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  moverTipo.mutate({
                                    id: d.id,
                                    tipo: d.tipo === "fixa" ? "variavel" : "fixa",
                                  });
                                }}
                                title={
                                  d.tipo === "fixa" ? "Mover para variável" : "Mover para fixa"
                                }
                                aria-label={
                                  d.tipo === "fixa" ? "Mover para variável" : "Mover para fixa"
                                }
                              >
                                <ArrowLeftRight className="size-4" />
                              </Button>
                            )}
                            {can("despesas", "editar") && (
                              <Button
                                variant="ghost"
                                size="icon"
                                className="size-8 text-muted-foreground hover:text-primary"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  abrirEdicao(d);
                                }}
                                aria-label="Editar despesa"
                              >
                                <Pencil className="size-4" />
                              </Button>
                            )}

                            {parcelas.length > 0 && (
                              <Button
                                variant="ghost"
                                size="icon"
                                className="size-8 text-muted-foreground"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setExpandida(aberta ? null : d.id);
                                }}
                                aria-label="Ver parcelas"
                              >
                                <ChevronDown
                                  className={cn(
                                    "size-4 transition-transform",
                                    aberta && "rotate-180",
                                  )}
                                />
                              </Button>
                            )}
                            {can("despesas", "excluir") && (
                              <Button
                                variant="ghost"
                                size="icon"
                                className="size-8 text-muted-foreground hover:text-destructive"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  if (d.tipo === "fixa" && !d.cartao_id) setDespesaFixaParaExcluir(d);
                                  else setDespesaParaExcluir(d);
                                }}
                                aria-label="Excluir despesa"
                              >
                                <Trash2 className="size-4" />
                              </Button>
                            )}
                          </div>
                        </div>

                        {aberta && (
                          <div className="space-y-2 border-t bg-muted/20 px-3 py-2.5">
                            {d.tipo !== "fixa" && d.total_parcelas > 1 && (
                              <Progress
                                value={(totalPagas / d.total_parcelas) * 100}
                                className="h-1.5"
                              />
                            )}
                            <div className="flex flex-wrap gap-1.5">
                              {parcelas.map((p: any) => (
                                <button
                                  key={p.id}
                                  onClick={() => togglePaga.mutate({ id: p.id, paga: !p.paga })}
                                  disabled={!can("despesas", "editar")}
                                  className={cn(
                                    "inline-flex items-center gap-1 rounded-lg border px-2.5 py-1.5 text-[11px] font-medium tabular-nums transition-colors",
                                    p.paga
                                      ? "border-success/30 bg-success/10 text-success"
                                      : "border-border bg-background text-muted-foreground hover:border-primary/40",
                                  )}
                                  title={`Vence em ${formatDate(p.vencimento)}`}
                                >
                                  {p.paga && <CheckCircle2 className="size-3" />}
                                  {d.tipo === "fixa"
                                    ? monthLabelLong(monthKey(p.vencimento))
                                    : `${p.numero}/${p.total}`}{" "}
                                  · {formatBRL(Number(p.valor))}
                                </button>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>
              {editId ? "Editar despesa" : `Nova despesa ${tab === "fixa" ? "fixa" : "variável"}`}
            </DialogTitle>
          </DialogHeader>
          {!editId && <PrimeiraCategoriaGuia tipo="despesa" />}

          {duplicata && (
            <Alert className="border-warning/40 bg-warning/10">
              <AlertTriangle className="size-4 text-warning" />
              <AlertTitle className="text-sm">Possível duplicidade</AlertTitle>
              <AlertDescription className="text-xs">
                Já existe “{duplicata.descricao}” de {formatBRL(Number(duplicata.valor_total))} em{" "}
                {formatDate(duplicata.data_compra)}. Clique em salvar novamente para confirmar mesmo
                assim.
              </AlertDescription>
            </Alert>
          )}

          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Descrição" className="sm:col-span-2">
              <Input
                value={form.descricao}
                onChange={(e) => setForm({ ...form, descricao: e.target.value })}
                placeholder="Ex.: Mercado do mês"
              />
            </Field>
            <Field label="Valor">
              <Input
                inputMode="decimal"
                value={form.valor_total}
                onChange={(e) => setForm({ ...form, valor_total: e.target.value })}
                placeholder="0,00"
              />
              {valorDigitado > 0 && (
                <p className="mt-1 text-[11px] text-muted-foreground">
                  {ehFixa
                    ? `${formatBRL(valorDigitado)} por mês`
                    : nParcelas > 1
                      ? `${nParcelas}x de ${formatBRL(previewParcela)} — total ${formatBRL(valorNum)}`
                      : ""}
                </p>
              )}
            </Field>
            {ehFixa ? (
              <Field label="Duração">
                <Select
                  value={form.recorrencia_duracao}
                  onValueChange={(v) => setForm({ ...form, recorrencia_duracao: v })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sem_prazo">Sem prazo</SelectItem>
                    <SelectItem value="prazo">Prazo determinado</SelectItem>
                  </SelectContent>
                </Select>
              </Field>
            ) : (
              <div className="hidden sm:block" />
            )}
            {ehFixa && !semPrazo && (
              <Field label="Parcelas/Meses">
                <Input
                  type="number"
                  min={1}
                  max={600}
                  value={form.recorrencia_meses}
                  onChange={(e) => setForm({ ...form, recorrencia_meses: e.target.value })}
                />
              </Field>
            )}

            <Field label="Moeda">
              <Select value={form.moeda} onValueChange={(v) => setForm({ ...form, moeda: v })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="BRL">R$ Real</SelectItem>
                  <SelectItem value="USD">US$ Dólar</SelectItem>
                </SelectContent>
              </Select>
            </Field>
            <Field label="Categoria">
              <SelectBusca
                ariaLabel="Categoria da despesa"
                placeholder="Selecione"
                valor={form.categoria}
                opcoes={categorias.map((c: any) => ({
                  valor: c.nome as string,
                  rotulo: c.nome as string,
                }))}
                onEscolher={(v) => setForm({ ...form, categoria: v })}
              />
            </Field>
            <Field label="Tipo">
              <Select value={form.tipo} onValueChange={(v) => setForm({ ...form, tipo: v })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="fixa">Fixa</SelectItem>
                  <SelectItem value="variavel">Variável</SelectItem>
                </SelectContent>
              </Select>
            </Field>
            <Field label="Data da compra">
              <Input
                type="date"
                value={form.data_compra}
                onChange={(e) => setForm({ ...form, data_compra: e.target.value })}
              />
            </Field>
            <Field label="Forma de pagamento">
              <Select
                value={form.pagamento}
                onValueChange={(v) => setForm({ ...form, pagamento: v })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Cartão ou banco" />
                </SelectTrigger>
                <SelectContent>
                  {cartoes.map((c: any) => (
                    <SelectItem key={c.id} value={`cartao:${c.id}`}>
                      {c.apelido ?? c.bandeira} •{c.final} · {primeiroNome(c.titular)}
                    </SelectItem>
                  ))}
                  {bancos.map((b: any) => (
                    <SelectItem key={b.id} value={`banco:${b.id}`}>
                      {b.nome} (conta)
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
            {!ehFixa && (
              <Field label="Número de parcelas *">
                <Input
                  type="number"
                  min={1}
                  value={form.total_parcelas}
                  onChange={(e) => setForm({ ...form, total_parcelas: e.target.value })}
                />
              </Field>
            )}
            {!ehFixa && nParcelas > 1 && (
              <Field label="Parcela atual / Já pagas">
                <Input
                  type="number"
                  min={1}
                  max={nParcelas}
                  value={form.parcela_atual ?? "1"}
                  onChange={(e) => setForm({ ...form, parcela_atual: e.target.value })}
                />
              </Field>
            )}
            <Field label={ehFixa ? "Data de início" : "Data da 1ª parcela"}>
              <Input
                type="date"
                value={form.data_primeira_parcela}
                onChange={(e) => setForm({ ...form, data_primeira_parcela: e.target.value })}
              />
            </Field>
            {ehFixa && (
              <Field label="Reajuste" className="sm:col-span-2">
                <Select
                  value={form.reajuste_tipo}
                  onValueChange={(v) => setForm({ ...form, reajuste_tipo: v })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="nenhum">Sem reajuste</SelectItem>
                    <SelectItem value="composto">Reajuste composto periódico</SelectItem>
                  </SelectContent>
                </Select>
              </Field>
            )}
            {ehFixa && form.reajuste_tipo === "composto" && (
              <>
                <Field label="Percentual (%)">
                  <Input
                    inputMode="decimal"
                    placeholder="Ex.: 5"
                    value={form.reajuste_percentual}
                    onChange={(e) => setForm({ ...form, reajuste_percentual: e.target.value })}
                  />
                </Field>
                <Field label="Periodicidade">
                  <Select
                    value={form.reajuste_periodicidade}
                    onValueChange={(v) => setForm({ ...form, reajuste_periodicidade: v })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {PERIODICIDADES.map((p) => (
                        <SelectItem key={p.value} value={p.value}>
                          {p.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </Field>
                <Field label="Índice (opcional)">
                  <IndiceReajusteField
                    indice={form.reajuste_indice}
                    onIndiceChange={(v) => setForm({ ...form, reajuste_indice: v })}
                    periodicidade={form.reajuste_periodicidade as Periodicidade}
                    onValorBuscado={(percentual) =>
                      setForm({
                        ...form,
                        reajuste_percentual: String(percentual).replace(".", ","),
                      })
                    }
                    onMediaMensalBuscada={(percentual) =>
                      setForm({
                        ...form,
                        reajuste_periodicidade: "mensal",
                        reajuste_percentual: String(percentual).replace(".", ","),
                      })
                    }
                  />
                </Field>
                <Field label="1º reajuste em">
                  <Input
                    type="date"
                    value={form.reajuste_inicio}
                    onChange={(e) => setForm({ ...form, reajuste_inicio: e.target.value })}
                  />
                </Field>
              </>
            )}
            <Field label="Responsável">
              <Select
                value={form.responsavel}
                onValueChange={(v) => setForm({ ...form, responsavel: v })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione" />
                </SelectTrigger>
                <SelectContent>
                  {responsaveis.map((r) => (
                    <SelectItem key={r} value={r}>
                      {r}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
            <Field label="Observações" className="sm:col-span-2">
              <Textarea
                rows={2}
                value={form.observacoes}
                onChange={(e) => setForm({ ...form, observacoes: e.target.value })}
              />
            </Field>
            <div className="sm:col-span-2 rounded-lg border border-emerald-500/20 bg-emerald-50/50 p-3 dark:bg-emerald-950/20">
              <label className="flex items-center gap-2 text-sm font-medium text-emerald-800 dark:text-emerald-300 cursor-pointer">
                <Checkbox
                  checked={!!form.economia_conquistada}
                  onCheckedChange={(v) => setForm({ ...form, economia_conquistada: !!v })}
                />
                Despesa Ajustada / Economia Conquistada
              </label>
              <p className="mt-1 text-xs text-muted-foreground">
                Marque se você negociou ou cancelou esta cobrança (ex.: anuidade isentada ou serviço cancelado). A despesa fica riscada no histórico.
              </p>
            </div>
          </div>

          {valorDigitado > 0 && (ehFixa || nParcelas > 1) && (
            <p className="rounded-lg bg-muted/60 px-3 py-2 text-xs text-muted-foreground">
              {ehFixa
                ? `${formatBRL(valorDigitado)} por mês a partir de ${monthLabelLong(competenciaDe(form.data_primeira_parcela || form.data_compra))}` +
                  (semPrazo
                    ? ", sem prazo."
                    : ` até ${monthLabelLong(ultimaCompetencia?.competencia ?? "")} (${mesesPrazo} meses).`) +
                  (recorrencia?.reajuste
                    ? ` Reajuste ${recorrencia.reajuste.periodicidade} de ${recorrencia.reajuste.percentual}%${recorrencia.reajuste.indice ? ` (${recorrencia.reajuste.indice})` : ""} — último mês projetado: ${formatBRL(ultimaCompetencia?.valor ?? valorDigitado)}.`
                    : "")
                : `${nParcelas}x de ${formatBRL(previewParcela)} — total ${formatBRL(valorNum)}.`}
            </p>
          )}

          <DialogFooter>
            <Button onClick={tentarSalvar} disabled={salvar.isPending}>
              {duplicata ? "Salvar mesmo assim" : editId ? "Salvar alterações" : "Salvar despesa"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog
        open={!!despesaParaExcluir}
        onOpenChange={(v) => !v && setDespesaParaExcluir(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {despesaParaExcluir &&
              (faturasMes as any[]).some((f) => f.despesa_avulsa_id === despesaParaExcluir.id)
                ? "Excluir lançamento de total da fatura?"
                : "Excluir despesa?"}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {despesaParaExcluir &&
              (faturasMes as any[]).some((f) => f.despesa_avulsa_id === despesaParaExcluir.id)
                ? "Os lançamentos normais do cartão voltarão a ser considerados e somados no mês."
                : `Tem certeza que deseja excluir "${despesaParaExcluir?.descricao}"?`}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() => {
                if (despesaParaExcluir) {
                  void executarExclusaoComUndo(despesaParaExcluir);
                  setDespesaParaExcluir(null);
                }
              }}
            >
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <ExcluirRecorrenteDialog
        aberto={!!despesaFixaParaExcluir}
        onFechar={() => setDespesaFixaParaExcluir(null)}
        descricao={despesaFixaParaExcluir?.descricao ?? ""}
        competencia={competenciaFiltrada}
        onConfirmar={async (modo) => {
          const alvo = despesaFixaParaExcluir;
          setDespesaFixaParaExcluir(null);
          if (!alvo) return;
          try {
            await excluirDespesaSerie(supabase, alvo.id, competenciaFiltrada, modo);
            toast.success("Despesa excluída");
            qc.invalidateQueries();
          } catch (e: any) {
            toast.error(e?.message ?? "Erro ao excluir despesa");
          }
        }}
      />
    </AppLayout>
  );
}
