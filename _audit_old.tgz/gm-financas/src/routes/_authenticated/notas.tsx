import { useBancos, useCartoes } from "@/hooks/useFinance";
import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  AlertTriangle,
  Camera,
  Copy,
  ExternalLink,
  FolderOpen,
  HardDrive,
  Image as ImageIcon,
  Plus,
  QrCode,
  ShieldCheck,
  Trash2,
  Upload,
} from "lucide-react";
import { toast } from "sonner";

import { AppLayout } from "@/components/AppLayout";
import { LeitorNota } from "@/components/LeitorNota";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { classificarItemNota, calcularDepreciacao } from "@/lib/nota-itens-classificacao";
import { DepreciacaoItem, PresetsVidaUtil } from "@/components/notas/DepreciacaoItem";
import { LISTA_CATEGORIAS } from "@/lib/categorizacao";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { formatBRL, formatDate, toISODate } from "@/lib/format";
import {
  PRAZOS_GARANTIA,
  calcularFimGarantia,
  chaveValida,
  dadosDaChave,
  diasRestantes,
  formatarChave,
  linkConsulta,
  statusGarantia,
} from "@/lib/nfe";
import {
  completeDriveConnection,
  disconnectDrive,
  driveStatus,
  getPastaDrive,
  resolverUrlsOracle,
  setPastaDrive,
  startDriveConnect,
  uploadNotaArquivo,
} from "@/lib/drive.functions";
import { consultarNota } from "@/lib/nfe.functions";
import { usePermissoes } from "@/hooks/useAuthData";
import { obterConfiguracaoAcesso } from "@/lib/configuracoes-site.functions";

export const Route = createFileRoute("/_authenticated/notas")({
  head: () => ({
    meta: [
      { title: "Notas fiscais e garantias — Control ALL" },
      {
        name: "description",
        content:
          "Guarde comprovantes por foto ou leitura do QR Code da nota, com chave de acesso, itens e alerta de fim da garantia.",
      },
      { property: "og:title", content: "Notas fiscais e garantias — Control ALL" },
      {
        property: "og:description",
        content:
          "Comprovantes em pasta compartilhada, chave de acesso e aviso antes da garantia expirar.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: NotasPage,
});

const CATEGORIAS = [
  "eletronicos",
  "eletrodomesticos",
  "moveis",
  "vestuario",
  "servicos",
  "alimentacao",
  "outros",
];

type Filtro = "todas" | "ativa" | "expirando" | "expirada";

type NotaForm = {
  estabelecimento: string;
  descricao: string;
  data_compra: string;
  valor_total: string;
  categoria: string;
  garantia_meses: string;
  observacoes: string;
  /** Item 19 (2026-10-05): "cartao:<id>" | "banco:<id>" | "" (cartão/conta usada na compra). */
  pagamento: string;
  chave_acesso: string;
  url_consulta: string;
  uf: string;
  status_captura: string;
};

const FORM_VAZIO: NotaForm = {
  estabelecimento: "",
  descricao: "",
  data_compra: toISODate(new Date()),
  valor_total: "",
  categoria: "outros",
  garantia_meses: "12",
  observacoes: "",
  pagamento: "",
  chave_acesso: "",
  url_consulta: "",
  uf: "",
  status_captura: "manual",
};

function useNotas() {
  return useQuery({
    queryKey: ["notas-fiscais"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("notas_fiscais")
        .select("*, nota_itens(*), nota_arquivos(*)")
        .order("data_compra", { ascending: false });
      if (error) throw error;
      const notas = data ?? [];

      // Arquivos "supabase:<path>": bucket privado no Supabase Storage,
      // resolvido direto no client (mesma sessão do usuário já tem acesso
      // via RLS do storage).
      const paths = [
        ...new Set(
          notas.flatMap((nota) =>
            (nota.nota_arquivos ?? [])
              .filter((arquivo) => arquivo.drive_file_id.startsWith("supabase:"))
              .map((arquivo) => arquivo.drive_file_id.slice("supabase:".length)),
          ),
        ),
      ];
      const links = new Map<string, string>();
      if (paths.length) {
        const { data: assinaturas, error: assinaturasError } = await supabase.storage
          .from("comprovantes")
          .createSignedUrls(paths, 3600);
        if (assinaturasError) throw assinaturasError;
        paths.forEach((path, index) => {
          const url = assinaturas?.[index]?.signedUrl;
          if (url) links.set(path, url);
        });
      }

      // Arquivos "oracle:<object_key>" (2026-09-27): bucket privado no
      // Oracle Object Storage — as credenciais não existem no client, então
      // a URL assinada precisa vir do server (resolverUrlsOracle).
      const objectKeysOracle = [
        ...new Set(
          notas.flatMap((nota) =>
            (nota.nota_arquivos ?? [])
              .filter((arquivo) => arquivo.drive_file_id.startsWith("oracle:"))
              .map((arquivo) => arquivo.drive_file_id.slice("oracle:".length)),
          ),
        ),
      ];
      const linksOracle = new Map<string, string>();
      if (objectKeysOracle.length) {
        try {
          const { urls } = await resolverUrlsOracle({ data: { objectKeys: objectKeysOracle } });
          Object.entries(urls).forEach(([objectKey, url]) => linksOracle.set(objectKey, url));
        } catch (err) {
          console.error("Não foi possível carregar os arquivos do Oracle:", err);
        }
      }

      return notas.map((nota) => ({
        ...nota,
        nota_arquivos: (nota.nota_arquivos ?? []).map((arquivo) => {
          if (arquivo.drive_file_id.startsWith("supabase:")) {
            const url = links.get(arquivo.drive_file_id.slice("supabase:".length)) ?? null;
            return {
              ...arquivo,
              link: url,
              thumbnail_link: arquivo.mime_type?.startsWith("image/") ? url : null,
            };
          }
          if (arquivo.drive_file_id.startsWith("oracle:")) {
            const url = linksOracle.get(arquivo.drive_file_id.slice("oracle:".length)) ?? null;
            return {
              ...arquivo,
              link: url,
              thumbnail_link: arquivo.mime_type?.startsWith("image/") ? url : null,
            };
          }
          return arquivo;
        }),
      }));
    },
    refetchInterval: 30 * 60 * 1000,
  });
}

function SeloGarantia({ fim }: { fim: string | null }) {
  const status = statusGarantia(fim);
  const dias = diasRestantes(fim);
  if (status === "sem") return <Badge variant="secondary">Sem garantia</Badge>;
  if (status === "expirada")
    return <Badge variant="destructive">Garantia expirada em {formatDate(fim!)}</Badge>;
  const tom =
    status === "critica"
      ? "bg-destructive/10 text-destructive"
      : status === "atencao"
        ? "bg-warning/15 text-warning-foreground"
        : "bg-primary/10 text-primary";
  return (
    <span className={`rounded-full px-2.5 py-1 text-xs font-medium ${tom}`}>
      Garantia até {formatDate(fim!)} · {dias} dia{dias === 1 ? "" : "s"}
    </span>
  );
}

function NotasPage() {
  const { exclusaoBloqueada, isSiteAdmin } = usePermissoes();
  const qc = useQueryClient();
  const { data: notas = [], isLoading } = useNotas();
  const [filtro, setFiltro] = useState<Filtro>("todas");
  const [busca, setBusca] = useState("");
  const [escolha, setEscolha] = useState(false);
  useEffect(() => {
    const abrir = () => setEscolha(true);
    window.addEventListener("abrir-nova-nota", abrir);
    return () => window.removeEventListener("abrir-nova-nota", abrir);
  }, []);
  const [leitor, setLeitor] = useState(false);
  const [form, setForm] = useState<NotaForm | null>(null);
  const { data: cartoesLista = [] } = useCartoes();
  const { data: bancosLista = [] } = useBancos();
  const nomePagamento = (tipo: string | null, id: string | null) => {
    if (!id) return "";
    if (tipo === "cartao") {
      const c = (cartoesLista as any[]).find((x) => x.id === id);
      return c ? `Cartão ${c.apelido || c.bancos?.nome || ""}${c.final ? ` •${c.final}` : ""}`.trim() : "Cartão removido";
    }
    const b = (bancosLista as any[]).find((x) => x.id === id);
    return b ? `Conta ${b.nome}` : "Conta removida";
  };
  const [editandoId, setEditandoId] = useState<string | null>(null);
  const [detalhe, setDetalhe] = useState<string | null>(null);
  const [itensLidos, setItensLidos] = useState<
    {
      descricao: string;
      quantidade: number;
      valor_unitario: number;
      valor_total: number;
      categoria?: string | null;
      subcategoria?: string | null;
      deprecia?: boolean | null;
      meses_depreciacao?: number | null;
    }[]
  >([]);
  const [fotosPendentes, setFotosPendentes] = useState<File[]>([]);
  const fileRef = useRef<HTMLInputElement | null>(null);
  const notaAlvoUpload = useRef<string | null>(null);

  const status = useServerFn(driveStatus);
  const iniciarConexao = useServerFn(startDriveConnect);
  const concluirConexao = useServerFn(completeDriveConnection);
  const desconectar = useServerFn(disconnectDrive);
  const enviarArquivo = useServerFn(uploadNotaArquivo);
  const consultar = useServerFn(consultarNota);

  const drive = useQuery({ queryKey: ["drive-status"], queryFn: () => status({}) });

  // Item 15 (backlog 2026-09-27): a seção de pasta/Google Drive fica oculta
  // pro usuário comum por padrão — só o admin do site vê sempre, e pode
  // reabilitar pra todo mundo mais tarde via essa mesma configuração global.
  const obterConfigAcesso = useServerFn(obterConfiguracaoAcesso);
  const configAcesso = useQuery({
    queryKey: ["configuracao-acesso-publica"],
    queryFn: () => obterConfigAcesso(),
    staleTime: 60_000,
  });
  const mostrarSecaoDrive = isSiteAdmin || !!configAcesso.data?.google_drive_habilitado;

  const lerPasta = useServerFn(getPastaDrive);
  const gravarPasta = useServerFn(setPastaDrive);
  const pasta = useQuery({ queryKey: ["drive-pasta"], queryFn: () => lerPasta({}) });
  const [pastaInput, setPastaInput] = useState("");
  useEffect(() => {
    if (pasta.data?.folderUrl) setPastaInput(pasta.data.folderUrl);
  }, [pasta.data?.folderUrl]);
  const salvarPasta = useMutation({
    mutationFn: () => gravarPasta({ data: { valor: pastaInput } }),
    onSuccess: () => {
      toast.success("Pasta compartilhada salva.");
      void qc.invalidateQueries({ queryKey: ["drive-pasta"] });
    },
    onError: (e: Error) => toast.error(e.message ?? "Não consegui salvar a pasta."),
  });

  const conectar = useMutation({
    mutationFn: async () => {
      const popup = window.open("", "google-drive-oauth", "width=600,height=720");
      if (!popup) throw new Error("Permita pop-ups para conectar o Google Drive.");
      let authorization: { code: string; state: string };
      try {
        const { authorizationUrl } = await iniciarConexao({});
        const completion = new Promise<{ code: string; state: string }>((resolve, reject) => {
          const cleanup = () => {
            window.removeEventListener("message", onMessage);
            window.clearInterval(poll);
            window.clearTimeout(timeout);
          };
          const onMessage = (event: MessageEvent) => {
            const tipo = (event.data as { type?: string })?.type;
            if (
              event.origin !== window.location.origin ||
              event.source !== popup ||
              (event.data as { connectorId?: string })?.connectorId !== "google_drive" ||
              (tipo !== "appUserConnectorOAuthComplete" && tipo !== "appUserConnectorOAuthFailed")
            )
              return;
            cleanup();
            if (tipo === "appUserConnectorOAuthComplete") {
              const c = (event.data as { code?: string | null })?.code;
              const s = (event.data as { state?: string | null })?.state;
              if (typeof c === "string" && typeof s === "string") resolve({ code: c, state: s });
              else reject(new Error("O Google não retornou uma autorização válida."));
              return;
            }
            popup.close();
            const detalhe = (event.data as { error?: string | null })?.error;
            reject(
              new Error(
                detalhe ? `Google Drive: ${detalhe}` : "Conexão com o Google Drive não concluída.",
              ),
            );
          };
          window.addEventListener("message", onMessage);
          const poll = window.setInterval(() => {
            if (!popup.closed) return;
            cleanup();
            reject(
              new Error(
                "A janela do Google foi fechada antes de concluir. Se o Google mostrou um erro, verifique se a sua conta está liberada no app e tente novamente.",
              ),
            );
          }, 500);
          const timeout = window.setTimeout(() => {
            cleanup();
            popup.close();
            reject(new Error("A autorização demorou demais. Tente conectar novamente."));
          }, 5 * 60_000);
        });
        popup.location.href = authorizationUrl;
        authorization = await completion;
      } catch (e) {
        popup.close();
        throw e;
      }
      await concluirConexao({ data: authorization });
    },
    onSuccess: () => {
      toast.success("Google Drive conectado.");
      void qc.invalidateQueries({ queryKey: ["drive-status"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const salvar = useMutation({
    mutationFn: async (dados: NotaForm) => {
      const meses = Number(dados.garantia_meses) || 0;
      const payload = {
        estabelecimento: dados.estabelecimento || null,
        descricao: dados.descricao || null,
        data_compra: dados.data_compra,
        valor_total: Number(dados.valor_total.replace(",", ".")) || 0,
        categoria: dados.categoria,
        garantia_meses: meses || null,
        garantia_fim: calcularFimGarantia(dados.data_compra, meses),
        observacoes: dados.observacoes || null,
        pagamento_tipo: dados.pagamento ? dados.pagamento.split(":")[0]! : null,
        pagamento_id: dados.pagamento ? dados.pagamento.split(":")[1]! : null,
        chave_acesso: dados.chave_acesso || null,
        url_consulta: dados.url_consulta || null,
        uf: dados.uf || null,
        status_captura: dados.status_captura,
      };

      let notaId = editandoId;
      if (notaId) {
        const { error } = await supabase.from("notas_fiscais").update(payload).eq("id", notaId);
        if (error) throw error;
      } else {
        const { data: user } = await supabase.auth.getUser();
        const { data, error } = await supabase
          .from("notas_fiscais")
          .insert({ ...payload, created_by: user.user?.id ?? null })
          .select("id")
          .single();
        if (error) throw error;
        notaId = data.id;
        if (itensLidos.length) {
          await (supabase.from("nota_itens") as any).insert(
            itensLidos.map((i) => {
              const classif = i.categoria ? { categoria: i.categoria, subcategoria: i.subcategoria } : classificarItemNota(i.descricao);
              return {
                nota_id: notaId!,
                descricao: i.descricao,
                quantidade: i.quantidade,
                valor_unitario: i.valor_unitario,
                valor_total: i.valor_total,
                categoria: i.categoria ?? classif.categoria,
                subcategoria: i.subcategoria ?? classif.subcategoria,
                deprecia: i.deprecia ?? false,
                meses_depreciacao: i.meses_depreciacao ?? null,
              };
            }),
          );
        }
      }

      if (fotosPendentes.length) {
        const competencia = dados.data_compra.slice(0, 7);
        for (const file of fotosPendentes) {
          const base64 = await fileParaBase64(file);
          const resultado = await enviarArquivo({
            data: {
              notaId: notaId!,
              nome: file.name || `nota-${Date.now()}.jpg`,
              mimeType: file.type || "image/jpeg",
              base64,
              competencia,
            },
          });
          if ("aviso" in resultado && resultado.aviso) toast.warning(resultado.aviso);
        }
      }
      return notaId!;
    },
    onSuccess: () => {
      toast.success("Nota salva.");
      setForm(null);
      setEditandoId(null);
      setItensLidos([]);
      setFotosPendentes([]);
      void qc.invalidateQueries({ queryKey: ["notas-fiscais"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const excluir = useMutation({
    mutationFn: async (id: string) => {
      if (exclusaoBloqueada) throw new Error("Seu perfil não possui permissão para excluir dados.");
      const { data: arquivos, error: arquivosError } = await supabase
        .from("nota_arquivos")
        .select("drive_file_id")
        .eq("nota_id", id);
      if (arquivosError) throw arquivosError;
      const paths = (arquivos ?? [])
        .filter((arquivo) => arquivo.drive_file_id.startsWith("supabase:"))
        .map((arquivo) => arquivo.drive_file_id.slice("supabase:".length));
      if (paths.length) {
        const { error: removeError } = await supabase.storage.from("comprovantes").remove(paths);
        if (removeError) throw removeError;
      }
      const { error } = await supabase.from("notas_fiscais").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Nota excluída.");
      setDetalhe(null);
      void qc.invalidateQueries({ queryKey: ["notas-fiscais"] });
    },
  });

  const anexar = useMutation({
    mutationFn: async ({ notaId, files }: { notaId: string; files: File[] }) => {
      const nota = notas.find((n) => n.id === notaId);
      const competencia = (nota?.data_compra ?? toISODate(new Date())).slice(0, 7);
      const destinos = new Set<string>();
      for (const file of files) {
        const base64 = await fileParaBase64(file);
        const resultado = await enviarArquivo({
          data: {
            notaId,
            nome: file.name || `nota-${Date.now()}.jpg`,
            mimeType: file.type || "image/jpeg",
            base64,
            competencia,
          },
        });
        destinos.add(resultado.destino);
        if ("aviso" in resultado && resultado.aviso) toast.warning(resultado.aviso);
      }
      return destinos;
    },
    onSuccess: (destinos) => {
      // Se misturou destinos (alguns arquivos foram pro Drive, outros
      // caíram no site), diz isso claramente — dizer só "enviado ao Google
      // Drive" quando pelo menos um foi escondia que outro(s) não foram
      // (o aviso individual de cada arquivo já aparece, mas o resumo final
      // não podia contradizer isso).
      const foiDrive = destinos.has("google_drive");
      const foiSite = destinos.has("site");
      toast.success(
        foiDrive && foiSite
          ? "Parte dos comprovantes foi ao Google Drive; o restante ficou salvo no site."
          : foiDrive
            ? "Comprovante enviado ao Google Drive."
            : "Comprovante guardado no site.",
      );
      void qc.invalidateQueries({ queryKey: ["notas-fiscais"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  async function aoLerCodigo({ chave, texto }: { chave: string; texto: string }) {
    setLeitor(false);
    if (!chaveValida(chave))
      toast.warning("A chave lida não passou na validação; confira os dados.");
    const dados = dadosDaChave(chave);
    const base: NotaForm = {
      ...FORM_VAZIO,
      chave_acesso: chave,
      url_consulta: /^https?:/i.test(texto) ? texto : linkConsulta(chave),
      uf: dados?.uf ?? "",
      data_compra: dados?.emissao ?? FORM_VAZIO.data_compra,
    };
    setForm(base);
    setEditandoId(null);
    setItensLidos([]);

    try {
      const r = await consultar({ data: { url: base.url_consulta } });
      if (r.status === "auto") {
        setForm((f) =>
          f
            ? {
                ...f,
                estabelecimento: r.estabelecimento ?? f.estabelecimento,
                valor_total: r.valor_total !== null ? String(r.valor_total) : f.valor_total,
                data_compra: r.data_compra ?? f.data_compra,
                status_captura: "auto",
              }
            : f,
        );
        setItensLidos(r.itens);
        toast.success("Dados da nota obtidos automaticamente.");
      } else {
        toast.info(r.motivo ?? "Preencha os dados manualmente.");
      }
    } catch {
      toast.info("Não deu para consultar a nota agora; preencha manualmente.");
    }
  }

  const lista = useMemo(() => {
    const termo = busca.trim().toLowerCase();
    return notas.filter((n) => {
      const st = statusGarantia(n.garantia_fim);
      if (filtro === "ativa" && (st === "expirada" || st === "sem")) return false;
      if (filtro === "expirada" && st !== "expirada") return false;
      if (filtro === "expirando" && st !== "critica" && st !== "atencao") return false;
      if (!termo) return true;
      // Busca também nos itens da nota (ex.: "ventilador" acha a nota da Riachuelo).
      return [n.estabelecimento, n.descricao, n.chave_acesso, ...(n.nota_itens ?? []).map((i) => i.descricao)]
        .filter(Boolean)
        .some((v) => String(v).toLowerCase().includes(termo));
    });
  }, [notas, filtro, busca]);

  const aVencer = notas.filter((n) => {
    const st = statusGarantia(n.garantia_fim);
    return st === "critica" || st === "atencao";
  });

  const notaDetalhe = notas.find((n) => n.id === detalhe) ?? null;

  return (
    <AppLayout
      title="Notas fiscais"
      description="Comprovantes, chave de acesso e controle de garantia"
      actions={
        <Button size="sm" className="hidden gap-2 lg:inline-flex" onClick={() => setEscolha(true)} data-tour="nova-nota">
          <Plus className="size-4" /> Nova nota
        </Button>
      }
    >
      <input
        ref={fileRef}
        type="file"
        accept="image/*,application/pdf"
        capture="environment"
        multiple
        className="hidden"
        onChange={(e) => {
          const files = Array.from(e.target.files ?? []);
          e.target.value = "";
          if (!files.length) return;
          const alvo = notaAlvoUpload.current;
          notaAlvoUpload.current = null;
          if (alvo) anexar.mutate({ notaId: alvo, files });
          else {
            setFotosPendentes(files);
            setForm({ ...FORM_VAZIO });
            setEditandoId(null);
          }
        }}
      />

      <div className="space-y-4">
        {mostrarSecaoDrive && (
        <Card>
          {isSiteAdmin && !configAcesso.data?.google_drive_habilitado && (
            <div className="border-b bg-amber-500/10 px-4 py-2 text-[11px] text-amber-700">
              Visível só pra você (admin). Oculto pros usuários comuns — reative em Administração
              → Módulos.
            </div>
          )}
          <CardContent className="space-y-4 py-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="flex size-9 items-center justify-center rounded-xl bg-primary/10">
                  <FolderOpen className="size-4.5 text-primary" />
                </div>
                <div>
                  <p className="text-sm font-semibold">Pasta dos comprovantes</p>
                  <p className="text-xs text-muted-foreground">
                    {pasta.data?.folderUrl
                      ? `${pasta.data.provider ?? "Serviço"} selecionado`
                      : "Use uma pasta compartilhada do serviço que preferir"}
                  </p>
                </div>
              </div>
              {pasta.data?.folderUrl && (
                <Button variant="outline" size="sm" asChild>
                  <a href={pasta.data.folderUrl} target="_blank" rel="noreferrer">
                    <ExternalLink className="size-4" /> Abrir pasta
                  </a>
                </Button>
              )}
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <Input
                value={pastaInput}
                onChange={(e) => setPastaInput(e.target.value)}
                placeholder="Cole o link do OneDrive, MEGA, iCloud Drive, Google Drive…"
                className="min-w-[220px] flex-1"
              />
              <Button
                size="sm"
                variant="outline"
                onClick={() => salvarPasta.mutate()}
                disabled={salvarPasta.isPending}
              >
                Salvar pasta
              </Button>
            </div>
            <div className="border-t pt-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="flex size-9 items-center justify-center rounded-xl bg-primary/10">
                    <HardDrive className="size-4.5 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold">Envio automático pelo Google Drive</p>
                    <p className="text-xs text-muted-foreground">
                      {drive.data?.connected
                        ? pasta.data?.provider === "Google Drive" && pasta.data?.folderId
                          ? "Conectado. Tentamos usar a pasta que você configurou abaixo — se o Drive não deixar (só funciona com pastas criadas ou abertas pelo próprio app), cai automaticamente para a pasta padrão do app"
                          : "Conectado. O envio usa a pasta que o próprio app cria no seu Drive (\"Finanças do Casal/Notas fiscais\")"
                        : drive.data?.googleAvailable
                          ? "Opcional: conecte. Sem conexão, os arquivos ficam privados no site"
                          : "Seus arquivos ficam privados no site. Google Drive aguarda configuração"}
                    </p>
                  </div>
                </div>
                {drive.data?.connected ? (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() =>
                      desconectar({}).then(() => {
                        toast.success("Google Drive desconectado.");
                        void qc.invalidateQueries({ queryKey: ["drive-status"] });
                      })
                    }
                  >
                    Desconectar
                  </Button>
                ) : drive.data?.googleAvailable ? (
                  <Button size="sm" onClick={() => conectar.mutate()} disabled={conectar.isPending}>
                    {conectar.isPending ? "Conectando…" : "Conectar Google Drive"}
                  </Button>
                ) : null}
              </div>
              <p className="mt-2 text-[11px] text-muted-foreground">
                A conexão usa somente a pasta e os arquivos criados pelo aplicativo na sua conta
                Google. Em outros serviços, use “Abrir pasta” para enviar ou consultar os
                comprovantes.
              </p>
            </div>
          </CardContent>
        </Card>
        )}

        {aVencer.length > 0 && (
          <Card className="border-warning/40 bg-warning/5">
            <CardContent className="flex items-start gap-3 py-4">
              <AlertTriangle className="mt-0.5 size-4.5 text-warning" />
              <div className="text-sm">
                <p className="font-medium">
                  {aVencer.length} garantia{aVencer.length > 1 ? "s" : ""} vencendo em até 30 dias
                </p>
                <p className="text-xs text-muted-foreground">
                  {aVencer
                    .slice(0, 3)
                    .map(
                      (n) =>
                        `${n.estabelecimento ?? n.descricao ?? "Nota"} (${diasRestantes(n.garantia_fim)}d)`,
                    )
                    .join(" · ")}
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        <Tabs defaultValue="notas" className="space-y-4">
          <TabsList className="h-9">
            <TabsTrigger value="notas" className="text-xs">Notas fiscais</TabsTrigger>
            <TabsTrigger value="segmentos" className="text-xs">Gastos por tipo</TabsTrigger>
            <TabsTrigger value="depreciacao" className="text-xs">Depreciação</TabsTrigger>
          </TabsList>

          {/* === ABA 1: listagem de notas === */}
          <TabsContent value="notas" className="space-y-4">
            <div className="flex flex-wrap items-center gap-2">
              <Input
                value={busca}
                onChange={(e) => setBusca(e.target.value)}
                placeholder="Buscar por loja, item, descrição ou chave"
                className="h-9 max-w-xs"
              />
              {(
                [
                  ["todas", "Todas"],
                  ["ativa", "Garantia ativa"],
                  ["expirando", "Vencendo em 30 dias"],
                  ["expirada", "Expiradas"],
                ] as [Filtro, string][]
              ).map(([id, label]) => (
                <Button
                  key={id}
                  size="sm"
                  variant={filtro === id ? "default" : "outline"}
                  onClick={() => setFiltro(id)}
                >
                  {label}
                </Button>
              ))}
            </div>

            {isLoading ? (
              <p className="text-sm text-muted-foreground">Carregando…</p>
            ) : lista.length === 0 ? (
              <Card>
                <CardContent className="py-10 text-center text-sm text-muted-foreground">
                  Nenhuma nota por aqui ainda. Toque em "Nova nota" para começar.
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
                {lista.map((n) => {
                  const foto = (n.nota_arquivos ?? [])[0];
                  const temGarantia = !!n.garantia_fim;
                  return (
                    <Card
                      key={n.id}
                      className="cursor-pointer transition-colors hover:border-primary/50"
                      onClick={() => setDetalhe(n.id)}
                    >
                      <CardContent className="flex gap-3 py-4">
                        <div className="flex size-14 shrink-0 items-center justify-center overflow-hidden rounded-xl bg-muted">
                          {foto?.thumbnail_link ? (
                            <img
                              src={foto.thumbnail_link}
                              alt={`Comprovante de ${n.estabelecimento ?? "nota fiscal"}`}
                              className="size-full object-cover"
                              loading="lazy"
                            />
                          ) : (
                            <ImageIcon className="size-5 text-muted-foreground" />
                          )}
                        </div>
                        <div className="min-w-0 flex-1 space-y-1">
                          <div className="flex items-start justify-between gap-1">
                            <p className="truncate text-sm font-semibold">
                              {n.estabelecimento || n.descricao || "Nota fiscal"}
                            </p>
                            {temGarantia ? (
                              <Badge variant="default" className="shrink-0 h-4 text-[10px] px-1.5 bg-emerald-600 hover:bg-emerald-600">
                                <ShieldCheck className="size-2.5 mr-0.5" />
                                Garantia
                              </Badge>
                            ) : (
                              <Badge variant="secondary" className="shrink-0 h-4 text-[10px] px-1.5">
                                Sem garantia
                              </Badge>
                            )}
                          </div>
                          <p className="text-xs text-muted-foreground">
                            {formatDate(n.data_compra)} · {formatBRL(Number(n.valor_total))}
                          </p>
                          <SeloGarantia fim={n.garantia_fim} />
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </TabsContent>

          {/* === ABA 2: gastos por tipo / segmentos === */}
          <TabsContent value="segmentos" className="space-y-3">
            {(() => {
              const todosItens = notas.flatMap((n) =>
                (n.nota_itens ?? []).map((i) => ({
                  ...i,
                  data_compra: n.data_compra,
                  estabelecimento: n.estabelecimento ?? n.descricao ?? "Nota fiscal",
                })),
              );
              if (!todosItens.length) {
                return (
                  <Card>
                    <CardContent className="py-10 text-center text-sm text-muted-foreground">
                      Nenhum item registrado ainda. Faça a leitura de uma nota via QR Code para ver os gastos por tipo.
                    </CardContent>
                  </Card>
                );
              }
              const porCategoria = todosItens.reduce<Record<string, { total: number; qtdItens: number }>>((acc, i) => {
                const cat = (i as any).categoria ?? "Outros";
                if (!acc[cat]) acc[cat] = { total: 0, qtdItens: 0 };
                acc[cat].total += Number((i as any).valor_total ?? 0);
                acc[cat].qtdItens += 1;
                return acc;
              }, {});
              const totalGeral = Object.values(porCategoria).reduce((s, v) => s + v.total, 0);
              const categorias = Object.entries(porCategoria).sort((a, b) => b[1].total - a[1].total);
              return (
                <>
                  <p className="text-xs text-muted-foreground">
                    Total em itens registrados: <span className="font-semibold text-foreground">{formatBRL(totalGeral)}</span>
                  </p>
                  <div className="space-y-3">
                    {categorias.map(([cat, { total, qtdItens }]) => {
                      const pct = totalGeral > 0 ? (total / totalGeral) * 100 : 0;
                      return (
                        <Card key={cat}>
                          <CardContent className="py-3 space-y-1.5">
                            <div className="flex items-center justify-between gap-2">
                              <p className="text-sm font-medium">{cat}</p>
                              <div className="flex items-center gap-2">
                                <Badge variant="secondary" className="text-[10px]">
                                  {qtdItens} {qtdItens === 1 ? "item" : "itens"}
                                </Badge>
                                <span className="text-sm font-semibold tabular-nums">
                                  {formatBRL(total)}
                                </span>
                              </div>
                            </div>
                            <div className="h-1.5 w-full rounded-full bg-muted overflow-hidden">
                              <div
                                className="h-full rounded-full bg-primary transition-all"
                                style={{ width: `${pct.toFixed(1)}%` }}
                              />
                            </div>
                            <p className="text-[11px] text-muted-foreground text-right">
                              {pct.toFixed(1)}% do total
                            </p>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>
                </>
              );
            })()}
          </TabsContent>

          {/* === ABA 3: módulo de depreciação === */}
          <TabsContent value="depreciacao" className="space-y-3">
            {(() => {
              const bensDepreciaveis = notas.flatMap((n) =>
                (n.nota_itens ?? [])
                  .filter((i) => !!(i as any).deprecia && (i as any).meses_depreciacao)
                  .map((i) => ({
                    ...i,
                    data_compra: n.data_compra,
                    estabelecimento: n.estabelecimento ?? n.descricao ?? "Nota fiscal",
                  })),
              );
              if (!bensDepreciaveis.length) {
                return (
                  <Card>
                    <CardContent className="py-10 text-center text-sm text-muted-foreground">
                      Nenhum bem sujeito a depreciação registrado. Ao ler uma nota, marque "Este item deprecia?" para ativá-lo aqui.
                    </CardContent>
                  </Card>
                );
              }
              const calculos = bensDepreciaveis.map((i) =>
                calcularDepreciacao({
                  valorOriginal: Number((i as any).valor_total ?? 0),
                  dataCompra: i.data_compra,
                  mesesVidaUtil: Number((i as any).meses_depreciacao),
                }),
              );
              const totalOriginal = bensDepreciaveis.reduce((s, i) => s + Number((i as any).valor_total ?? 0), 0);
              const totalAtual = calculos.reduce((s, c) => s + c.valorAtual, 0);
              const totalMensal = calculos.reduce((s, c) => s + (c.totalmenteDepreciado ? 0 : c.taxaMensal), 0);
              return (
                <div className="space-y-3">
                  <Card>
                    <CardContent className="py-3 space-y-2">
                      <div className="grid grid-cols-2 gap-2 text-center sm:grid-cols-4">
                        <div className="rounded-lg bg-muted/50 p-2">
                          <p className="text-[10px] text-muted-foreground">Valor de compra</p>
                          <p className="text-xs font-semibold">{formatBRL(totalOriginal)}</p>
                        </div>
                        <div className="rounded-lg bg-muted/50 p-2">
                          <p className="text-[10px] text-muted-foreground">Valor atual dos bens</p>
                          <p className="text-xs font-semibold text-primary">{formatBRL(totalAtual)}</p>
                        </div>
                        <div className="rounded-lg bg-muted/50 p-2">
                          <p className="text-[10px] text-muted-foreground">Depreciado até hoje</p>
                          <p className="text-xs font-semibold">{formatBRL(totalOriginal - totalAtual)}</p>
                        </div>
                        <div className="rounded-lg bg-muted/50 p-2">
                          <p className="text-[10px] text-muted-foreground">Perda de valor por mês</p>
                          <p className="text-xs font-semibold">{formatBRL(totalMensal)}</p>
                        </div>
                      </div>
                      <p className="text-[11px] text-muted-foreground">
                        Depreciação é a perda de valor do bem ao longo da vida útil (método linear, em meses completos a partir da compra). Não é um gasto novo: o dinheiro já saiu na compra, então ela não entra nas despesas do mês.
                      </p>
                    </CardContent>
                  </Card>
                  {bensDepreciaveis.map((i) => {
                    const dep = calcularDepreciacao({
                      valorOriginal: Number((i as any).valor_total ?? 0),
                      dataCompra: i.data_compra,
                      mesesVidaUtil: Number((i as any).meses_depreciacao),
                    });
                    return (
                      <Card key={(i as any).id}>
                        <CardContent className="py-3 space-y-2">
                          <div className="flex items-start justify-between gap-2">
                            <div className="min-w-0">
                              <p className="text-sm font-medium truncate">{(i as any).descricao}</p>
                              <p className="text-xs text-muted-foreground">{(i as any).estabelecimento} · {formatDate(i.data_compra)}</p>
                            </div>
                            <Badge
                              variant={dep.totalmenteDepreciado ? "destructive" : "secondary"}
                              className="shrink-0 text-[10px]"
                            >
                              {dep.totalmenteDepreciado ? "Totalmente depreciado" : `${dep.percentualDepreciado.toFixed(0)}% depreciado`}
                            </Badge>
                          </div>
                          <div className="grid grid-cols-3 gap-2 text-center">
                            <div className="rounded-lg bg-muted/50 p-2">
                              <p className="text-[10px] text-muted-foreground">Valor original</p>
                              <p className="text-xs font-semibold">{formatBRL(Number((i as any).valor_total))}</p>
                            </div>
                            <div className="rounded-lg bg-muted/50 p-2">
                              <p className="text-[10px] text-muted-foreground">Valor atual</p>
                              <p className="text-xs font-semibold text-primary">{formatBRL(dep.valorAtual)}</p>
                            </div>
                            <div className="rounded-lg bg-muted/50 p-2">
                              <p className="text-[10px] text-muted-foreground">Meses restantes</p>
                              <p className="text-xs font-semibold">{dep.mesesRestantes}</p>
                            </div>
                          </div>
                          <div className="h-1.5 w-full rounded-full bg-muted overflow-hidden">
                            <div
                              className="h-full rounded-full bg-primary transition-all"
                              style={{ width: `${dep.percentualDepreciado.toFixed(1)}%` }}
                            />
                          </div>
                          <p className="text-[11px] text-muted-foreground">
                            Vida útil: {(i as any).meses_depreciacao} meses · Depreciação mensal: {formatBRL(dep.taxaMensal)}
                          </p>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              );
            })()}
          </TabsContent>
        </Tabs>
      </div>

      {/* Escolha foto x leitura */}
      <Dialog open={escolha} onOpenChange={setEscolha}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Nova nota</DialogTitle>
          </DialogHeader>
          <div className="grid gap-3">
            <Button
              variant="outline"
              className="h-auto justify-start gap-3 py-4"
              onClick={() => {
                setEscolha(false);
                notaAlvoUpload.current = null;
                fileRef.current?.click();
              }}
            >
              <Camera className="size-5 text-primary" />
              <span className="text-left">
                <span className="block text-sm font-semibold">Foto do comprovante</span>
                <span className="block text-xs text-muted-foreground">Câmera ou arquivo</span>
              </span>
            </Button>
            <Button
              variant="outline"
              className="h-auto justify-start gap-3 py-4"
              onClick={() => {
                setEscolha(false);
                setLeitor(true);
              }}
            >
              <QrCode className="size-5 text-primary" />
              <span className="text-left">
                <span className="block text-sm font-semibold">
                  Ler nota (QR / código de barras)
                </span>
                <span className="block text-xs text-muted-foreground">
                  Captura a chave de acesso
                </span>
              </span>
            </Button>
            <Button
              variant="ghost"
              onClick={() => {
                setEscolha(false);
                setForm({ ...FORM_VAZIO });
                setEditandoId(null);
              }}
            >
              Preencher manualmente
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <LeitorNota open={leitor} onOpenChange={setLeitor} onLido={aoLerCodigo} />

      {/* Formulário */}
      <Dialog
        open={!!form}
        onOpenChange={(v) => {
          if (!v) {
            setForm(null);
            setEditandoId(null);
            setFotosPendentes([]);
            setItensLidos([]);
          }
        }}
      >
        <DialogContent className="max-h-[90vh] max-w-lg overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editandoId ? "Editar nota" : "Nova nota"}</DialogTitle>
          </DialogHeader>
          {form && (
            <div className="space-y-3">
              {form.chave_acesso && (
                <div className="rounded-xl border bg-muted/40 p-3 text-xs">
                  <p className="font-medium">Chave de acesso</p>
                  <p className="break-all text-muted-foreground">
                    {formatarChave(form.chave_acesso)}
                  </p>
                  <p className="mt-1 text-muted-foreground">
                    {form.status_captura === "auto"
                      ? "Dados obtidos automaticamente"
                      : "Preencher manualmente"}
                  </p>
                </div>
              )}
              <div className="grid gap-3 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label>Estabelecimento</Label>
                  <Input
                    value={form.estabelecimento}
                    onChange={(e) => setForm({ ...form, estabelecimento: e.target.value })}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label>Data da compra</Label>
                  <Input
                    type="date"
                    value={form.data_compra}
                    onChange={(e) => setForm({ ...form, data_compra: e.target.value })}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label>Valor</Label>
                  <Input
                    inputMode="decimal"
                    value={form.valor_total}
                    onChange={(e) => setForm({ ...form, valor_total: e.target.value })}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label>Categoria</Label>
                  <Select
                    value={form.categoria}
                    onValueChange={(v) => setForm({ ...form, categoria: v })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {CATEGORIAS.map((c) => (
                        <SelectItem key={c} value={c}>
                          {c.charAt(0).toUpperCase() + c.slice(1)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label>Garantia</Label>
                  <Select
                    value={form.garantia_meses}
                    onValueChange={(v) => setForm({ ...form, garantia_meses: v })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {PRAZOS_GARANTIA.map((p) => (
                        <SelectItem key={p.meses} value={String(p.meses)}>
                          {p.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label>Fim da garantia</Label>
                  <Input
                    readOnly
                    value={
                      calcularFimGarantia(form.data_compra, Number(form.garantia_meses) || 0)
                        ? formatDate(
                            calcularFimGarantia(
                              form.data_compra,
                              Number(form.garantia_meses) || 0,
                            )!,
                          )
                        : "—"
                    }
                  />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label>Descrição</Label>
                <Input
                  value={form.descricao}
                  onChange={(e) => setForm({ ...form, descricao: e.target.value })}
                />
              </div>
              <div className="space-y-1.5">
                <Label>Cartão ou conta usada na compra</Label>
                <Select
                  value={form.pagamento || "nenhum"}
                  onValueChange={(v) => setForm({ ...form, pagamento: v === "nenhum" ? "" : v })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione (opcional)" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="nenhum">Não informar</SelectItem>
                    {(cartoesLista as any[]).map((c) => (
                      <SelectItem key={c.id} value={`cartao:${c.id}`}>
                        Cartão: {c.apelido || c.bancos?.nome || "Cartão"}
                        {c.final ? ` •${c.final}` : ""}
                      </SelectItem>
                    ))}
                    {(bancosLista as any[]).map((b) => (
                      <SelectItem key={b.id} value={`banco:${b.id}`}>
                        Conta: {b.nome}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Observações</Label>
                <Textarea
                  rows={2}
                  value={form.observacoes}
                  onChange={(e) => setForm({ ...form, observacoes: e.target.value })}
                />
              </div>

              {itensLidos.length > 0 && (
                <div className="rounded-xl border p-3 space-y-3">
                  <p className="text-xs font-semibold">
                    {itensLidos.length} {itensLidos.length === 1 ? "item identificado" : "itens identificados"}
                  </p>
                  <div className="max-h-64 space-y-2 overflow-y-auto pr-1">
                    {itensLidos.map((item, idx) => (
                      <div key={idx} className="rounded-lg border bg-muted/30 p-2.5 space-y-1.5">
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0 flex-1">
                            <p className="text-xs font-medium truncate">
                              {item.quantidade}x {item.descricao}
                            </p>
                            {item.categoria && (
                              <Badge variant="secondary" className="mt-0.5 text-[10px] h-4 px-1.5">
                                {item.categoria}{item.subcategoria ? ` / ${item.subcategoria}` : ""}
                              </Badge>
                            )}
                          </div>
                          <span className="shrink-0 text-xs font-semibold tabular-nums">
                            {formatBRL(item.valor_total)}
                          </span>
                        </div>
                        <label className="flex items-center gap-2 cursor-pointer select-none">
                          <input
                            type="checkbox"
                            checked={!!item.deprecia}
                            onChange={(e) =>
                              setItensLidos((prev) =>
                                prev.map((it, i) =>
                                  i === idx ? { ...it, deprecia: e.target.checked } : it,
                                ),
                              )
                            }
                            className="size-3.5 accent-primary"
                          />
                          <span className="text-[11px] text-muted-foreground">
                            Este item deprecia?
                          </span>
                        </label>
                        {item.deprecia && (
                          <div className="flex items-center gap-2">
                            <label className="text-[11px] text-muted-foreground shrink-0">
                              Vida útil (meses):
                            </label>
                            <input
                              type="number"
                              min={1}
                              value={item.meses_depreciacao ?? ""}
                              onChange={(e) =>
                                setItensLidos((prev) =>
                                  prev.map((it, i) =>
                                    i === idx
                                      ? { ...it, meses_depreciacao: Number(e.target.value) || null }
                                      : it,
                                  ),
                                )
                              }
                              placeholder="Ex: 36"
                              className="w-20 rounded border bg-background px-2 py-0.5 text-xs"
                            />
                            {item.meses_depreciacao && (
                              <span className="text-[10px] text-muted-foreground">
                                ≈ {(item.meses_depreciacao / 12).toFixed(1)} ano(s)
                              </span>
                            )}
                          </div>
                        )}
                        {item.deprecia && (
                          <PresetsVidaUtil
                            valor={item.meses_depreciacao}
                            sugerido={classificarItemNota(item.descricao).sugestaoDepreciacao?.meses}
                            onEscolher={(m) =>
                              setItensLidos((prev) =>
                                prev.map((it, i) => (i === idx ? { ...it, meses_depreciacao: m } : it)),
                              )
                            }
                          />
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {fotosPendentes.length > 0 && (
                <p className="text-xs text-muted-foreground">
                  {drive.data?.connected
                    ? `${fotosPendentes.length} arquivo(s) serão enviados ao Google Drive ao salvar.`
                    : `${fotosPendentes.length} arquivo(s) serão guardados no site ao salvar.`}
                </p>
              )}

              <Button
                className="w-full"
                onClick={() => salvar.mutate(form)}
                disabled={salvar.isPending}
              >
                {salvar.isPending ? "Salvando…" : "Salvar nota"}
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Detalhe */}
      <Dialog open={!!notaDetalhe} onOpenChange={(v) => !v && setDetalhe(null)}>
        <DialogContent className="max-h-[90vh] max-w-lg overflow-y-auto">
          {notaDetalhe && (
            <>
              <DialogHeader>
                <DialogTitle>
                  {notaDetalhe.estabelecimento || notaDetalhe.descricao || "Nota fiscal"}
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="flex flex-wrap items-center gap-2 text-sm">
                  <Badge variant="secondary">{formatDate(notaDetalhe.data_compra)}</Badge>
                  <Badge variant="secondary">{formatBRL(Number(notaDetalhe.valor_total))}</Badge>
                  <SeloGarantia fim={notaDetalhe.garantia_fim} />
                </div>

                {notaDetalhe.chave_acesso && (
                  <div className="rounded-xl border p-3 text-xs">
                    <p className="mb-1 font-medium">Chave de acesso</p>
                    <p className="break-all text-muted-foreground">
                      {formatarChave(notaDetalhe.chave_acesso)}
                    </p>
                    <div className="mt-2 flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        className="gap-1"
                        onClick={() => {
                          void navigator.clipboard.writeText(notaDetalhe.chave_acesso!);
                          toast.success("Chave copiada.");
                        }}
                      >
                        <Copy className="size-3.5" /> Copiar
                      </Button>
                      <a
                        href={notaDetalhe.url_consulta ?? linkConsulta(notaDetalhe.chave_acesso)}
                        target="_blank"
                        rel="noreferrer"
                      >
                        <Button size="sm" variant="outline" className="gap-1">
                          <ExternalLink className="size-3.5" /> Consultar
                        </Button>
                      </a>
                    </div>
                  </div>
                )}

                <div>
                  <p className="mb-2 text-xs font-medium">Comprovantes</p>
                  <div className="flex flex-wrap gap-2">
                    {(notaDetalhe.nota_arquivos ?? []).map((a) => (
                      <a
                        key={a.id}
                        href={a.link ?? "#"}
                        target="_blank"
                        rel="noreferrer"
                        className="size-20 overflow-hidden rounded-xl border bg-muted"
                      >
                        {a.thumbnail_link ? (
                          <img
                            src={a.thumbnail_link}
                            alt={a.nome ?? "Comprovante"}
                            className="size-full object-cover"
                            loading="lazy"
                          />
                        ) : (
                          <span className="flex size-full items-center justify-center text-[10px] text-muted-foreground">
                            {a.nome ?? "arquivo"}
                          </span>
                        )}
                      </a>
                    ))}
                    <Button
                      variant="outline"
                      className="size-20 flex-col gap-1 text-[11px]"
                      disabled={anexar.isPending}
                      onClick={() => {
                        notaAlvoUpload.current = notaDetalhe.id;
                        fileRef.current?.click();
                      }}
                    >
                      <Upload className="size-4" /> Adicionar
                    </Button>
                  </div>
                </div>

                {(notaDetalhe.nota_itens ?? []).length > 0 && (
                  <div>
                    <p className="mb-2 text-xs font-medium">Itens</p>
                    <div className="space-y-2">
                      {(notaDetalhe.nota_itens ?? []).map((i) => {
                        const iDepreciavel = !!(i as any).deprecia && (i as any).meses_depreciacao;
                        const dep = iDepreciavel
                          ? calcularDepreciacao({
                              valorOriginal: Number(i.valor_total ?? 0),
                              dataCompra: notaDetalhe.data_compra,
                              mesesVidaUtil: Number((i as any).meses_depreciacao),
                            })
                          : null;
                        return (
                          <div key={i.id} className="rounded-lg border bg-muted/20 px-2.5 py-2 space-y-1">
                            <div className="flex items-start justify-between gap-2">
                              <div className="min-w-0 flex-1">
                                <p className="text-xs truncate">
                                  {Number(i.quantidade)}x {i.descricao}
                                </p>
                                {(i as any).categoria && (
                                  <Badge variant="secondary" className="mt-0.5 h-4 text-[10px] px-1.5">
                                    {(i as any).categoria}
                                    {(i as any).subcategoria ? ` / ${(i as any).subcategoria}` : ""}
                                  </Badge>
                                )}
                              </div>
                              <span className="shrink-0 text-xs font-semibold tabular-nums">
                                {formatBRL(Number(i.valor_total))}
                              </span>
                            </div>
                            {dep && (
                              <p className="text-[11px] text-muted-foreground">
                                {dep.totalmenteDepreciado
                                  ? "Totalmente depreciado"
                                  : `Valor atual: ${formatBRL(dep.valorAtual)} · ${dep.percentualDepreciado.toFixed(0)}% depreciado`}
                              </p>
                            )}
                            <DepreciacaoItem item={i as any} />
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {(notaDetalhe as any).pagamento_id && (
                  <p className="text-xs text-muted-foreground">
                    Paga com: {nomePagamento((notaDetalhe as any).pagamento_tipo, (notaDetalhe as any).pagamento_id)}
                  </p>
                )}
                {notaDetalhe.observacoes && (
                  <p className="text-xs text-muted-foreground">{notaDetalhe.observacoes}</p>
                )}

                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    className="flex-1 gap-2"
                    onClick={() => {
                      setDetalhe(null);
                      setEditandoId(notaDetalhe.id);
                      setForm({
                        estabelecimento: notaDetalhe.estabelecimento ?? "",
                        descricao: notaDetalhe.descricao ?? "",
                        data_compra: notaDetalhe.data_compra,
                        valor_total: String(notaDetalhe.valor_total ?? ""),
                        categoria: notaDetalhe.categoria ?? "outros",
                        garantia_meses: String(notaDetalhe.garantia_meses ?? 0),
                        observacoes: notaDetalhe.observacoes ?? "",
                        pagamento: (notaDetalhe as any).pagamento_id
                          ? `${(notaDetalhe as any).pagamento_tipo}:${(notaDetalhe as any).pagamento_id}`
                          : "",
                        chave_acesso: notaDetalhe.chave_acesso ?? "",
                        url_consulta: notaDetalhe.url_consulta ?? "",
                        uf: notaDetalhe.uf ?? "",
                        status_captura: notaDetalhe.status_captura ?? "manual",
                      });
                    }}
                  >
                    <ShieldCheck className="size-4" /> Editar
                  </Button>
                  <Button
                    variant="destructive"
                    className="gap-2"
                    onClick={() => excluir.mutate(notaDetalhe.id)}
                  >
                    <Trash2 className="size-4" /> Excluir
                  </Button>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </AppLayout>
  );
}

function fileParaBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = String(reader.result ?? "");
      resolve(result.slice(result.indexOf(",") + 1));
    };
    reader.onerror = () => reject(new Error("Não foi possível ler o arquivo."));
    reader.readAsDataURL(file);
  });
}
