import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useRef, useState } from "react";
import {
  Car,
  Download,
  FileHeart,
  Image as ImageIcon,
  MapPin,
  PawPrint,
  Receipt,
  Share2,
  ShoppingCart,
  Sparkles,
  Wallet,
} from "lucide-react";
import { toast } from "sonner";
import { useServerFn } from "@tanstack/react-start";
import { Input } from "@/components/ui/input";
import { resumoFinanceiroIA } from "@/lib/lancamento-ia.functions";
import { useResumoFinanceiroMes } from "@/hooks/useResumoFinanceiroMes";

import { AppLayout } from "@/components/AppLayout";
import { ConviteAmigosBanner, useConvitesAmigos } from "@/components/ConviteAmigosBanner";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useDespesas, useReceitas, useVeiculos } from "@/hooks/useFinance";
import { useCotacao } from "@/hooks/useCotacao";
import { useModulosGlobais, useProfile } from "@/hooks/useAuthData";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";
import { currentMonthKey, formatBRL, formatDate, monthKey, monthLabel, toBRL } from "@/lib/format";
import { alertasDosVeiculos } from "@/lib/veiculo-alertas";

export const Route = createFileRoute("/_authenticated/compartilhar")({
  head: () => ({
    meta: [
      { title: "Compartilhar — Control ALL" },
      {
        name: "description",
        content:
          "Gere um resumo ou imagem de finanças, lista de compras, notas fiscais ou veículos para compartilhar no WhatsApp ou salvar.",
      },
      { property: "og:title", content: "Compartilhar — Control ALL" },
      {
        property: "og:description",
        content: "Resumos prontos para compartilhar no WhatsApp ou salvar.",
      },
    ],
  }),
  component: CompartilharPage,
});

/** Abre o WhatsApp com o texto pronto, ou tenta o compartilhamento nativo do
 * aparelho quando disponível (mobile). Mesmo padrão já usado pra finanças. */
async function compartilharTexto(texto: string, titulo: string) {
  const nav = navigator as Navigator & { canShare?: (d: any) => boolean };
  if (nav.canShare?.({ text: texto })) {
    try {
      await navigator.share({ text: texto, title: titulo });
      return;
    } catch {
      /* cancelado pelo usuário — cai no fallback do WhatsApp Web */
    }
  }
  window.open(`https://wa.me/?text=${encodeURIComponent(texto)}`, "_blank", "noopener");
}

async function copiarTexto(texto: string) {
  try {
    await navigator.clipboard.writeText(texto);
    toast.success("Texto copiado");
  } catch {
    toast.error("Não foi possível copiar — tente novamente.");
  }
}

/** Desenha um texto (título + linhas) num canvas com o mesmo visual usado em
 * Finanças, pra gerar uma imagem pronta a partir de um resumo em texto. */
function desenharTextoEmCanvas(
  canvas: HTMLCanvasElement | null,
  titulo: string,
  linhas: string[],
): HTMLCanvasElement | null {
  if (!canvas) return null;
  const ctx = canvas.getContext("2d");
  if (!ctx) return null;
  const W = (canvas.width = 1080);
  const linhaAltura = 54;
  const H = (canvas.height = Math.max(600, 260 + linhas.length * linhaAltura + 120));

  const grad = ctx.createLinearGradient(0, 0, W, H);
  grad.addColorStop(0, "#0f172a");
  grad.addColorStop(1, "#1e3a8a");
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, W, H);

  ctx.fillStyle = "#ffffff";
  ctx.font = "800 56px system-ui, sans-serif";
  ctx.fillText(titulo, 80, 140);

  ctx.fillStyle = "rgba(255,255,255,0.08)";
  ctx.beginPath();
  ctx.roundRect(80, 200, W - 160, H - 200 - 100, 24);
  ctx.fill();

  ctx.font = "500 30px system-ui, sans-serif";
  let y = 260;
  for (const linha of linhas) {
    ctx.fillStyle = "rgba(255,255,255,0.92)";
    ctx.fillText(linha, 120, y);
    y += linhaAltura;
  }

  ctx.fillStyle = "rgba(255,255,255,0.5)";
  ctx.font = "400 24px system-ui, sans-serif";
  ctx.fillText("Gerado pelo Control ALL", 80, H - 50);

  return canvas;
}

/** Mesmas três ações de compartilhamento por imagem do card de Finanças
 * (Compartilhar, Copiar imagem, Baixar imagem), reaproveitadas nas demais
 * abas a partir do texto-resumo que cada uma já monta. */
function ImageShareActions({
  titulo,
  texto,
  arquivo,
}: {
  titulo: string;
  texto: string;
  arquivo: string;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const linhas = texto.split("\n").filter((l) => l.trim().length > 0);

  function desenhar() {
    return desenharTextoEmCanvas(canvasRef.current, titulo, linhas);
  }

  async function baixar() {
    const canvas = desenhar();
    if (!canvas) return;
    const url = canvas.toDataURL("image/png");
    const a = document.createElement("a");
    a.href = url;
    a.download = `${arquivo}.png`;
    a.click();
    toast.success("Imagem baixada");
  }

  async function compartilhar() {
    const canvas = desenhar();
    if (!canvas) return;
    canvas.toBlob(async (blob) => {
      if (!blob) return;
      const file = new File([blob], `${arquivo}.png`, { type: "image/png" });
      const nav = navigator as Navigator & { canShare?: (d: any) => boolean };
      if (nav.canShare?.({ files: [file] })) {
        try {
          await navigator.share({ files: [file], title: titulo });
          return;
        } catch {
          /* cancelado pelo usuário */
        }
      }
      window.open(`https://wa.me/?text=${encodeURIComponent(texto)}`, "_blank", "noopener");
    }, "image/png");
  }

  async function copiarParaClipboard() {
    const canvas = desenhar();
    if (!canvas) return;
    canvas.toBlob(async (blob) => {
      if (!blob) return;
      try {
        if (navigator.clipboard && window.ClipboardItem) {
          const item = new ClipboardItem({ "image/png": blob });
          await navigator.clipboard.write([item]);
          toast.success("Imagem copiada para a área de transferência! Cole no WhatsApp.");
        } else {
          toast.error("Seu navegador não suporta copiar imagens diretamente.");
        }
      } catch {
        toast.error("Não foi possível copiar a imagem.");
      }
    }, "image/png");
  }

  return (
    <>
      <Button className="w-full" onClick={compartilhar}>
        <Share2 className="size-4" /> Compartilhar
      </Button>
      <Button variant="secondary" className="w-full" onClick={copiarParaClipboard}>
        <ImageIcon className="size-4" /> Copiar imagem
      </Button>
      <Button variant="outline" className="w-full" onClick={baixar}>
        <Download className="size-4" /> Baixar imagem
      </Button>
      <canvas ref={canvasRef} className="hidden" aria-hidden="true" />
    </>
  );
}

/** Item 16: banner verde de convite; some quando os convites acabam. */
function ConviteCompartilhar() {
  const { temConviteDisponivel, isLoading } = useConvitesAmigos();
  if (isLoading || !temConviteDisponivel) return null;
  return <ConviteAmigosBanner className="mb-4" />;
}

function CompartilharPage() {
  const { habilitado } = useModulosGlobais();

  return (
    <AppLayout title="Compartilhar" description="Gere um resumo pronto para compartilhar">
      <ConviteCompartilhar />
      <Tabs defaultValue="financas" className="space-y-4">
        <TabsList className="flex h-auto flex-wrap gap-1">
          <TabsTrigger value="financas" className="gap-1.5 text-xs">
            <Wallet className="size-3.5" /> Finanças
          </TabsTrigger>
          {habilitado("lista") && (
            <TabsTrigger value="lista" className="gap-1.5 text-xs">
              <ShoppingCart className="size-3.5" /> Lista de compras
            </TabsTrigger>
          )}
          {habilitado("notas") && (
            <TabsTrigger value="notas" className="gap-1.5 text-xs">
              <Receipt className="size-3.5" /> Notas fiscais
            </TabsTrigger>
          )}
          {habilitado("veiculo") && (
            <TabsTrigger value="veiculos" className="gap-1.5 text-xs">
              <Car className="size-3.5" /> Veículos
            </TabsTrigger>
          )}
          {habilitado("pet") && (
            <TabsTrigger value="pet" className="gap-1.5 text-xs">
              <PawPrint className="size-3.5" /> Pet
            </TabsTrigger>
          )}
          {habilitado("onde_esta") && (
            <TabsTrigger value="onde-esta" className="gap-1.5 text-xs">
              <MapPin className="size-3.5" /> Onde está?
            </TabsTrigger>
          )}
          {habilitado("exames") && (
            <TabsTrigger value="exames" className="gap-1.5 text-xs">
              <FileHeart className="size-3.5" /> Exames
            </TabsTrigger>
          )}
          <TabsTrigger value="inteligente" className="gap-1.5 text-xs">
            <Sparkles className="size-3.5" /> Resumo inteligente
          </TabsTrigger>
        </TabsList>

        <TabsContent value="financas">
          <FinancasShareCard />
        </TabsContent>
        {habilitado("lista") && (
          <TabsContent value="lista">
            <ListaComprasShareCard />
          </TabsContent>
        )}
        {habilitado("notas") && (
          <TabsContent value="notas">
            <NotasFiscaisShareCard />
          </TabsContent>
        )}
        {habilitado("veiculo") && (
          <TabsContent value="veiculos">
            <VeiculosShareCard />
          </TabsContent>
        )}
        {habilitado("pet") && (
          <TabsContent value="pet">
            <PetShareCard />
          </TabsContent>
        )}
        {habilitado("onde_esta") && (
          <TabsContent value="onde-esta">
            <OndeEstaShareCard />
          </TabsContent>
        )}
        {habilitado("exames") && (
          <TabsContent value="exames">
            <ExamesShareCard />
          </TabsContent>
        )}
        <TabsContent value="inteligente">
          <ResumoInteligenteShareCard />
        </TabsContent>
      </Tabs>
    </AppLayout>
  );
}

/** ─── Finanças: gera uma imagem (canvas) do resumo do mês, como já era antes. ─── */
function FinancasShareCard() {
  const cotacao = useCotacao();
  const { data: perfil } = useProfile();
  const { data: receitas = [] } = useReceitas();
  const { data: despesas = [] } = useDespesas();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [mes, setMes] = useState(currentMonthKey());

  const meses = useMemo(() => {
    const set = new Set<string>([currentMonthKey()]);
    receitas.forEach((r: any) => set.add(monthKey(r.data_recebimento)));
    despesas.forEach((d: any) => set.add(monthKey(d.data_compra)));
    return [...set].sort().reverse();
  }, [receitas, despesas]);

  const resumo = useMemo(() => {
    const rec = receitas
      .filter((r: any) => monthKey(r.data_recebimento) === mes)
      .reduce((s: number, r: any) => s + toBRL(Number(r.valor), r.moeda, cotacao), 0);

    const parcelasMes = despesas.flatMap((d: any) =>
      (d.parcelas ?? [])
        .filter((p: any) => monthKey(p.vencimento) === mes)
        .map((p: any) => ({ ...p, categoria: d.categoria, moeda: d.moeda })),
    );
    const desp = parcelasMes.reduce(
      (s: number, p: any) => s + toBRL(Number(p.valor), p.moeda, cotacao),
      0,
    );
    const porCategoria = Object.entries(
      parcelasMes.reduce((acc: Record<string, number>, p: any) => {
        acc[p.categoria] = (acc[p.categoria] ?? 0) + toBRL(Number(p.valor), p.moeda, cotacao);
        return acc;
      }, {}),
    )
      .sort((a, b) => (b[1] as number) - (a[1] as number))
      .slice(0, 5) as [string, number][];

    return { rec, desp, saldo: rec - desp, porCategoria };
  }, [receitas, despesas, mes, cotacao]);

  function desenhar(): HTMLCanvasElement | null {
    const canvas = canvasRef.current;
    if (!canvas) return null;
    const ctx = canvas.getContext("2d");
    if (!ctx) return null;
    const W = (canvas.width = 1080);
    const H = (canvas.height = 1350);

    const grad = ctx.createLinearGradient(0, 0, W, H);
    grad.addColorStop(0, "#0f172a");
    grad.addColorStop(1, "#1e3a8a");
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, W, H);

    ctx.fillStyle = "rgba(255,255,255,0.75)";
    ctx.font = "600 34px system-ui, sans-serif";
    ctx.fillText("Resumo financeiro do casal", 80, 140);
    ctx.fillStyle = "#ffffff";
    ctx.font = "800 84px system-ui, sans-serif";
    ctx.fillText(monthLabel(mes).toUpperCase(), 80, 240);

    const box = (y: number, label: string, value: string, color: string) => {
      ctx.fillStyle = "rgba(255,255,255,0.08)";
      ctx.beginPath();
      ctx.roundRect(80, y, W - 160, 150, 28);
      ctx.fill();
      ctx.fillStyle = "rgba(255,255,255,0.7)";
      ctx.font = "500 30px system-ui, sans-serif";
      ctx.fillText(label, 120, y + 58);
      ctx.fillStyle = color;
      ctx.font = "800 56px system-ui, sans-serif";
      ctx.fillText(value, 120, y + 118);
    };

    box(320, "Receitas do mês", formatBRL(resumo.rec), "#4ade80");
    box(500, "Despesas do mês", formatBRL(resumo.desp), "#f87171");
    box(680, "Saldo", formatBRL(resumo.saldo), resumo.saldo >= 0 ? "#38bdf8" : "#fbbf24");

    ctx.fillStyle = "rgba(255,255,255,0.75)";
    ctx.font = "600 32px system-ui, sans-serif";
    ctx.fillText("Maiores categorias", 80, 900);

    let y = 960;
    resumo.porCategoria.forEach(([cat, val]) => {
      ctx.fillStyle = "rgba(255,255,255,0.9)";
      ctx.font = "500 30px system-ui, sans-serif";
      ctx.fillText(cat, 80, y);
      ctx.textAlign = "right";
      ctx.fillText(formatBRL(val), W - 80, y);
      ctx.textAlign = "left";
      y += 60;
    });

    ctx.fillStyle = "rgba(255,255,255,0.5)";
    ctx.font = "400 26px system-ui, sans-serif";
    ctx.fillText(`Gerado por ${perfil?.nome ?? "Control ALL"}`, 80, H - 80);

    return canvas;
  }

  async function baixar() {
    const canvas = desenhar();
    if (!canvas) return;
    const url = canvas.toDataURL("image/png");
    const a = document.createElement("a");
    a.href = url;
    a.download = `resumo-${mes}.png`;
    a.click();
    toast.success("Imagem baixada");
  }

  async function compartilhar() {
    const canvas = desenhar();
    if (!canvas) return;
    canvas.toBlob(async (blob) => {
      if (!blob) return;
      const file = new File([blob], `resumo-${mes}.png`, { type: "image/png" });
      const nav = navigator as Navigator & { canShare?: (d: any) => boolean };
      if (nav.canShare?.({ files: [file] })) {
        try {
          await navigator.share({ files: [file], title: `Resumo ${monthLabel(mes)}` });
        } catch {
          /* cancelado pelo usuário */
        }
      } else {
        const texto = `Resumo ${monthLabel(mes)}%0AReceitas: ${formatBRL(resumo.rec)}%0ADespesas: ${formatBRL(resumo.desp)}%0ASaldo: ${formatBRL(resumo.saldo)}`;
        window.open(`https://wa.me/?text=${texto}`, "_blank", "noopener");
      }
    }, "image/png");
  }

  async function copiarParaClipboard() {
    const canvas = desenhar();
    if (!canvas) return;
    canvas.toBlob(async (blob) => {
      if (!blob) return;
      try {
        if (navigator.clipboard && window.ClipboardItem) {
          const item = new ClipboardItem({ "image/png": blob });
          await navigator.clipboard.write([item]);
          toast.success("Imagem copiada para a área de transferência! Cole no WhatsApp.");
        } else {
          toast.error("Seu navegador não suporta copiar imagens diretamente.");
        }
      } catch {
        toast.error("Não foi possível copiar a imagem.");
      }
    }, "image/png");
  }

  return (
    <div className="grid gap-4 lg:grid-cols-[280px_1fr]">
      <Card>
        <CardContent className="space-y-4 p-4">
          <Select value={mes} onValueChange={setMes}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {meses.map((m) => (
                <SelectItem key={m} value={m}>
                  {monthLabel(m)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button className="w-full" onClick={compartilhar}>
            <Share2 className="size-4" /> Compartilhar
          </Button>
          <Button variant="secondary" className="w-full" onClick={copiarParaClipboard}>
            <ImageIcon className="size-4" /> Copiar imagem
          </Button>
          <Button variant="outline" className="w-full" onClick={baixar}>
            <Download className="size-4" /> Baixar imagem
          </Button>
          <p className="text-xs text-muted-foreground">
            A imagem inclui receitas, despesas, saldo e as maiores categorias do mês selecionado.
          </p>
        </CardContent>
      </Card>

      <Card className="overflow-hidden">
        <CardContent className="space-y-4 p-6">
          <div className="flex items-center gap-2 text-sm font-semibold">
            <ImageIcon className="size-4" /> Prévia do resumo — {monthLabel(mes)}
          </div>
          <div className="grid gap-3 sm:grid-cols-3">
            <Preview label="Receitas" value={formatBRL(resumo.rec)} tone="text-success" />
            <Preview label="Despesas" value={formatBRL(resumo.desp)} tone="text-destructive" />
            <Preview
              label="Saldo"
              value={formatBRL(resumo.saldo)}
              tone={resumo.saldo >= 0 ? "text-primary" : "text-destructive"}
            />
          </div>
          <div className="space-y-1.5">
            {resumo.porCategoria.map(([cat, val]) => (
              <div key={cat} className="flex justify-between text-sm">
                <span className="text-muted-foreground">{cat}</span>
                <span className="font-medium">{formatBRL(val)}</span>
              </div>
            ))}
            {resumo.porCategoria.length === 0 && (
              <p className="text-sm text-muted-foreground">Sem lançamentos neste mês.</p>
            )}
          </div>
        </CardContent>
      </Card>

      <canvas ref={canvasRef} className="hidden" aria-hidden="true" />
    </div>
  );
}

/** ─── Lista de compras: resumo em texto dos itens pendentes, pronto pra WhatsApp. ─── */
function ListaComprasShareCard() {
  const { data: itens = [], isLoading } = useQuery({
    queryKey: ["lista-compras-compartilhar"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("lista_compras")
        .select("nome,quantidade,comprado")
        .order("comprado")
        .order("created_at", { ascending: false })
        .limit(200);
      if (error) throw error;
      return data ?? [];
    },
  });

  const pendentes = useMemo(() => (itens as any[]).filter((i) => !i.comprado), [itens]);

  const texto = useMemo(() => {
    if (pendentes.length === 0) return "Lista de compras\n\nNenhum item pendente. 🎉";
    const linhas = pendentes.map(
      (i: any) => `• ${i.nome}${i.quantidade > 1 ? ` (${i.quantidade}x)` : ""}`,
    );
    return `Lista de compras (${pendentes.length} pendente${pendentes.length > 1 ? "s" : ""})\n\n${linhas.join("\n")}`;
  }, [pendentes]);

  return (
    <div className="grid gap-4 lg:grid-cols-[280px_1fr]">
      <Card>
        <CardContent className="space-y-4 p-4">
          <Button
            variant="outline"
            className="w-full"
            disabled={isLoading}
            onClick={() => compartilharTexto(texto, "Lista de compras")}
          >
            <Share2 className="size-4" /> Compartilhar texto
          </Button>
          <Button variant="outline" className="w-full" onClick={() => copiarTexto(texto)}>
            <ImageIcon className="size-4" /> Copiar texto
          </Button>
          <ImageShareActions titulo="Lista de compras" texto={texto} arquivo="lista-compras" />
          <p className="text-xs text-muted-foreground">
            Envia os itens ainda pendentes de compra, com quantidade.
          </p>
        </CardContent>
      </Card>
      <Card>
        <CardContent className="space-y-2 p-6">
          <div className="flex items-center gap-2 text-sm font-semibold">
            <ShoppingCart className="size-4" /> Prévia
          </div>
          <pre className="whitespace-pre-wrap rounded-lg bg-muted/50 p-3 text-sm">{texto}</pre>
        </CardContent>
      </Card>
    </div>
  );
}

/** ─── Notas fiscais: resumo em texto de quantidade e total gasto no mês. ─── */
function NotasFiscaisShareCard() {
  const [mes, setMes] = useState(currentMonthKey());
  const { data: notas = [], isLoading } = useQuery({
    queryKey: ["notas-fiscais-compartilhar"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("notas_fiscais")
        .select("estabelecimento,data_compra,valor_total")
        .order("data_compra", { ascending: false })
        .limit(500);
      if (error) throw error;
      return data ?? [];
    },
  });

  const meses = useMemo(() => {
    const set = new Set<string>([currentMonthKey()]);
    (notas as any[]).forEach((n) => set.add(monthKey(n.data_compra)));
    return [...set].sort().reverse();
  }, [notas]);

  const doMes = useMemo(
    () => (notas as any[]).filter((n) => monthKey(n.data_compra) === mes),
    [notas, mes],
  );
  const total = useMemo(
    () => doMes.reduce((s, n: any) => s + Number(n.valor_total ?? 0), 0),
    [doMes],
  );

  const texto = useMemo(() => {
    if (doMes.length === 0) return `Notas fiscais — ${monthLabel(mes)}\n\nNenhuma nota registrada.`;
    const top = [...doMes]
      .sort((a: any, b: any) => Number(b.valor_total ?? 0) - Number(a.valor_total ?? 0))
      .slice(0, 5)
      .map((n: any) => `• ${n.estabelecimento || "Sem nome"}: ${formatBRL(Number(n.valor_total ?? 0))}`);
    return `Notas fiscais — ${monthLabel(mes)}\n\n${doMes.length} nota${doMes.length > 1 ? "s" : ""} · Total: ${formatBRL(total)}\n\nMaiores compras:\n${top.join("\n")}`;
  }, [doMes, mes, total]);

  return (
    <div className="grid gap-4 lg:grid-cols-[280px_1fr]">
      <Card>
        <CardContent className="space-y-4 p-4">
          <Select value={mes} onValueChange={setMes}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {meses.map((m) => (
                <SelectItem key={m} value={m}>
                  {monthLabel(m)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button
            variant="outline"
            className="w-full"
            disabled={isLoading}
            onClick={() => compartilharTexto(texto, "Notas fiscais")}
          >
            <Share2 className="size-4" /> Compartilhar texto
          </Button>
          <Button variant="outline" className="w-full" onClick={() => copiarTexto(texto)}>
            <ImageIcon className="size-4" /> Copiar texto
          </Button>
          <ImageShareActions titulo="Notas fiscais" texto={texto} arquivo={`notas-fiscais-${mes}`} />
          <p className="text-xs text-muted-foreground">
            Não inclui as fotos das notas — só o resumo em texto (quantidade, total e maiores
            compras do mês).
          </p>
        </CardContent>
      </Card>
      <Card>
        <CardContent className="space-y-2 p-6">
          <div className="flex items-center gap-2 text-sm font-semibold">
            <Receipt className="size-4" /> Prévia
          </div>
          <pre className="whitespace-pre-wrap rounded-lg bg-muted/50 p-3 text-sm">{texto}</pre>
        </CardContent>
      </Card>
    </div>
  );
}

/** ─── Veículos: resumo em texto com alertas ativos (óleo, IPVA, seguro). ─── */
function VeiculosShareCard() {
  const { data: veiculos = [], isLoading } = useVeiculos();

  const alertas = useMemo(() => alertasDosVeiculos(veiculos as any[]), [veiculos]);

  const texto = useMemo(() => {
    if ((veiculos as any[]).length === 0) return "Veículos\n\nNenhum veículo cadastrado.";
    const linhasVeiculos = (veiculos as any[]).map((v: any) => {
      const km = v.km_atual != null ? ` · ${Number(v.km_atual).toLocaleString("pt-BR")} km` : "";
      return `• ${v.nome}${km}`;
    });
    const linhasAlertas = alertas.map((a) => `⚠️ ${a.veiculoNome}: ${a.mensagem}`);
    return [
      `Veículos (${(veiculos as any[]).length})`,
      "",
      linhasVeiculos.join("\n"),
      ...(linhasAlertas.length ? ["", "Alertas:", linhasAlertas.join("\n")] : []),
    ].join("\n");
  }, [veiculos, alertas]);

  return (
    <div className="grid gap-4 lg:grid-cols-[280px_1fr]">
      <Card>
        <CardContent className="space-y-4 p-4">
          <Button
            variant="outline"
            className="w-full"
            disabled={isLoading}
            onClick={() => compartilharTexto(texto, "Veículos")}
          >
            <Share2 className="size-4" /> Compartilhar texto
          </Button>
          <Button variant="outline" className="w-full" onClick={() => copiarTexto(texto)}>
            <ImageIcon className="size-4" /> Copiar texto
          </Button>
          <ImageShareActions titulo="Veículos" texto={texto} arquivo="veiculos" />
          <p className="text-xs text-muted-foreground">
            Inclui os veículos cadastrados e os alertas ativos (troca de óleo, IPVA, seguro).
          </p>
        </CardContent>
      </Card>
      <Card>
        <CardContent className="space-y-2 p-6">
          <div className="flex items-center gap-2 text-sm font-semibold">
            <Car className="size-4" /> Prévia
          </div>
          <pre className="whitespace-pre-wrap rounded-lg bg-muted/50 p-3 text-sm">{texto}</pre>
        </CardContent>
      </Card>
    </div>
  );
}

/** ─── Pet: resumo em texto dos pets cadastrados e das próximas doses de vacina. ─── */
function PetShareCard() {
  const { data: pets = [], isLoading: carregandoPets } = useQuery({
    queryKey: ["pets-compartilhar"],
    queryFn: async () => {
      const { data, error } = await (supabase as any)
        .from("pet_animais")
        .select("id,nome,especie,raca")
        .order("nome");
      if (error) throw error;
      return data ?? [];
    },
  });
  const { data: vacinas = [] } = useQuery({
    queryKey: ["pet-vacinas-compartilhar"],
    queryFn: async () => {
      const { data, error } = await (supabase as any)
        .from("pet_vacinas")
        .select("pet_id,nome,proxima_dose_em")
        .order("proxima_dose_em");
      if (error) throw error;
      return data ?? [];
    },
  });

  const texto = useMemo(() => {
    if ((pets as any[]).length === 0) return "Pet\n\nNenhum pet cadastrado.";
    const linhasPets = (pets as any[]).map(
      (p: any) => `• ${p.nome}${p.especie ? ` (${p.especie}${p.raca ? ` · ${p.raca}` : ""})` : ""}`,
    );
    const hoje = new Date().toISOString().slice(0, 10);
    const proximasDoses = (vacinas as any[])
      .filter((v: any) => v.proxima_dose_em && v.proxima_dose_em >= hoje)
      .slice(0, 5)
      .map((v: any) => {
        const nomePet = (pets as any[]).find((p: any) => p.id === v.pet_id)?.nome ?? "Pet";
        return `• ${nomePet} — ${v.nome}: ${formatDate(v.proxima_dose_em)}`;
      });
    return [
      `Pet (${(pets as any[]).length})`,
      "",
      linhasPets.join("\n"),
      ...(proximasDoses.length ? ["", "Próximas doses de vacina:", proximasDoses.join("\n")] : []),
    ].join("\n");
  }, [pets, vacinas]);

  return (
    <div className="grid gap-4 lg:grid-cols-[280px_1fr]">
      <Card>
        <CardContent className="space-y-4 p-4">
          <Button
            variant="outline"
            className="w-full"
            disabled={carregandoPets}
            onClick={() => compartilharTexto(texto, "Pet")}
          >
            <Share2 className="size-4" /> Compartilhar texto
          </Button>
          <Button variant="outline" className="w-full" onClick={() => copiarTexto(texto)}>
            <ImageIcon className="size-4" /> Copiar texto
          </Button>
          <ImageShareActions titulo="Pet" texto={texto} arquivo="pet" />
          <p className="text-xs text-muted-foreground">
            Inclui os pets cadastrados e as próximas doses de vacina previstas.
          </p>
        </CardContent>
      </Card>
      <Card>
        <CardContent className="space-y-2 p-6">
          <div className="flex items-center gap-2 text-sm font-semibold">
            <PawPrint className="size-4" /> Prévia
          </div>
          <pre className="whitespace-pre-wrap rounded-lg bg-muted/50 p-3 text-sm">{texto}</pre>
        </CardContent>
      </Card>
    </div>
  );
}

/** ─── Onde está?: resumo em texto dos locais cadastrados e quantos itens cada um guarda. ─── */
function OndeEstaShareCard() {
  const { data: locais = [], isLoading } = useQuery({
    queryKey: ["locais-compartilhar"],
    queryFn: async () => {
      const { data, error } = await (supabase as any)
        .from("locais_armazenamento")
        .select("id,nome")
        .order("nome");
      if (error) throw error;
      return data ?? [];
    },
  });
  const { data: itens = [] } = useQuery({
    queryKey: ["itens-armazenados-compartilhar"],
    queryFn: async () => {
      const { data, error } = await (supabase as any)
        .from("itens_armazenados")
        .select("local_id");
      if (error) throw error;
      return data ?? [];
    },
  });

  const texto = useMemo(() => {
    if ((locais as any[]).length === 0) return "Onde está?\n\nNenhum local cadastrado.";
    const linhas = (locais as any[]).map((l: any) => {
      const qtd = (itens as any[]).filter((i: any) => i.local_id === l.id).length;
      return `• ${l.nome} — ${qtd} item(ns)`;
    });
    return `Onde está? (${(locais as any[]).length} local(is))\n\n${linhas.join("\n")}`;
  }, [locais, itens]);

  return (
    <div className="grid gap-4 lg:grid-cols-[280px_1fr]">
      <Card>
        <CardContent className="space-y-4 p-4">
          <Button
            variant="outline"
            className="w-full"
            disabled={isLoading}
            onClick={() => compartilharTexto(texto, "Onde está?")}
          >
            <Share2 className="size-4" /> Compartilhar texto
          </Button>
          <Button variant="outline" className="w-full" onClick={() => copiarTexto(texto)}>
            <ImageIcon className="size-4" /> Copiar texto
          </Button>
          <ImageShareActions titulo="Onde está?" texto={texto} arquivo="onde-esta" />
          <p className="text-xs text-muted-foreground">
            Inclui os locais de guarda cadastrados e quantos itens cada um tem.
          </p>
        </CardContent>
      </Card>
      <Card>
        <CardContent className="space-y-2 p-6">
          <div className="flex items-center gap-2 text-sm font-semibold">
            <MapPin className="size-4" /> Prévia
          </div>
          <pre className="whitespace-pre-wrap rounded-lg bg-muted/50 p-3 text-sm">{texto}</pre>
        </CardContent>
      </Card>
    </div>
  );
}

/** ─── Exames: resumo em texto com título, data e laboratório dos exames
 * aprovados — sem os valores/indicadores dos resultados, que continuam só
 * dentro do site (o próprio usuário decide se quer digitar esses números
 * na mensagem antes de enviar). ─── */
function ExamesShareCard() {
  const { data: exames = [], isLoading } = useQuery({
    queryKey: ["exames-compartilhar"],
    queryFn: async () => {
      const { data, error } = await (supabase as any)
        .from("exames_registros")
        .select("titulo,laboratorio,data_exame")
        .eq("status_importacao", "aprovado")
        .order("data_exame", { ascending: false })
        .limit(10);
      if (error) throw error;
      return data ?? [];
    },
  });

  const texto = useMemo(() => {
    if ((exames as any[]).length === 0) return "Exames\n\nNenhum exame registrado.";
    const linhas = (exames as any[]).map(
      (e: any) =>
        `• ${e.titulo}${e.data_exame ? ` — ${formatDate(e.data_exame)}` : ""}${e.laboratorio ? ` (${e.laboratorio})` : ""}`,
    );
    return `Exames — últimos registrados\n\n${linhas.join("\n")}`;
  }, [exames]);

  return (
    <div className="grid gap-4 lg:grid-cols-[280px_1fr]">
      <Card>
        <CardContent className="space-y-4 p-4">
          <Button
            variant="outline"
            className="w-full"
            disabled={isLoading}
            onClick={() => compartilharTexto(texto, "Exames")}
          >
            <Share2 className="size-4" /> Compartilhar texto
          </Button>
          <Button variant="outline" className="w-full" onClick={() => copiarTexto(texto)}>
            <ImageIcon className="size-4" /> Copiar texto
          </Button>
          <ImageShareActions titulo="Exames" texto={texto} arquivo="exames" />
          <p className="text-xs text-muted-foreground">
            Inclui só título, data e laboratório dos exames — os resultados/indicadores não entram
            neste resumo.
          </p>
        </CardContent>
      </Card>
      <Card>
        <CardContent className="space-y-2 p-6">
          <div className="flex items-center gap-2 text-sm font-semibold">
            <FileHeart className="size-4" /> Prévia
          </div>
          <pre className="whitespace-pre-wrap rounded-lg bg-muted/50 p-3 text-sm">{texto}</pre>
        </CardContent>
      </Card>
    </div>
  );
}

/** ─── Resumo inteligente: um texto único juntando os pontos mais relevantes
 * de finanças, lista de compras e veículos — pensado pra mandar de uma vez
 * só pra alguém que quer só o essencial, sem abrir o site. ─── */
const REVISAO_COMPLETA =
  "Seja meu assistente pessoal e revise meu mês em tópicos curtos: saldo; categorias acima da " +
  "média dos 3 meses anteriores; lançamentos em aberto; assinaturas e gastos fixos para revisar; " +
  "parcelas que terminam logo; lista de compras e garantias perto do fim; uma dica. " +
  "Use só os dados informados.";

const PERGUNTAS_RAPIDAS = [
  "Quais categorias estão acima do normal?",
  "Quais assinaturas devo revisar?",
  "O que tenho em aberto para pagar este mês?",
  "Quais garantias estão perto de acabar?",
];

/** Assistente pessoal (IA): lê o resumo que o site já calcula do PRÓPRIO usuário. */
function AssistenteIA() {
  const { resumo, carregando } = useResumoFinanceiroMes();
  const resumirFn = useServerFn(resumoFinanceiroIA);
  const [resposta, setResposta] = useState("");
  const [pergunta, setPergunta] = useState("");
  const [rodando, setRodando] = useState(false);

  async function perguntar(texto: string) {
    if (!texto.trim() || rodando) return;
    setRodando(true);
    setResposta("");
    try {
      const r = await resumirFn({ data: { pergunta: texto, resumo } });
      if (r.erro) toast.error(r.erro);
      else setResposta(r.texto);
    } catch {
      toast.error("Não consegui falar com o assistente agora. Tente de novo.");
    } finally {
      setRodando(false);
    }
  }

  return (
    <Card className="lg:col-span-2">
      <CardContent className="space-y-3 p-4 sm:p-6">
        <div className="flex items-center gap-2 text-sm font-semibold">
          <Sparkles className="size-4 text-primary" /> Assistente pessoal (IA)
        </div>
        <p className="text-xs text-muted-foreground">
          Lê só os seus dados do site (finanças, assinaturas, lista de compras e notas fiscais) e
          ajuda a revisar. Pode errar: confira os valores antes de decidir. Uso diário limitado.
        </p>
        <Button onClick={() => perguntar(REVISAO_COMPLETA)} disabled={rodando || carregando}>
          <Sparkles className="size-4" /> {rodando ? "Analisando..." : "Revisar meu mês com IA"}
        </Button>
        <div className="flex flex-wrap gap-2">
          {PERGUNTAS_RAPIDAS.map((q) => (
            <button
              key={q}
              type="button"
              disabled={rodando || carregando}
              onClick={() => perguntar(q)}
              className="rounded-full border px-3 py-1 text-xs hover:bg-muted disabled:opacity-50"
            >
              {q}
            </button>
          ))}
        </div>
        <form
          className="flex gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            void perguntar(pergunta);
          }}
        >
          <Input
            value={pergunta}
            onChange={(e) => setPergunta(e.target.value)}
            placeholder="Pergunte algo sobre as suas finanças..."
            maxLength={500}
          />
          <Button type="submit" variant="outline" disabled={rodando || carregando || !pergunta.trim()}>
            Perguntar
          </Button>
        </form>
        {resposta && (
          <div className="space-y-2">
            <pre className="whitespace-pre-wrap rounded-lg bg-muted/50 p-3 font-sans text-sm">{resposta}</pre>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={() => copiarTexto(resposta)}>
                Copiar
              </Button>
              <Button variant="outline" size="sm" onClick={() => compartilharTexto(resposta, "Revisão do mês")}>
                <Share2 className="size-4" /> Compartilhar
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function ResumoInteligenteShareCard() {
  const cotacao = useCotacao();
  const { habilitado } = useModulosGlobais();
  const { data: receitas = [] } = useReceitas();
  const { data: despesas = [] } = useDespesas();
  const { data: veiculos = [] } = useVeiculos();
  const { data: itensLista = [] } = useQuery({
    queryKey: ["lista-compras-compartilhar"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("lista_compras")
        .select("nome,quantidade,comprado")
        .order("comprado")
        .limit(200);
      if (error) throw error;
      return data ?? [];
    },
    enabled: habilitado("lista"),
  });

  const mes = currentMonthKey();
  const alertasVeiculos = useMemo(
    () => (habilitado("veiculo") ? alertasDosVeiculos(veiculos as any[]) : []),
    [veiculos, habilitado],
  );

  const resumo = useMemo(() => {
    const rec = (receitas as any[])
      .filter((r) => monthKey(r.data_recebimento) === mes)
      .reduce((s, r) => s + toBRL(Number(r.valor), r.moeda, cotacao), 0);
    const parcelasMes = (despesas as any[]).flatMap((d) =>
      (d.parcelas ?? [])
        .filter((p: any) => monthKey(p.vencimento) === mes)
        .map((p: any) => ({ ...p, moeda: d.moeda })),
    );
    const desp = parcelasMes.reduce((s, p: any) => s + toBRL(Number(p.valor), p.moeda, cotacao), 0);
    const pendentesLista = (itensLista as any[]).filter((i) => !i.comprado).length;
    return { rec, desp, saldo: rec - desp, pendentesLista };
  }, [receitas, despesas, itensLista, mes, cotacao]);

  const texto = useMemo(() => {
    const linhas = [
      `Resumo — ${monthLabel(mes)}`,
      "",
      `💰 Receitas: ${formatBRL(resumo.rec)}`,
      `💸 Despesas: ${formatBRL(resumo.desp)}`,
      `${resumo.saldo >= 0 ? "✅" : "🔴"} Saldo: ${formatBRL(resumo.saldo)}`,
    ];
    if (habilitado("lista")) {
      linhas.push(
        resumo.pendentesLista > 0
          ? `🛒 ${resumo.pendentesLista} item(ns) pendente(s) na lista de compras`
          : "🛒 Lista de compras sem pendências",
      );
    }
    if (habilitado("veiculo") && alertasVeiculos.length > 0) {
      linhas.push(`🚗 ${alertasVeiculos.length} alerta(s) de veículo em aberto`);
    }
    linhas.push("", `Gerado em ${formatDate(new Date().toISOString())}`);
    return linhas.join("\n");
  }, [resumo, alertasVeiculos, habilitado, mes]);

  return (
    <div className="grid gap-4 lg:grid-cols-[280px_1fr]">
      <AssistenteIA />
      <Card>
        <CardContent className="space-y-4 p-4">
          <Button
            variant="outline"
            className="w-full"
            onClick={() => compartilharTexto(texto, "Resumo inteligente")}
          >
            <Share2 className="size-4" /> Compartilhar texto
          </Button>
          <Button variant="outline" className="w-full" onClick={() => copiarTexto(texto)}>
            <ImageIcon className="size-4" /> Copiar texto
          </Button>
          <ImageShareActions titulo="Resumo inteligente" texto={texto} arquivo="resumo-inteligente" />
          <p className="text-xs text-muted-foreground">
            Junta o essencial de finanças, lista de compras e veículos num único resumo — bom pra
            mandar rapidinho sem abrir o site.
          </p>
        </CardContent>
      </Card>
      <Card>
        <CardContent className="space-y-2 p-6">
          <div className="flex items-center gap-2 text-sm font-semibold">
            <Sparkles className="size-4" /> Prévia
          </div>
          <pre className="whitespace-pre-wrap rounded-lg bg-muted/50 p-3 text-sm">{texto}</pre>
        </CardContent>
      </Card>
    </div>
  );
}

function Preview({ label, value, tone }: { label: string; value: string; tone: string }) {
  return (
    <div className="rounded-xl bg-muted/50 p-3">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className={`mt-1 text-lg font-bold ${tone}`}>{value}</p>
    </div>
  );
}
