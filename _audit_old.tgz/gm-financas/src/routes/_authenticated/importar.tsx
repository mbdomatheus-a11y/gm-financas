import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { prepararEnvioLayout } from "@/lib/layout-fatura.functions";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  AlertTriangle,
  CheckCircle2,
  ArrowLeftRight,
  ClipboardPaste,
  FileSpreadsheet,
  FileText,
  Image as ImageIcon,
  Loader2,
  Plus,
  ShieldCheck,
  Trash2,
  Upload,
} from "lucide-react";
import { toast } from "sonner";

import { AppLayout } from "@/components/AppLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { usePermissoes, useSession } from "@/hooks/useAuthData";
import {
  RESPONSAVEIS_EXTRA,
  useBancos,
  useCartoes,
  useCategorias,
  useDespesas,
  useProfilesList,
} from "@/hooks/useFinance";
import { formatBRL, monthLabelLong } from "@/lib/format";
import { mesmaPessoa } from "@/lib/fatura-fluxo";
import {
  AvisoCorrespondenciaFixa,
  type AcaoFixa,
} from "@/components/AvisosImportacao";
import { DuplicidadeDialog } from "@/components/DuplicidadeDialog";
import {
  classificacaoAnterior,
  encontrarCandidatas,
  type AcaoDuplicata,
  type Candidata,
  type DespesaExistente,
} from "@/lib/duplicidade-importacao";
import {
  despesasFaltantes,
  type DecisaoFatura,
  type DecisaoFaltantes,
} from "@/lib/substituicao-fatura";

/** Fatura anterior do mesmo cartão e mês que a importação pode substituir. */
type ConflitoSubst = {
  arquivo_hash: string;
  arquivo_nome: string;
  cartao_id: string;
  competencia: string;
  faturas_antigas: string[];
  escopo_despesa_ids: string[];
  rotulo: string;
};

/** Compras da fatura anterior que a fatura nova não traz, à espera de decisão. */
type FaltantesPendentes = {
  arquivo_hash: string;
  rotulo: string;
  itens: { id: string; descricao: string; valor: number; data: string }[];
};
import { cn } from "@/lib/utils";
import { encontrarCorrespondenciaFixa, type FixaCandidata } from "@/lib/correspondencia-fixa";
import { mesesEntreCompetencias, somarMeses, vencimentoDaCompetencia } from "@/lib/recorrencia";
import {
  CATEGORIA_A_CONFIRMAR,
  CONFIANCA_LABEL,
  chaveEstabelecimento,
  classificar,
  detectarTipoLancamento,
  type RegraUsuario,
} from "@/lib/categorizacao";
import { PrimeiraCategoriaGuia } from "@/components/PrimeiraCategoriaGuia";
import { PrimeiraFaturaAviso } from "@/components/PrimeiraFaturaAviso";
import { useEstruturaCategorias } from "@/hooks/useEstruturaCategorias";
import { lembrarClassificacoes } from "@/lib/classificacao-lembrada";
import { SeletorCategoria } from "@/components/SeletorCategoria";
import { interpretarBloco } from "@/lib/lancamento-texto";
import { lancamentosDeOcr, ocrImagem, hashTexto as hashTextoOcr } from "@/lib/ocr";
import {
  BANCO_LABEL,
  conferirTotal,
  dedupKey,
  ErroLeituraPdf,
  processarFatura,
  vencimentoParcela,
  type BancoFatura,
  type FaturaExtraida,
  type LancamentoExtraido,
} from "@/lib/faturas";
import { lerPlanilhaImportacao, modeloCsvPlanilha } from "@/lib/importacao-planilha";

export const Route = createFileRoute("/_authenticated/importar")({
  head: () => ({
    meta: [
      { title: "Importar Lançamentos — Control ALL" },
      {
        name: "description",
        content:
          "Importe faturas em PDF ou cole lançamentos de texto, revise tudo linha a linha com categorização automática e confirme para lançar nas despesas.",
      },
      { property: "og:title", content: "Importar Lançamentos — Control ALL" },
      {
        property: "og:description",
        content:
          "Faturas em PDF e texto colado com prévia totalmente editável e de-para de categorias.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ImportarPage,
});

const BANCOS: BancoFatura[] = [
  "itau",
  "nubank",
  "pernambucanas",
  "santander",
  "xp",
  "riachuelo",
  "desconhecido",
];

/** Fatura já importada do mesmo cartão (ou banco, sem cartão) no mesmo mês. */
type ConflitoMes = { id: string; arquivo_nome: string; created_at: string };

type FaturaItem = FaturaExtraida & {
  arquivo: File | null;
  duplicada?: boolean;
  conflitoMes?: ConflitoMes | null;
  destino?: string;
  total_declarado_edicao?: string;
};


/** Normaliza nomes para comparar "Itaú" com "itau", "Banco Santander" com "santander" etc. */
function chaveNome(v: string) {
  return v
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]/g, "");
}

async function hashTexto(texto: string) {
  const buf = new TextEncoder().encode(texto);
  const digest = await crypto.subtle.digest("SHA-256", buf);
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

function ImportarPage() {
  const { estrutura, criarSubcategoria } = useEstruturaCategorias("despesa");
  const qc = useQueryClient();
  const { user } = useSession();
  const { can, canImportar, exclusaoBloqueada } = usePermissoes();
  const { data: profiles = [] } = useProfilesList();
  const { data: categorias = [] } = useCategorias("despesa");
  const { data: cartoes = [] } = useCartoes();
  const { data: bancos = [] } = useBancos();
  const { data: despesasTodas = [] } = useDespesas();
  // Despesas fixas já cadastradas (de importações/telas anteriores) — usadas
  // pra avisar quando um lançamento desta importação parece ser a mesma
  // despesa fixa aparecendo de novo (ex.: assinatura recorrente que chegou
  // numa fatura de mês seguinte), já que essas agora são projetadas
  // automaticamente pra frente e não precisam ser reimportadas.
  const despesasFixas = useMemo(
    () => (despesasTodas as FixaCandidata[]).filter((d) => d.tipo === "fixa"),
    [despesasTodas],
  );
  const inputRef = useRef<HTMLInputElement>(null);
  const layoutRef = useRef<HTMLInputElement>(null);
  const prepararLayout = useServerFn(prepararEnvioLayout);
  const [enviandoLayout, setEnviandoLayout] = useState(false);
  const [modalAnaliseOpen, setModalAnaliseOpen] = useState(false);

  const { data: solicitacoesAnalise = [] } = useQuery({
    queryKey: ["layout_solicitacoes"],
    queryFn: async () => {
      const { data, error } = await (supabase as any)
        .from("layout_solicitacoes")
        .select("*")
        .order("criado_em", { ascending: false });
      if (error) return [];
      return data ?? [];
    },
  });

  async function enviarParaModelagem(files: FileList | null) {
    const file = files?.[0];
    if (!file) return;
    if (file.size > 10 * 1024 * 1024) {
      toast.error("O arquivo pode ter no máximo 10 MB.");
      return;
    }
    setEnviandoLayout(true);
    try {
      const envio = await prepararLayout({ data: { nome: file.name } });
      const { error } = await supabase.storage
        .from("layouts_analise")
        .uploadToSignedUrl(envio.path, envio.token, file);
      if (error) throw error;
      qc.invalidateQueries({ queryKey: ["layout_solicitacoes"] });
      toast.success(
        `Fatura enviada para análise. Protocolo: ${envio.protocolo}. Usaremos apenas o layout e o arquivo será descartado em até 30 dias.`,
      );
    } catch (e: any) {
      toast.error(e.message ?? "Não foi possível enviar.");
    } finally {
      setEnviandoLayout(false);
      if (layoutRef.current) layoutRef.current.value = "";
    }
  }
  const imgInputRef = useRef<HTMLInputElement>(null);
  const planilhaInputRef = useRef<HTMLInputElement>(null);
  const classificacoesEditadas = useRef(new Set<string>());
  // Etapa F (plano-importacao-v2.md): "linha de base" de cada lançamento
  // (valor já extraído/corrigido automaticamente, antes de qualquer edição
  // manual nesta sessão) — usada só para saber quando mostrar o botão
  // "Ensinar" (a edição do usuário diverge da base) e o que gravar nela.
  const baseCorrecao = useRef(
    new Map<string, { data_compra: string; descricao: string; valor: number }>(),
  );

  const [lendo, setLendo] = useState(false);
  const [lendoImagens, setLendoImagens] = useState(false);
  const [lendoPlanilha, setLendoPlanilha] = useState(false);
  const [faturas, setFaturas] = useState<FaturaItem[]>([]);
  // Linha que travou a confirmação (destacada em vermelho na tabela de revisão).
  const [linhaComErro, setLinhaComErro] = useState<string | null>(null);
  // Andamento da gravação, para a barra percentual durante a confirmação.
  const [progresso, setProgresso] = useState<{ feitos: number; total: number; etapa: string } | null>(
    null,
  );
  const [acoesDuplicata, setAcoesDuplicata] = useState<
    Record<string, { acao: AcaoDuplicata; alvoId: string | null }>
  >({});
  /** Popup de criar categoria durante a importação. */
  /** Responsável aplicado a todas as linhas, por fatura (só para mostrar no botão). */
  const [responsavelDeTodos, setResponsavelDeTodos] = useState<Record<string, string>>({});
  const [novaCategoria, setNovaCategoria] = useState<{
    nome: string;
    faturaIdx: number;
    lancamentoId: string;
  } | null>(null);
  const [duplicataAberta, setDuplicataAberta] = useState<{
    faturaIdx: number;
    lancamentoId: string;
  } | null>(null);
  const [decisaoFatura, setDecisaoFatura] = useState<Record<string, DecisaoFatura>>({});
  const [decisaoFaltantes, setDecisaoFaltantes] = useState<Record<string, DecisaoFaltantes>>({});
  const [conflitosPorFatura, setConflitosPorFatura] = useState<Record<string, ConflitoSubst>>({});
  const [faltantesPendentes, setFaltantesPendentes] = useState<FaltantesPendentes[]>([]);
  const [dialogoSubst, setDialogoSubst] = useState<"modo" | "faltantes" | null>(null);
  const [preparando, setPreparando] = useState(false);
  const [acoesFixas, setAcoesFixas] = useState<Record<string, { acao: AcaoFixa; fixaId: string }>>(
    {},
  );
  const [colado, setColado] = useState("");
  const [cadastroDestino, setCadastroDestino] = useState<{
    arquivoHash: string;
    tipo: "banco" | "cartao";
  } | null>(null);
  const [nomeBancoNovo, setNomeBancoNovo] = useState("");
  const [cartaoNovo, setCartaoNovo] = useState({
    apelido: "",
    final: "",
    titular: "",
    bancoId: "",
  });
  const [pdfsComSenha, setPdfsComSenha] = useState<
    { file: File; senha: string; erro: string | null; tentando: boolean }[]
  >([]);

  const { data: regras = [] } = useQuery({
    queryKey: ["categoria-regras"],
    queryFn: async () => {
      const { data, error } = await supabase.from("categoria_regras").select("*");
      if (error) throw error;
      // De-para padrão do admin entra com prioridade baixa: as regras do usuário vencem.
      const { data: padrao } = await (supabase as any)
        .from("depara_padrao")
        .select("texto,categoria,subcategoria")
        .eq("ativo", true);
      const padraoRegras: RegraUsuario[] = ((padrao ?? []) as any[]).map((p) => ({
        estabelecimento_normalizado: p.texto,
        padroes: [p.texto],
        tipo_regra: "de_para",
        categoria: p.categoria,
        subcategoria: p.subcategoria ?? null,
        prioridade: 1,
        ativo: true,
      }));
      return [...((data ?? []) as RegraUsuario[]), ...padraoRegras];
    },
  });

  /**
   * Escolhas que o usuário já fez para cada estabelecimento em importações
   * anteriores (ex.: "esta linha substitui o valor daquela despesa fixa").
   * São aplicadas sozinhas na próxima fatura.
   */
  const { data: preferenciasImportacao = [] } = useQuery({
    queryKey: ["importacao-preferencias"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("importacao_preferencias")
        .select("chave, escopo, acao, despesa_id");
      if (error) throw error;
      return data ?? [];
    },
  });

  /** Cria a categoria na hora, sem sair da importação, e já aplica na linha. */
  const criarCategoria = useMutation({
    mutationFn: async (p: { nome: string; faturaIdx: number; lancamentoId: string }) => {
      const nome = p.nome.trim();
      if (!nome) throw new Error("Informe o nome da categoria.");
      const { data: existente } = await supabase
        .from("categorias")
        .select("id, nome")
        .eq("tipo", "despesa")
        .ilike("nome", nome)
        .limit(1)
        .maybeSingle();
      if (!existente) {
        const { error } = await supabase.from("categorias").insert({ nome, tipo: "despesa" });
        if (error) throw error;
      }
      return { ...p, nome: existente?.nome ?? nome };
    },
    onSuccess: (r) => {
      atualizarLancamento(r.faturaIdx, r.lancamentoId, { categoria: r.nome, subcategoria: null });
      void qc.invalidateQueries({ queryKey: ["categorias", "despesa"] });
      setNovaCategoria(null);
      toast.success(`Categoria "${r.nome}" pronta para uso.`);
    },
    onError: (e: any) => toast.error(e?.message ?? "Não foi possível criar a categoria."),
  });

  const salvarPreferenciaImportacao = useMutation({
    mutationFn: async (p: {
      descricao: string;
      escopo: "fixa" | "duplicata";
      acao: string;
      despesaId: string | null;
    }) => {
      const chave = chaveEstabelecimento(p.descricao);
      if (!chave || !user?.id) return;
      const { data: perfil } = await supabase
        .from("profiles")
        .select("grupo_id")
        .eq("id", user.id)
        .maybeSingle();
      if (!perfil?.grupo_id) return;
      const { error } = await supabase.from("importacao_preferencias").upsert(
        {
          grupo_id: perfil.grupo_id,
          chave,
          escopo: p.escopo,
          acao: p.acao,
          despesa_id: p.despesaId,
          criado_por: user.id,
          atualizado_em: new Date().toISOString(),
        },
        { onConflict: "grupo_id,chave,escopo" },
      );
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["importacao-preferencias"] }),
  });

  /**
   * Categoria e tipo que o usuário corrigiu à mão para este estabelecimento
   * (gravado ao salvar a despesa em /despesas). Vale mais que a classificação
   * automática, inclusive numa reimportação da mesma fatura.
   */
  function classificacaoCorrigida(
    descricao: string,
  ): { categoria: string; subcategoria: string | null; tipo: "fixa" | "variavel" } | null {
    const chave = chaveEstabelecimento(descricao);
    if (!chave) return null;
    const salva = (preferenciasImportacao as any[]).find(
      (p) => p.chave === chave && p.escopo === "classificacao",
    );
    if (!salva?.acao) return null;
    try {
      const v = JSON.parse(salva.acao) as {
        categoria?: string;
        subcategoria?: string | null;
        tipo?: string;
      };
      if (!v.categoria) return null;
      return {
        categoria: v.categoria,
        subcategoria: v.subcategoria ?? null,
        tipo: v.tipo === "fixa" ? "fixa" : "variavel",
      };
    } catch {
      return null;
    }
  }

  /** Preferência salva para o estabelecimento desta linha. */
  function preferenciaDe(descricao: string, escopo: "fixa" | "duplicata") {
    const chave = chaveEstabelecimento(descricao);
    if (!chave) return null;
    return (
      (preferenciasImportacao as any[]).find((p) => p.chave === chave && p.escopo === escopo) ?? null
    );
  }

  const responsaveis = useMemo(
    () => [...(profiles as any[]).map((p) => p.nome as string), RESPONSAVEIS_EXTRA],
    [profiles],
  );


  /** Aplica o de-para e as palavras-chave em cada lançamento lido. */
  function categorizar(lancamentos: LancamentoExtraido[]): LancamentoExtraido[] {
    return lancamentos.map((l) => {
      const c = classificar(l.descricao, { regras, valor: l.valor });
      // Repete a classificação que este mesmo estabelecimento já recebeu antes
      // (ex.: "Plano Nu Cel 25,00" marcado como despesa fixa no mês passado).
      // O de-para do usuário continua mandando quando tem confiança alta.
      // 1º) o que o usuário corrigiu à mão para este estabelecimento (salvo ao
      // editar a despesa); 2º) como ele já estava classificado antes; 3º) o
      // de-para e as palavras-chave.
      const corrigida = classificacaoCorrigida(l.descricao);
      const anterior = classificacaoAnterior(l, despesasTodas as DespesaExistente[]);
      const usarAnterior = !corrigida && !!anterior && c.confianca !== "alta";
      return {
        ...l,
        categoria: corrigida?.categoria ?? (usarAnterior ? anterior!.categoria : c.categoria),
        subcategoria:
          corrigida?.subcategoria ?? (usarAnterior ? anterior!.subcategoria : c.subcategoria),
        categoria_sugerida: c.categoria,
        confianca_categoria: corrigida || usarAnterior ? "alta" : c.confianca,
        tipo: l.tipo ?? corrigida?.tipo ?? anterior?.tipo ?? "variavel",
      };
    });
  }

  const chaveDup = (hash: string, lancamentoId: string) => `${hash}:${lancamentoId}`;

  /** Lançamentos já salvos que podem ser o mesmo gasto desta linha da fatura. */
  function candidatasDe(
    f: FaturaItem,
    l: LancamentoExtraido,
    conflitos: Record<string, ConflitoSubst> = conflitosPorFatura,
  ): Candidata[] {
    const todas = encontrarCandidatas(l, despesasTodas as DespesaExistente[]);
    const conflito = conflitos[f.arquivo_hash];
    if (!conflito || decisaoFatura[f.arquivo_hash] !== "fechada") return todas;
    // Compras da fatura anterior saem na substituição: não são parecidas, são a mesma coisa.
    const saem = new Set(conflito.escopo_despesa_ids);
    return todas.filter((c) => !saem.has(c.despesa.id));
  }

  function cartaoDaFatura(f: FaturaItem): string | null {
    const [tipo, id] = String(f.destino ?? "").split(":");
    if (tipo === "cartao" && id) return id;
    return f.lancamentos.map((l) => acharCartao(f.banco, l.cartao_final)?.id).find(Boolean) ?? null;
  }

  function competenciaDaFatura(f: FaturaItem): string | null {
    return f.competencia ?? f.vencimento?.slice(0, 7) ?? null;
  }

  function rotuloCartao(id: string): string {
    const c = (cartoes as any[]).find((x) => x.id === id);
    if (!c) return "Cartão";
    return `${c.bancos?.nome ? `${c.bancos.nome} ` : ""}${c.apelido || `Cartão •${c.final}`}`;
  }

  /** Faturas que já tiveram a pergunta de fechada ou parcial mostrada nesta tela. */
  const perguntadas = useRef<Set<string>>(new Set());

  /** Compara as faturas lidas com o banco (mesmo cartão e mês). */
  async function analisarSubstituicoes(): Promise<{
    conflitos: Record<string, ConflitoSubst>;
    pendentes: FaltantesPendentes[];
  }> {
    const conflitos: Record<string, ConflitoSubst> = {};
    for (const f of faturas) {
      const cartaoId = cartaoDaFatura(f);
      const comp = competenciaDaFatura(f);
      // Sem cartão conhecido não há como substituir com segurança: só o aviso aparece.
      if (!cartaoId || !comp) continue;
      const { data: antigas, error } = await supabase
        .from("import_faturas")
        .select("id")
        .eq("cartao_id", cartaoId)
        .eq("competencia", comp);
      if (error) throw error;
      if (!antigas?.length) continue;
      const ids = antigas.map((x) => x.id);
      const { data: parc, error: pErr } = await supabase
        .from("parcelas")
        .select("despesa_id")
        .in("fatura_id", ids);
      if (pErr) throw pErr;
      const { data: desp, error: dErr } = await supabase
        .from("despesas")
        .select("id")
        .in("fatura_id", ids);
      if (dErr) throw dErr;
      const escopo = [
        ...new Set([...(parc ?? []).map((p) => p.despesa_id), ...(desp ?? []).map((d) => d.id)]),
      ];
      conflitos[f.arquivo_hash] = {
        arquivo_hash: f.arquivo_hash,
        arquivo_nome: f.arquivo_nome,
        cartao_id: cartaoId,
        competencia: comp,
        faturas_antigas: ids,
        escopo_despesa_ids: escopo,
        rotulo: `${rotuloCartao(cartaoId)} · ${monthLabelLong(comp)}`,
      };
    }

    const pendentes: FaltantesPendentes[] = [];
    for (const c of Object.values(conflitos)) {
      if (decisaoFatura[c.arquivo_hash] !== "fechada" || decisaoFaltantes[c.arquivo_hash]) continue;
      const f = faturas.find((x) => x.arquivo_hash === c.arquivo_hash);
      if (!f || !c.escopo_despesa_ids.length) continue;
      const { data: antigas, error } = await supabase
        .from("despesas")
        .select("*")
        .in("id", c.escopo_despesa_ids);
      if (error) throw error;
      const faltam = despesasFaltantes(
        (antigas ?? []) as any[],
        f.lancamentos.filter((l) => l.incluir) as any[],
      );
      if (faltam.length)
        pendentes.push({
          arquivo_hash: c.arquivo_hash,
          rotulo: c.rotulo,
          itens: faltam.map((d) => ({
            id: d.id,
            descricao: d.descricao,
            valor: Number(d.valor_total),
            data: d.data_compra,
          })),
        });
    }
    return { conflitos, pendentes };
  }

  /**
   * Abre a pergunta de fechada ou parcial e a de faltantes, se faltar decisão.
   * Devolve os conflitos quando tudo está decidido, ou null quando um diálogo abriu.
   * `forcar` reabre perguntas que o usuário já tinha fechado sem responder.
   */
  async function decidirSubstituicoes(
    forcar: boolean,
  ): Promise<Record<string, ConflitoSubst> | null> {
    const { conflitos, pendentes } = await analisarSubstituicoes();
    setConflitosPorFatura(conflitos);
    const semModo = Object.values(conflitos).filter(
      (c) =>
        !decisaoFatura[c.arquivo_hash] && (forcar || !perguntadas.current.has(c.arquivo_hash)),
    );
    if (semModo.length) {
      semModo.forEach((c) => perguntadas.current.add(c.arquivo_hash));
      setDialogoSubst("modo");
      return null;
    }
    if (pendentes.length) {
      setFaltantesPendentes(pendentes);
      setDialogoSubst("faltantes");
      return null;
    }
    return conflitos;
  }

  // Ao adicionar ou remover fatura, pergunta logo no início (não na confirmação).
  const chaveFaturas = faturas.map((f) => f.arquivo_hash).join("|");
  useEffect(() => {
    if (!faturas.length) return;
    void decidirSubstituicoes(false).catch((e: any) =>
      toast.error(e?.message ?? "Não foi possível verificar as faturas deste mês."),
    );
    // Reage só a faturas adicionadas ou removidas, não a cada edição de linha.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [chaveFaturas]);

  // Aprendizado global: linhas sem categoria recebem a categoria mãe que mais grupos escolheram
  // para o mesmo estabelecimento. Nunca sobrescreve o que o usuário já editou nesta importação.
  const chavesSemCategoria = [
    ...new Set(
      faturas
        .flatMap((f) =>
          f.lancamentos
            .filter((l) => l.categoria === CATEGORIA_A_CONFIRMAR)
            .map((l) => chaveEstabelecimento(l.descricao)),
        )
        .filter(Boolean),
    ),
  ].sort();
  const chaveSemCategoria = chavesSemCategoria.join("|");
  useEffect(() => {
    if (!chavesSemCategoria.length) return;
    let cancelado = false;
    (async () => {
      const { data, error } = await (supabase as any).rpc("sugerir_classificacao", {
        p_chaves: chavesSemCategoria,
      });
      if (error || !Array.isArray(data) || cancelado) return;
      const mapa = new Map<string, string>(
        (data as { chave: string; categoria: string }[]).map((r) => [r.chave, r.categoria]),
      );
      if (!mapa.size) return;
      setFaturas((prev) =>
        prev.map((f) => ({
          ...f,
          lancamentos: f.lancamentos.map((l) => {
            if (l.categoria !== CATEGORIA_A_CONFIRMAR) return l;
            if (classificacoesEditadas.current.has(`${f.arquivo_hash}:${l.id}`)) return l;
            const sugerida = mapa.get(chaveEstabelecimento(l.descricao));
            return sugerida ? { ...l, categoria: sugerida } : l;
          }),
        })),
      );
    })().catch(() => {
      /* sugestão é auxiliar: sem ela a linha segue como "a confirmar" */
    });
    return () => {
      cancelado = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [chaveSemCategoria]);

  /** Confirmação: exige as decisões, checa parecidos e grava. */
  /** Competência (AAAA-MM) anterior ao mês corrente: a fatura é de um ciclo passado. */
  function competenciaAnterior(f: FaturaItem): string | null {
    const comp = competenciaDaFatura(f);
    if (!comp) return null;
    const hoje = new Date();
    const atual = `${hoje.getFullYear()}-${String(hoje.getMonth() + 1).padStart(2, "0")}`;
    return comp < atual ? comp : null;
  }

  function rotuloCompetencia(comp: string): string {
    const [ano, mes] = comp.split("-").map(Number);
    return new Date(ano!, mes! - 1, 1).toLocaleDateString("pt-BR", { month: "long", year: "numeric" });
  }

  async function prepararImportacao() {
    if (!faturas.length || preparando) return;
    const passadas = faturas
      .map((f) => competenciaAnterior(f))
      .filter((c): c is string => !!c);
    if (passadas.length) {
      toast.info(
        `Atenção: ${passadas.length === 1 ? "a fatura é" : "há faturas"} de competência anterior ao mês atual (${[
          ...new Set(passadas.map(rotuloCompetencia)),
        ].join(", ")}). A importação segue normalmente.`,
        { id: "aviso-competencia-anterior", duration: 4000, closeButton: true },
      );
    }
    setPreparando(true);
    try {
      const conflitos = await decidirSubstituicoes(true);
      if (!conflitos) return;

      const bloqueios = faturas.reduce(
        (n, f) =>
          n +
          f.lancamentos.filter(
            (l) =>
              l.incluir &&
              candidatasDe(f, l, conflitos).length > 0 &&
              acaoDuplicataDe(f, l) === "decidir",
          ).length,
        0,
      );
      if (bloqueios) {
        toast.error(
          `${bloqueios} lançamento(s) parecido(s) sem decisão. Resolva antes de importar: clique no aviso de cada linha.`,
        );
        return;
      }
      confirmar.mutate(conflitos);
    } catch (e: any) {
      toast.error(e?.message ?? "Não foi possível preparar a importação.");
    } finally {
      setPreparando(false);
    }
  }


  function acaoDuplicataDe(f: FaturaItem, l: LancamentoExtraido): AcaoDuplicata {
    const escolhida = acoesDuplicata[chaveDup(f.arquivo_hash, l.id)]?.acao;
    if (escolhida) return escolhida;
    const salva = preferenciaDe(l.descricao, "duplicata");
    return (salva?.acao as AcaoDuplicata) ?? "decidir";
  }

  /**
   * Repete as escolhas já feitas antes para os mesmos estabelecimentos (ex.:
   * "ajustar o valor da despesa fixa"). Roda como efeito, e não no momento de
   * abrir o arquivo: assim vale também quando a lista de preferências termina
   * de carregar depois da leitura da fatura — era por isso que uma decisão
   * salva às vezes voltava como "manter os dois". A escolha que o usuário
   * fizer agora nunca é sobrescrita.
   */
  const avisadas = useRef(new Set<string>());
  useEffect(() => {
    if (!faturas.length || !(preferenciasImportacao as any[]).length) return;
    const fixas: Record<string, { acao: AcaoFixa; fixaId: string }> = {};
    const duplicatas: Record<string, { acao: AcaoDuplicata; alvoId: string | null }> = {};
    for (const f of faturas) {
      for (const l of f.lancamentos) {
        const chaveFixa = `${f.arquivo_hash}:${l.id}`;
        const salvaFixa = preferenciaDe(l.descricao, "fixa");
        if (salvaFixa?.despesa_id && !acoesFixas[chaveFixa]) {
          fixas[chaveFixa] = { acao: salvaFixa.acao as AcaoFixa, fixaId: salvaFixa.despesa_id };
        }
        const chaveDupLinha = chaveDup(f.arquivo_hash, l.id);
        const salvaDup = preferenciaDe(l.descricao, "duplicata");
        if (salvaDup && !acoesDuplicata[chaveDupLinha]) {
          const c = candidatasDe(f, l);
          if (c.length)
            duplicatas[chaveDupLinha] = {
              acao: salvaDup.acao as AcaoDuplicata,
              alvoId: c[0]!.despesa.id,
            };
        }
      }
    }
    const total = Object.keys(fixas).length + Object.keys(duplicatas).length;
    if (!total) return;
    if (Object.keys(fixas).length) setAcoesFixas((atual) => ({ ...fixas, ...atual }));
    if (Object.keys(duplicatas).length) setAcoesDuplicata((atual) => ({ ...duplicatas, ...atual }));
    const chaveAviso = faturas.map((f) => f.arquivo_hash).join("|");
    if (!avisadas.current.has(chaveAviso)) {
      avisadas.current.add(chaveAviso);
      toast.info(`${total} escolha(s) de importações anteriores foram repetidas.`);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [faturas, preferenciasImportacao]);


  function definirAcaoDuplicata(
    f: FaturaItem,
    l: LancamentoExtraido,
    acao: AcaoDuplicata,
    alvoId: string | null,
  ) {
    setAcoesDuplicata((atual) => ({ ...atual, [chaveDup(f.arquivo_hash, l.id)]: { acao, alvoId } }));
    // Repete esta escolha na próxima fatura do mesmo estabelecimento.
    if (acao !== "decidir")
      salvarPreferenciaImportacao.mutate({
        descricao: l.descricao,
        escopo: "duplicata",
        acao,
        despesaId: null,
      });
    const idx = faturas.findIndex((x) => x.arquivo_hash === f.arquivo_hash);
    if (idx >= 0) atualizarLancamento(idx, l.id, { incluir: acao !== "manter_existente" });
  }

  /**
   * Marca todas as linhas com duplicata para substituir o lançamento já
   * cadastrado. Cada lançamento existente só pode ser usado por UMA linha: duas
   * compras iguais na mesma fatura (ex.: "Sem Parar 150,00" em dois dias) não
   * podem substituir o mesmo registro, senão uma delas se perde.
   */
  function substituirTodasDuplicatas(f: FaturaItem) {
    const novas: Record<string, { acao: AcaoDuplicata; alvoId: string | null }> = {};
    const usados = new Set<string>();
    let total = 0;
    let semAlvo = 0;
    for (const l of f.lancamentos) {
      const c = candidatasDe(f, l).filter((x) => !usados.has(x.despesa.id));
      if (!c.length) {
        // Já existia parecido, mas o único candidato foi usado por outra linha:
        // esta entra como lançamento novo, para não sumir da importação.
        if (candidatasDe(f, l).length) {
          novas[chaveDup(f.arquivo_hash, l.id)] = { acao: "novo", alvoId: null };
          semAlvo++;
        }
        continue;
      }
      usados.add(c[0]!.despesa.id);
      novas[chaveDup(f.arquivo_hash, l.id)] = { acao: "substituir", alvoId: c[0]!.despesa.id };
      total++;
    }
    if (!total) {
      toast.info("Nenhum lançamento desta fatura tem parecido já cadastrado.");
      return;
    }
    setAcoesDuplicata((atual) => ({ ...atual, ...novas }));
    toast.success(
      `${total} lançamento(s) vão substituir o que já estava cadastrado.` +
        (semAlvo ? ` ${semAlvo} entram como lançamento novo (o parecido já foi usado).` : ""),
    );
  }

  /** Cartão cadastrado com o final informado (preferindo o mesmo banco da fatura). */
  function acharCartao(banco: BancoFatura, final: string | null) {
    if (!final) return null;
    const doBanco = (cartoes as any[]).filter(
      (c) =>
        c.final === final &&
        (!c.bancos?.nome || chaveNome(c.bancos.nome) === chaveNome(BANCO_LABEL[banco])),
    );
    const qualquer = (cartoes as any[]).filter((c) => c.final === final);
    return doBanco[0] ?? qualquer[0] ?? null;
  }

  /** Destino padrão da fatura: cartão do banco (por final) ou conta bancária de mesmo nome. */
  function destinoPadrao(f: FaturaExtraida): string {
    const nome = chaveNome(BANCO_LABEL[f.banco]);
    for (const final of f.finais) {
      const c = acharCartao(f.banco, final);
      if (c) return `cartao:${c.id}`;
    }
    const cartaoBanco = (cartoes as any[]).find(
      (c) => c.bancos?.nome && chaveNome(c.bancos.nome) === nome,
    );
    if (cartaoBanco) return `cartao:${cartaoBanco.id}`;
    const banco = (bancos as any[]).find((b) => chaveNome(b.nome) === nome);
    return banco ? `banco:${banco.id}` : "";
  }

  /** Usuários do grupo + nomes de portadores lidos nas faturas (titular/adicionais). */
  const opcoesResponsavel = useMemo(() => {
    const nomes = new Set<string>(responsaveis);
    for (const f of faturas)
      for (const l of f.lancamentos) if (l.responsavel) nomes.add(l.responsavel);
    return Array.from(nomes);
  }, [responsaveis, faturas]);

  const totais = useMemo(() => {
    const lanc = faturas.flatMap((f) => f.lancamentos.filter((l) => l.incluir));
    return {
      arquivos: faturas.length,
      linhas: lanc.length,
      valor: lanc.reduce((s, l) => s + (l.direcao === "credito" ? -l.valor : l.valor), 0),
    };
  }, [faturas]);

  /** Processa um único PDF (com senha opcional) até virar um FaturaItem pronto pra revisão. */
  async function processarArquivoUnico(file: File, senha?: string): Promise<FaturaItem> {
    let extraida = await processarFatura(file, undefined, senha);
    // Se já aprendemos o padrão deste emissor, tenta a leitura guiada.
    if (
      extraida.assinatura &&
      extraida.leitura !== "fluxo" &&
      (!extraida.conferencia?.ok || !extraida.lancamentos.length)
    ) {
      const { data: perfil } = await supabase
        .from("fatura_layouts")
        .select("assinatura, banco, colunas, ancora_inicio, ancora_fim")
        .eq("assinatura", extraida.assinatura)
        .maybeSingle();
      if (perfil) {
        const alt = await processarFatura(
          file,
          {
            assinatura: perfil.assinatura,
            banco: perfil.banco,
            colunas: (perfil.colunas as any) ?? {},
            ancora_inicio: perfil.ancora_inicio,
            ancora_fim: perfil.ancora_fim,
          },
          senha,
        );
        if (
          alt.lancamentos.length &&
          (alt.conferencia?.ok || alt.lancamentos.length > extraida.lancamentos.length)
        ) {
          extraida = alt;
        }
      }
    }
    // Etapa F (plano-importacao-v2.md): aplica correções manuais já
    // ensinadas para este layout (mesma assinatura) antes de mostrar a
    // prévia — ver botão "Ensinar" na tabela de revisão, mais abaixo.
    if (extraida.assinatura) {
      const { data: aprendidas } = await supabase
        .from("fatura_correcoes_usuario")
        .select("campo, valor_original, valor_corrigido")
        .eq("assinatura", extraida.assinatura);
      if (aprendidas?.length) {
        const porCampo = {
          data_compra: new Map<string, string>(),
          descricao: new Map<string, string>(),
          valor: new Map<string, string>(),
        } as const;
        for (const a of aprendidas) {
          const mapa = (porCampo as Record<string, Map<string, string>>)[a.campo];
          mapa?.set(a.valor_original, a.valor_corrigido);
        }
        let aplicadas = 0;
        extraida = {
          ...extraida,
          lancamentos: extraida.lancamentos.map((l) => {
            let novo = l;
            const dataCorrigida = porCampo.data_compra.get(l.data_compra);
            if (dataCorrigida != null && dataCorrigida !== l.data_compra) {
              novo = { ...novo, data_compra: dataCorrigida };
              aplicadas++;
            }
            const descCorrigida = porCampo.descricao.get(l.descricao);
            if (descCorrigida != null && descCorrigida !== l.descricao) {
              novo = {
                ...novo,
                descricao: descCorrigida,
                descricao_normalizada: chaveEstabelecimento(descCorrigida),
              };
              aplicadas++;
            }
            const valorCorrigido = porCampo.valor.get(l.valor.toFixed(2));
            if (valorCorrigido != null) {
              const num = Number(valorCorrigido);
              if (Number.isFinite(num) && num !== l.valor) {
                novo = { ...novo, valor: num };
                aplicadas++;
              }
            }
            return novo;
          }),
        };
        if (aplicadas) toast.info(`${aplicadas} correção(ões) já ensinada(s) aplicada(s) de novo.`);
      }
    }
    const { data: jaExiste } = await supabase
      .from("import_faturas")
      .select("id")
      .eq("arquivo_hash", extraida.arquivo_hash)
      .maybeSingle();
    // Responsável: o nome impresso na fatura (titular/adicional) vira o
    // usuário do grupo com mesmo primeiro e último nome; sem correspondência,
    // fica o nome da fatura (aparece como opção na lista).
    const categorizados = categorizar(extraida.lancamentos).map((l) => {
      if (!l.responsavel) return l;
      const casado = responsaveis.find((r) => mesmaPessoa(r, l.responsavel));
      return casado ? { ...l, responsavel: casado } : l;
    });
    if (extraida.assinatura) {
      for (const l of categorizados) {
        // Chave com o arquivo: o id da linha (l0, l1...) recomeça em cada PDF. Com a chave só
        // pelo id, a base de uma fatura era comparada com a linha de outra e o sistema
        // "aprendia" trocas falsas (ex.: Netflix virava Supermercado, 11,00 virava 123,00).
        baseCorrecao.current.set(`${extraida.arquivo_hash}:${l.id}`, {
          data_compra: l.data_compra,
          descricao: l.descricao,
          valor: l.valor,
        });
      }
    }
    return {
      ...extraida,
      lancamentos: categorizados,
      arquivo: file,
      duplicada: !!jaExiste,
      conflitoMes: await conflitoDoMes(extraida, destinoPadrao(extraida)),
      destino: destinoPadrao(extraida),
    };
  }

  /** Fatura já importada do mesmo cartão (ou do banco, se o cartão não é conhecido) no mesmo mês. */
  async function conflitoDoMes(
    f: { banco: string; competencia?: string | null; vencimento?: string | null },
    destino: string,
  ): Promise<ConflitoMes | null> {
    const comp = f.competencia ?? f.vencimento?.slice(0, 7) ?? null;
    if (!comp) return null;
    const [tipo, id] = String(destino ?? "").split(":");
    const cartaoId = tipo === "cartao" && id ? id : null;
    const base = supabase.from("import_faturas").select("id,arquivo_nome,created_at").eq("competencia", comp);
    const { data, error } = await (cartaoId ? base.eq("cartao_id", cartaoId) : base.eq("banco", f.banco))
      .order("created_at", { ascending: false })
      .limit(1);
    if (error) return null;
    return (data?.[0] as ConflitoMes | undefined) ?? null;
  }

  async function onFiles(files: FileList | null) {
    if (!files?.length) return;
    setLendo(true);
    try {
      const novos: FaturaItem[] = [];
      for (const file of Array.from(files)) {
        if (file.type !== "application/pdf" && !file.name.toLowerCase().endsWith(".pdf")) {
          toast.error(`${file.name}: apenas PDF é aceito.`);
          continue;
        }
        try {
          novos.push(await processarArquivoUnico(file));
        } catch (erro) {
          if (erro instanceof ErroLeituraPdf && erro.codigo === "senha_necessaria") {
            setPdfsComSenha((prev) => [...prev, { file, senha: "", erro: null, tentando: false }]);
          } else if (erro instanceof ErroLeituraPdf) {
            toast.error(`${file.name}: ${erro.message}`);
          } else {
            toast.error(`${file.name}: ocorreu um erro ao ler o PDF.`);
          }
        }
      }
      setFaturas((prev) => [...prev, ...novos]);
      if (novos.length) toast.success(`${novos.length} fatura(s) lida(s).`);
    } finally {
      setLendo(false);
      if (inputRef.current) inputRef.current.value = "";
    }
  }

  /** Tenta de novo um PDF protegido, agora com a senha informada pelo usuário. */
  async function tentarComSenha(file: File) {
    const alvo = pdfsComSenha.find((p) => p.file === file);
    if (!alvo || !alvo.senha) return;
    setPdfsComSenha((prev) =>
      prev.map((p) => (p.file === file ? { ...p, tentando: true, erro: null } : p)),
    );
    try {
      const item = await processarArquivoUnico(file, alvo.senha);
      setFaturas((prev) => [...prev, item]);
      setPdfsComSenha((prev) => prev.filter((p) => p.file !== file));
      toast.success(`${file.name}: fatura lida.`);
    } catch (erro) {
      const mensagem =
        erro instanceof ErroLeituraPdf
          ? erro.message
          : "Não foi possível ler o PDF com essa senha.";
      setPdfsComSenha((prev) =>
        prev.map((p) => (p.file === file ? { ...p, tentando: false, erro: mensagem } : p)),
      );
    }
  }

  /** Interpreta o bloco colado (extrato, planilha, mensagens) e cria um lote editável. */
  async function importarColado() {
    const linhas = interpretarBloco(colado, {
      perfis: (profiles as any[]).map((p) => p.nome),
      cartoes: (cartoes as any[]).map((c) => ({ final: c.final, banco: c.bancos?.nome ?? null })),
    });
    if (!linhas.length) {
      toast.error("Não encontrei linhas com data, descrição e valor.");
      return;
    }
    const hoje = new Date().toISOString().slice(0, 10);
    const lancamentos: LancamentoExtraido[] = linhas.map((l, i) => ({
      id: `colado-${i}-${Math.random().toString(36).slice(2, 8)}`,
      data_compra: l.data ?? hoje,
      descricao: l.descricao,
      descricao_normalizada: chaveEstabelecimento(l.descricao),
      valor: l.valor,
      moeda: "BRL",
      direcao: "debito",
      parcela_numero: 1,
      parcela_total: 1,
      cartao_final: null,
      responsavel: null,
      categoria: "Outros",
      confianca_data: l.data ? "alta" : "baixa",
      valor_estimado: false,
      incluir: true,
    }));
    const hash = await hashTexto(colado);
    const item: FaturaItem = {
      banco: "desconhecido",
      arquivo_nome: `Colado em ${new Date().toLocaleString("pt-BR")}`,
      arquivo_hash: hash,
      paginas: 0,
      vencimento: null,
      competencia: null,
      total_declarado: null,
      limite_total: null,
      limite_utilizado: null,
      limite_disponivel: null,
      finais: [],
      lancamentos: categorizar(lancamentos),
      texto: colado,
      arquivo: null,
      destino: "",
    };
    setFaturas((prev) => [...prev, item]);
    setColado("");
    toast.success(`${linhas.length} lançamento(s) interpretado(s).`);
  }

  /** Processa prints (JPG/PNG/WEBP) por OCR no navegador e cria um lote editável por imagem. */
  async function onImages(files: FileList | null) {
    if (!files?.length) return;
    const imgs = Array.from(files).filter(
      (f) => /image\//.test(f.type) || /\.(png|jpe?g|webp)$/i.test(f.name),
    );
    if (!imgs.length) {
      toast.error("Selecione imagens (PNG, JPG ou WEBP).");
      return;
    }
    const lote = imgs.slice(0, 10);
    if (imgs.length > 10) toast.info(`Limite de 10 imagens por lote. ${lote.length} processadas.`);
    setLendoImagens(true);
    try {
      const novos: FaturaItem[] = [];
      for (const [i, file] of lote.entries()) {
        try {
          const texto = await ocrImagem(file);
          const { lancamentos, banco, finais } = lancamentosDeOcr(texto);
          const linhas = lancamentos.length
            ? lancamentos
            : [
                {
                  id: `vazio-${i}`,
                  data_compra: "",
                  descricao: "",
                  descricao_normalizada: "",
                  valor: 0,
                  moeda: "BRL",
                  direcao: "debito",
                  parcela_numero: 1,
                  parcela_total: 1,
                  cartao_final: null,
                  responsavel: null,
                  categoria: "outros",
                  confianca_data: "baixa",
                  valor_estimado: false,
                  incluir: true,
                } as (typeof lancamentos)[number],
              ];
          const arquivo_hash = await hashTextoOcr(`${file.name}-${texto}`);
          const { data: jaExiste } = await supabase
            .from("import_faturas")
            .select("id")
            .eq("arquivo_hash", arquivo_hash)
            .maybeSingle();
          const extraida = {
            banco,
            arquivo_nome: file.name,
            arquivo_hash,
            paginas: 1,
            vencimento: null,
            competencia: null,
            total_declarado: null,
            limite_total: null,
            limite_utilizado: null,
            limite_disponivel: null,
            finais,
            lancamentos: categorizar(linhas),
            texto,
          };
          novos.push({
            ...extraida,
            arquivo: null,
            duplicada: !!jaExiste,
            conflitoMes: await conflitoDoMes(extraida, destinoPadrao(extraida)),
            destino: destinoPadrao(extraida),
          });
          if (lancamentos.length)
            toast.success(`${file.name}: ${lancamentos.length} linha(s) reconhecida(s).`);
          else
            toast.warning(
              `${file.name}: não reconheci lançamentos. Deixei uma linha em branco para preencher.`,
            );
        } catch {
          toast.error(`${file.name}: não consegui ler a imagem.`);
        }
      }
      if (novos.length) setFaturas((prev) => [...prev, ...novos]);
    } finally {
      setLendoImagens(false);
      if (imgInputRef.current) imgInputRef.current.value = "";
    }
  }

  /** Etapa E (plano-importacao-v2.md): planilha Excel/CSV de qualquer
   * banco, com auto-detecção de colunas (ver `importacao-planilha.ts`). */
  async function importarPlanilha(files: FileList | null) {
    if (!files?.length) return;
    const lote = Array.from(files).filter((f) => /\.(xlsx|csv)$/i.test(f.name));
    if (!lote.length) {
      toast.error("Selecione um arquivo .xlsx ou .csv.");
      return;
    }
    setLendoPlanilha(true);
    try {
      const novos: FaturaItem[] = [];
      for (const file of lote) {
        try {
          const { linhas, colunas } = await lerPlanilhaImportacao(file);
          if (!linhas.length) {
            toast.error(
              !colunas.descricao || !colunas.valor
                ? `${file.name}: não encontrei colunas de descrição e valor na planilha.`
                : `${file.name}: nenhuma linha com descrição e valor válidos.`,
            );
            continue;
          }
          const hoje = new Date().toISOString().slice(0, 10);
          const lancamentos: LancamentoExtraido[] = linhas.map((l, i) => ({
            id: `planilha-${i}-${Math.random().toString(36).slice(2, 8)}`,
            data_compra: l.data ?? hoje,
            descricao: l.descricao,
            descricao_normalizada: chaveEstabelecimento(l.descricao),
            valor: l.valor,
            moeda: "BRL",
            direcao: l.direcao,
            parcela_numero: l.parcela_numero,
            parcela_total: l.parcela_total,
            cartao_final: null,
            responsavel: null,
            categoria: "Outros",
            confianca_data: l.data ? "alta" : "baixa",
            valor_estimado: false,
            incluir: true,
          }));
          const arquivo_hash = await hashTexto(`${file.name}-${file.size}-${file.lastModified}`);
          const { data: jaExiste } = await supabase
            .from("import_faturas")
            .select("id")
            .eq("arquivo_hash", arquivo_hash)
            .maybeSingle();
          const extraida = {
            banco: "desconhecido" as BancoFatura,
            arquivo_nome: file.name,
            arquivo_hash,
            paginas: 0,
            vencimento: null,
            competencia: null,
            total_declarado: null,
            limite_total: null,
            limite_utilizado: null,
            limite_disponivel: null,
            finais: [],
            lancamentos: categorizar(lancamentos),
            texto: "",
          };
          novos.push({
            ...extraida,
            arquivo: null,
            duplicada: !!jaExiste,
            conflitoMes: await conflitoDoMes(extraida, destinoPadrao(extraida)),
            destino: destinoPadrao(extraida),
          });
          toast.success(`${file.name}: ${linhas.length} lançamento(s) interpretado(s).`);
        } catch (erro) {
          toast.error(
            erro instanceof Error
              ? `${file.name}: ${erro.message}`
              : `${file.name}: não consegui ler a planilha.`,
          );
        }
      }
      if (novos.length) setFaturas((prev) => [...prev, ...novos]);
    } finally {
      setLendoPlanilha(false);
      if (planilhaInputRef.current) planilhaInputRef.current.value = "";
    }
  }

  function atualizarFatura(idx: number, patch: Partial<FaturaItem>) {
    setFaturas((prev) => prev.map((f, i) => (i === idx ? { ...f, ...patch } : f)));
  }

  const cadastrarDestino = useMutation({
    mutationFn: async () => {
      if (!cadastroDestino) throw new Error("Escolha uma fatura.");
      if (cadastroDestino.tipo === "banco") {
        const nome = nomeBancoNovo.trim();
        if (nome.length < 2) throw new Error("Informe o nome do banco ou conta.");
        const { data, error } = await supabase
          .from("bancos")
          .insert({ nome, tipo_conta: "outros", titular: profiles[0]?.nome ?? null })
          .select("*")
          .single();
        if (error) throw error;
        qc.setQueryData(["bancos"], (anterior: typeof bancos | undefined) => [
          ...(anterior ?? []),
          data,
        ]);
        return `banco:${data.id}`;
      }
      const final = cartaoNovo.final.trim();
      if (!/^\d{4}$/.test(final)) throw new Error("Informe os quatro últimos dígitos do cartão.");
      if (!cartaoNovo.titular.trim()) throw new Error("Informe o titular do cartão.");
      const { data, error } = await supabase
        .from("cartoes")
        .insert({
          apelido: cartaoNovo.apelido.trim() || `Cartão •${final}`,
          final,
          titular: cartaoNovo.titular.trim(),
          banco_id: cartaoNovo.bancoId || null,
          bandeira: "Não informada",
          tipo: "credito",
        })
        .select("*, bancos(nome)")
        .single();
      if (error) throw error;
      qc.setQueryData(["cartoes"], (anterior: typeof cartoes | undefined) => [
        ...(anterior ?? []),
        data,
      ]);
      return `cartao:${data.id}`;
    },
    onSuccess: (destino) => {
      setFaturas((atuais) =>
        atuais.map((f) =>
          f.arquivo_hash === cadastroDestino?.arquivoHash ? { ...f, destino } : f,
        ),
      );
      setCadastroDestino(null);
      toast.success("Cadastro concluído. Continue a importação normalmente.");
    },
    onError: (erro: Error) => toast.error(erro.message),
  });

  function atualizarLancamento(idx: number, id: string, patch: Partial<LancamentoExtraido>) {
    setLinhaComErro((atual) => (atual === id ? null : atual));
    if ("categoria" in patch || "subcategoria" in patch) {
      classificacoesEditadas.current.add(`${faturas[idx]?.arquivo_hash}:${id}`);
    }
    setFaturas((prev) =>
      prev.map((f, i) =>
        i === idx
          ? { ...f, lancamentos: f.lancamentos.map((l) => (l.id === id ? { ...l, ...patch } : l)) }
          : f,
      ),
    );
  }

  async function gravarRegra(l: LancamentoExtraido) {
    const chave = chaveEstabelecimento(l.descricao);
    const item = {
      texto_original: l.descricao,
      estabelecimento_normalizado: chave,
      tipo_regra: "de_para",
      categoria: l.categoria,
      subcategoria: l.subcategoria ?? null,
      prioridade: 300,
      ativo: true,
      created_by: user?.id ?? null,
    };
    const { data: existente } = await supabase
      .from("categoria_regras")
      .select("id")
      .eq("estabelecimento_normalizado", chave)
      .eq("tipo_regra", "de_para")
      .maybeSingle();
    if (existente) {
      const { error } = await supabase.from("categoria_regras").update(item).eq("id", existente.id);
      if (error) throw error;
    } else {
      const { error } = await supabase.from("categoria_regras").insert(item);
      if (error) throw error;
    }
    const { data: categoriaExistente, error: buscaCategoriaErro } = await supabase
      .from("categorias")
      .select("id")
      .eq("tipo", "despesa")
      .ilike("nome", l.categoria)
      .limit(1)
      .maybeSingle();
    if (buscaCategoriaErro) throw buscaCategoriaErro;
    if (!categoriaExistente) {
      const { error } = await supabase
        .from("categorias")
        .insert({ nome: l.categoria, tipo: "despesa" });
      if (error) throw error;
    }
  }

  /** Etapa F: grava a(s) diferença(s) entre o valor atual do lançamento e
   * sua linha de base (`baseCorrecao`) como correção aprendida para esta
   * assinatura de layout — e passa a ser a nova linha de base, pra não
   * reoferecer "Ensinar" de novo sem uma edição nova. */
  const ensinarCorrecao = useMutation({
    mutationFn: async ({
      assinatura,
      hash,
      l,
      somenteDescricao = false,
    }: {
      assinatura: string;
      hash: string;
      l: LancamentoExtraido;
      somenteDescricao?: boolean;
    }) => {
      const base = baseCorrecao.current.get(`${hash}:${l.id}`);
      if (!base) return 0;
      const diffs: {
        campo: "data_compra" | "descricao" | "valor";
        original: string;
        corrigido: string;
      }[] = [];
      if (!somenteDescricao && base.data_compra !== l.data_compra) {
        diffs.push({ campo: "data_compra", original: base.data_compra, corrigido: l.data_compra });
      }
      if (base.descricao !== l.descricao) {
        diffs.push({ campo: "descricao", original: base.descricao, corrigido: l.descricao });
      }
      if (!somenteDescricao && base.valor !== l.valor) {
        diffs.push({
          campo: "valor",
          original: base.valor.toFixed(2),
          corrigido: l.valor.toFixed(2),
        });
      }
      if (!diffs.length) return 0;
      for (const d of diffs) {
        const { error } = await supabase.from("fatura_correcoes_usuario").upsert(
          {
            assinatura,
            campo: d.campo,
            valor_original: d.original,
            valor_corrigido: d.corrigido,
            created_by: user?.id ?? null,
          },
          { onConflict: "assinatura,campo,valor_original" },
        );
        if (error) throw error;
      }
      baseCorrecao.current.set(`${hash}:${l.id}`, {
        data_compra: l.data_compra,
        descricao: l.descricao,
        valor: l.valor,
      });
      return diffs.length;
    },
    onSuccess: (n: number) => {
      void n;
    },
    onError: (e: any) => toast.error(e?.message ?? "Não foi possível salvar a correção."),
  });


  /**
   * "Ajustar a fixa a partir desta competência": encerra a recorrência antiga
   * no mês anterior e cria a continuação com o novo valor, levando junto as
   * ocorrências já geradas (e pagas) deste mês em diante. Os meses anteriores
   * não mudam. Se a competência é o próprio início da fixa, só troca o valor.
   */
  async function ajustarFixaAPartirDe(p: {
    fixaId: string;
    grupoId: string;
    competencia: string;
    valor: number;
    faturaId: string;
  }) {
    const { data: fixa, error } = await supabase
      .from("despesas")
      .select("*")
      .eq("id", p.fixaId)
      .eq("grupo_id", p.grupoId)
      .single();
    if (error || !fixa) throw new Error("A despesa fixa escolhida não está disponível neste grupo.");
    const f = fixa as any;
    const inicio: string = f.recorrencia_inicio ?? f.data_primeira_parcela;
    const decorridos = mesesEntreCompetencias(inicio, p.competencia);
    const deData = `${p.competencia}-01`;
    const centavos = Math.round(p.valor * 100);
    let alvoId: string = f.id;
    if (decorridos <= 0) {
      const { error: e1 } = await supabase
        .from("despesas")
        .update({ valor_total: p.valor, valor_total_centavos: centavos } as any)
        .eq("id", f.id);
      if (e1) throw e1;
    } else {
      const restantes = f.recorrencia_sem_prazo
        ? null
        : Math.max(1, Number(f.recorrencia_meses ?? decorridos + 1) - decorridos);
      const { error: e1 } = await supabase
        .from("despesas")
        .update({ recorrencia_sem_prazo: false, recorrencia_meses: decorridos } as any)
        .eq("id", f.id);
      if (e1) throw e1;
      const { id: _id, created_at: _c, updated_at: _u, parcelas: _p, ...resto } = f;
      const inicioNovo = vencimentoDaCompetencia(inicio, p.competencia);
      const { data: nova, error: e2 } = await supabase
        .from("despesas")
        .insert({
          ...resto,
          valor_total: p.valor,
          valor_total_centavos: centavos,
          data_compra: inicioNovo,
          data_primeira_parcela: inicioNovo,
          recorrencia_inicio: inicioNovo,
          recorrencia_sem_prazo: !!f.recorrencia_sem_prazo,
          recorrencia_meses: restantes,
          created_by: user?.id ?? f.created_by ?? null,
        } as any)
        .select("id")
        .single();
      if (e2 || !nova) throw e2 ?? new Error("Não foi possível criar a continuação da fixa.");
      alvoId = nova.id;
      const { error: e3 } = await supabase
        .from("parcelas")
        .update({ despesa_id: alvoId } as any)
        .eq("despesa_id", f.id)
        .gte("vencimento", deData);
      if (e3) throw e3;
    }
    const { error: e4 } = await supabase
      .from("parcelas")
      .update({ valor: p.valor } as any)
      .eq("despesa_id", alvoId)
      .gte("vencimento", deData)
      .eq("paga", false);
    if (e4) throw e4;
    const { data: doMes } = await supabase
      .from("parcelas")
      .select("id")
      .eq("despesa_id", alvoId)
      .gte("vencimento", deData)
      .lt("vencimento", `${somarMeses(p.competencia, 1)}-01`)
      .maybeSingle();
    if (doMes) {
      const { error: e5 } = await supabase
        .from("parcelas")
        .update({ fatura_id: p.faturaId, origem: "importacao_vinculo" } as any)
        .eq("id", doMes.id);
      if (e5) throw e5;
    }
  }

  const backupsRecentes = useQuery({
    queryKey: ["importacao-backups"],
    queryFn: async () => {
      const { data, error } = await (supabase as any)
        .from("importacao_backups")
        .select("id,cartao_id,competencia,criado_em")
        .eq("status", "ativo")
        .order("criado_em", { ascending: false })
        .limit(5);
      if (error) throw error;
      return (data ?? []) as { id: string; cartao_id: string; competencia: string; criado_em: string }[];
    },
  });

  const faturasFechadasLista = useQuery({
    queryKey: ["import-faturas-fechadas"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("import_faturas")
        .select("id, arquivo_nome, banco, cartao_id, competencia, status, total_declarado, total_extraido, created_at, fechada_em")
        .is("arquivo_excluido_em", null)
        .order("competencia", { ascending: false })
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as any[];
    },
  });

  const excluirFaturaFechada = useMutation({
    mutationFn: async (fatura: any) => {
      if (exclusaoBloqueada) throw new Error("Seu perfil não possui permissão para excluir dados.");
      // 1. Busca todas as parcelas vinculadas a essa fatura
      const { data: parcFatura, error: pErr } = await supabase
        .from("parcelas")
        .select("*, despesas(*)")
        .eq("fatura_id", fatura.id);
      if (pErr) throw pErr;

      // 2. Salva backup para permitir desfazer
      const despesasIds = [...new Set((parcFatura ?? []).map((p: any) => p.despesa_id))];
      let despesasSalvas: any[] = [];
      if (despesasIds.length) {
        const { data: dData } = await supabase.from("despesas").select("*").in("id", despesasIds);
        despesasSalvas = dData ?? [];
      }

      const { data: userSess } = await supabase.auth.getUser();
      const grupoId = (userSess?.user?.user_metadata as any)?.grupo_id ?? null;

      await (supabase as any).from("importacao_backups").insert({
        grupo_id: grupoId,
        cartao_id: fatura.cartao_id,
        competencia: fatura.competencia,
        faturas_antigas: [fatura.id],
        faturas_novas: [],
        dados: { despesas: despesasSalvas, parcelas: parcFatura ?? [] },
        status: "ativo",
      });

      // 3. Remove parcelas desta fatura
      const parcIds = (parcFatura ?? []).map((p: any) => p.id);
      if (parcIds.length) {
        const { error: delPErr } = await supabase.from("parcelas").delete().in("id", parcIds);
        if (delPErr) throw delPErr;
      }

      // 4. Remove despesas que ficaram sem nenhuma parcela
      if (despesasIds.length) {
        const { data: restantes } = await supabase
          .from("parcelas")
          .select("despesa_id")
          .in("despesa_id", despesasIds);
        const aindaTem = new Set((restantes ?? []).map((r: any) => r.despesa_id));
        const semParcelas = despesasIds.filter((id) => !aindaTem.has(id));
        if (semParcelas.length) {
          await supabase.from("despesas").delete().in("id", semParcelas);
        }
      }

      // 5. Marca a fatura como excluída
      await supabase
        .from("import_faturas")
        .update({
          arquivo_excluido_em: new Date().toISOString(),
          arquivo_excluido_por: userSess?.user?.id ?? null,
        })
        .eq("id", fatura.id);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["despesas"] });
      qc.invalidateQueries({ queryKey: ["parcelas"] });
      qc.invalidateQueries({ queryKey: ["fatura-mes"] });
      qc.invalidateQueries({ queryKey: ["import-faturas-fechadas"] });
      qc.invalidateQueries({ queryKey: ["importacao-backups"] });
      toast.success("Fatura fechada excluída com sucesso. Você pode desfazer a qualquer momento.");
    },
    onError: (e: any) => toast.error(e?.message ?? "Não foi possível excluir a fatura."),
  });

  const desfazerSubstituicao = useMutation({
    mutationFn: async (backupId: string) => {
      const { data: bk, error: bkErr } = await (supabase as any)
        .from("importacao_backups")
        .select("*")
        .eq("id", backupId)
        .single();
      if (bkErr) throw bkErr;
      const novasFaturas: string[] = bk.faturas_novas ?? [];
      if (novasFaturas.length) {
        // 1. Apaga o que a importação substituta gravou.
        const { data: pNovas, error: pErr } = await supabase
          .from("parcelas")
          .select("id,despesa_id")
          .in("fatura_id", novasFaturas);
        if (pErr) throw pErr;
        const idsParcNovas = (pNovas ?? []).map((p) => p.id);
        if (idsParcNovas.length) {
          const { error } = await supabase.from("parcelas").delete().in("id", idsParcNovas);
          if (error) throw error;
        }
        const { data: dPorFatura, error: dErr } = await supabase
          .from("despesas")
          .select("id")
          .in("fatura_id", novasFaturas);
        if (dErr) throw dErr;
        const candidatos = [
          ...new Set([
            ...(pNovas ?? []).map((p) => p.despesa_id),
            ...(dPorFatura ?? []).map((d) => d.id),
          ]),
        ];
        if (candidatos.length) {
          // Só compras criadas depois do backup; as antigas que continuam em outra fatura ficam.
          const { data: criadas, error: cErr } = await supabase
            .from("despesas")
            .select("id,created_at")
            .in("id", candidatos);
          if (cErr) throw cErr;
          const corte = new Date(bk.criado_em).getTime();
          const novas = (criadas ?? [])
            .filter((d) => new Date(d.created_at).getTime() >= corte)
            .map((d) => d.id);
          if (novas.length) {
            const { data: restantes, error: rErr } = await supabase
              .from("parcelas")
              .select("despesa_id")
              .in("despesa_id", novas);
            if (rErr) throw rErr;
            const comParcela = new Set((restantes ?? []).map((p) => p.despesa_id));
            const apagar = novas.filter((id) => !comParcela.has(id));
            if (apagar.length) {
              const { error } = await supabase.from("despesas").delete().in("id", apagar);
              if (error) throw error;
            }
          }
        }
        const apagarFaturas = novasFaturas.filter((id) => !(bk.faturas_antigas ?? []).includes(id));
        if (apagarFaturas.length) {
          const { error: impErr } = await supabase.from("import_faturas").delete().in("id", apagarFaturas);
          if (impErr) throw impErr;
        }
      }
      // 2. Restaura a fatura anterior como estava no backup.
      const dados = (bk.dados ?? {}) as { despesas?: any[]; parcelas?: any[] };
      if (dados.despesas?.length) {
        const { error } = await supabase.from("despesas").upsert(dados.despesas as any, { onConflict: "id" });
        if (error) throw error;
      }
      if (dados.parcelas?.length) {
        const { error } = await supabase.from("parcelas").upsert(dados.parcelas as any, { onConflict: "id" });
        if (error) throw error;
      }
      const { error: stErr } = await (supabase as any)
        .from("importacao_backups")
        .update({ status: "desfeito", desfeito_em: new Date().toISOString() })
        .eq("id", backupId);
      if (stErr) throw stErr;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["despesas"] });
      qc.invalidateQueries({ queryKey: ["parcelas"] });
      qc.invalidateQueries({ queryKey: ["fatura-mes"] });
      qc.invalidateQueries({ queryKey: ["import-faturas"] });
      qc.invalidateQueries({ queryKey: ["importacao-backups"] });
      toast.success("Substituição desfeita. A fatura anterior voltou como estava.");
    },
    onError: (e: any) => toast.error(e?.message ?? "Não foi possível desfazer a substituição."),
  });

  const confirmar = useMutation({
    mutationFn: async (conflitos: Record<string, ConflitoSubst>) => {
      if (!user?.id) throw new Error("Entre na sua conta para importar faturas.");
      setLinhaComErro(null);
      const totalLinhas = Math.max(
        1,
        faturas.reduce((s, fat) => s + fat.lancamentos.filter((x) => x.incluir).length, 0),
      );
      let linhasFeitas = 0;
      setProgresso({ feitos: 0, total: totalLinhas, etapa: "Preparando a gravação" });
      const { data: perfil, error: perfilErr } = await supabase
        .from("profiles")
        .select("grupo_id")
        .eq("id", user.id)
        .single();
      if (perfilErr) throw perfilErr;
      if (!perfil.grupo_id) throw new Error("Não foi possível identificar o seu grupo.");
      const grupoId = perfil.grupo_id;
      const totaisPendentes: string[] = [];
      const fechamentosManuais: string[] = [];

      // Cria na hora a macro e a subcategoria que ainda não existem, e grava o
      // aprendizado do grupo: o próximo lançamento deste estabelecimento já vem
      // classificado (ex.: LANCHONETE DA MARIA sempre em Restaurante).
      const incluidas = faturas.flatMap((f) => f.lancamentos.filter((l) => l.incluir));
      const macrosUsadas = new Set(incluidas.map((l) => l.categoria).filter(Boolean));
      const { data: catsExistentes } = await supabase
        .from("categorias")
        .select("nome")
        .eq("tipo", "despesa");
      const nomesCats = new Set((catsExistentes ?? []).map((c: any) => String(c.nome).toLowerCase()));
      for (const nome of macrosUsadas) {
        if (nomesCats.has(nome.toLowerCase())) continue;
        const { error } = await supabase.from("categorias").insert({ nome, tipo: "despesa" });
        if (error && !String(error.message).includes("duplicate")) throw error;
        nomesCats.add(nome.toLowerCase());
      }
      const subsNovas = new Map<string, { categoria: string; nome: string }>();
      for (const l of incluidas) {
        if (!l.subcategoria) continue;
        const jaExiste = estrutura.find((e) => e.macro === l.categoria)?.subcategorias ?? [];
        if (jaExiste.includes(l.subcategoria)) continue;
        subsNovas.set(`${l.categoria}|${l.subcategoria}`, { categoria: l.categoria, nome: l.subcategoria });
      }
      for (const sub of subsNovas.values()) {
        const { error } = await (supabase as any)
          .from("subcategorias")
          .insert({ categoria: sub.categoria, nome: sub.nome, tipo: "despesa" });
        if (error && !String(error.message).includes("duplicate")) throw error;
      }
      // Aprendizado global: um voto por estabelecimento para o grupo (o banco aceita só categorias padrão).
      try {
        const votos = new Map<string, string>();
        faturas.forEach((f) =>
          f.lancamentos.forEach((l) => {
            if (!l.incluir || !l.categoria || l.categoria === CATEGORIA_A_CONFIRMAR) return;
            const chave = chaveEstabelecimento(l.descricao);
            if (chave && !votos.has(chave)) votos.set(chave, l.categoria);
          }),
        );
        if (votos.size) {
          await (supabase as any).rpc("registrar_votos_classificacao", {
            p_votos: [...votos].map(([chave, categoria]) => ({ chave, categoria })),
          });
        }
      } catch {
        /* o aprendizado global não pode impedir a importação */
      }
      await lembrarClassificacoes(
        grupoId,
        user.id,
        incluidas.map((l) => ({
          descricao: l.descricao,
          categoria: l.categoria,
          subcategoria: l.subcategoria ?? null,
          tipo: l.tipo ?? "variavel",
        })),
      );
      for (const f of faturas) {
        const [tipoDestino, idDestino] = String(f.destino ?? "").split(":");
        const ids = new Set<string>();
        if (tipoDestino === "cartao" && idDestino) ids.add(idDestino);
        f.lancamentos.forEach((l) => {
          const c = acharCartao(f.banco, l.cartao_final);
          if (c?.id) ids.add(c.id);
        });
        const comp = f.competencia ?? f.vencimento?.slice(0, 7);
        if (!comp || !ids.size) continue;
        const { data } = await supabase
          .from("fatura_mes")
          .select("id,cartao_id,competencia")
          .in("cartao_id", [...ids])
          .eq("competencia", comp)
          .eq("modo_calculo", "somente_total")
          .eq("status", "aberta");
        if (data?.length) {
          totaisPendentes.push(`${f.arquivo_nome} (${comp})`);
          fechamentosManuais.push(...data.map((r: any) => String(r.id)));
        }
      }
      if (
        totaisPendentes.length &&
        !window.confirm(
          `Há um total manual para:\n\n${totaisPendentes.join("\n")}\n\nDeseja concluir esse lançamento e usar os itens desta importação? O total manual continuará no histórico, tachado.`,
        )
      )
        throw new Error("Importação cancelada para preservar o total manual.");
      const regrasAprendidas = new Map<string, LancamentoExtraido>();
      faturas.forEach((f) =>
        f.lancamentos.forEach((l) => {
          // Ao confirmar a fatura, toda categoria já definida vira regra do de-para (sem clicar em salvar).
          // Transferências e pagamentos a pessoas não viram regra: o nome do favorecido não é guardado.
          if (
            l.incluir &&
            l.categoria &&
            l.categoria !== CATEGORIA_A_CONFIRMAR &&
            !/\b(PIX|TED|DOC|TRANSF|TRANSFERENCIA|SAQUE|BOLETO)\b/i.test(l.descricao)
          ) {
            regrasAprendidas.set(chaveEstabelecimento(l.descricao), l);
          }
        }),
      );

      const { data: lote, error: loteErr } = await supabase
        .from("import_lotes")
        .insert({ created_by: user?.id ?? null, status: "confirmado" })
        .select("id")
        .single();
      if (loteErr) throw loteErr;

      // Fatura fechada: guarda o backup da fatura anterior (mesmo cartão e mês) e a
      // retira do banco antes de gravar a nova. "Desfazer" restaura esse backup.
      const backupPorHash = new Map<string, string>();
      const novasFaturas = new Map<string, string>();
      for (const f of faturas) {
        const conflito = conflitos[f.arquivo_hash];
        if (!conflito || decisaoFatura[f.arquivo_hash] !== "fechada") continue;
        const { data: pAnt, error: pErr } = await supabase
          .from("parcelas")
          .select("*")
          .in("fatura_id", conflito.faturas_antigas);
        if (pErr) throw pErr;
        const idsDesp = conflito.escopo_despesa_ids;
        let despesasAntigas: any[] = [];
        if (idsDesp.length) {
          const { data: dAnt, error: dErr } = await supabase
            .from("despesas")
            .select("*")
            .in("id", idsDesp);
          if (dErr) throw dErr;
          despesasAntigas = dAnt ?? [];
        }
        const faltantes = despesasFaltantes(
          despesasAntigas,
          f.lancamentos.filter((l) => l.incluir) as any[],
        );
        const decisao = decisaoFaltantes[f.arquivo_hash] ?? "nova";
        const { error: substErr } = await (supabase as any)
          .from("importacao_backups")
          .update({ status: "substituido" })
          .eq("cartao_id", conflito.cartao_id)
          .eq("competencia", conflito.competencia)
          .eq("status", "ativo");
        if (substErr) throw substErr;
        const { data: backup, error: bkErr } = await (supabase as any)
          .from("importacao_backups")
          .insert({
            created_by: user.id,
            grupo_id: grupoId,
            cartao_id: conflito.cartao_id,
            competencia: conflito.competencia,
            lote_id: lote.id,
            faturas_antigas: conflito.faturas_antigas,
            dados: {
              despesas: despesasAntigas,
              parcelas: pAnt ?? [],
              faltantes_ids: faltantes.map((d) => d.id),
              decisao,
            },
          })
          .select("id")
          .single();
        if (bkErr) throw bkErr;
        backupPorHash.set(f.arquivo_hash, backup.id);

        const idsParc = (pAnt ?? []).map((p) => p.id);
        if (idsParc.length) {
          const { error } = await supabase.from("parcelas").delete().in("id", idsParc);
          if (error) throw error;
        }
      }

      let inseridos = 0;
      let ignorados = 0;
      // Um lançamento já cadastrado só pode ser substituído por UMA linha.
      const alvosUsados = new Set<string>();
      let fechadas = 0;
      // Parcelas do mês anterior quitadas por causa do pagamento que veio na fatura.
      let quitadas = 0;

      // Etapa D: ponto final e autoritativo de aplicação das permissões de
      // importação — mesmo que algum estado de UI escapasse do bloqueio nos
      // controles (ex.: fatura adicionada por outro fluxo), nada entra no
      // banco fora do que o usuário tem permissão de importar.
      const permitido = (l: LancamentoExtraido) =>
        l.incluir && (l.parcela_total > 1 ? podeImportarParcelamentos : podeImportarLancamentos);

      for (const f of faturas) {
        const cartoesTocados = new Set<string>();
        const [tipoDestinoFatura, idDestinoFatura] = String(f.destino ?? "").split(":");
        const cartaoPrincipal =
          tipoDestinoFatura === "cartao"
            ? idDestinoFatura
            : (f.lancamentos.map((l) => acharCartao(f.banco, l.cartao_final)?.id).find(Boolean) ??
              null);
        // Etapa C (plano-importacao-v2, 2026-10-02): o arquivo em si nunca é
        // mais enviado ao Storage — só hash + metadados do lote (lidos
        // acima, antes deste loop) seguem gravados, pra evitar reimportar o
        // mesmo arquivo sem querer. `storage_path` fica sempre nulo agora;
        // a coluna continua existindo só por histórico de faturas já
        // importadas antes desta mudança.
        const path: string | null = null;

        const { data: fatura, error: fatErr } = await supabase
          .from("import_faturas")
          .upsert(
            {
              lote_id: lote.id,
              grupo_id: grupoId,
              banco: f.banco,
              arquivo_nome: f.arquivo_nome,
              arquivo_hash: f.arquivo_hash,
              storage_path: path,
              vencimento: f.vencimento,
              competencia: f.competencia,
              total_declarado: f.total_declarado,
              limite_total: podeImportarLimite ? f.limite_total : null,
              limite_utilizado: podeImportarLimite ? f.limite_utilizado : null,
              limite_disponivel: podeImportarLimite ? f.limite_disponivel : null,
              cartao_id: cartaoPrincipal || null,
              total_extraido: f.lancamentos
                .filter(permitido)
                .reduce((s, l) => s + (l.direcao === "credito" ? -l.valor : l.valor), 0),
              paginas: f.paginas,
              status: "importada",
            },
            { onConflict: "grupo_id,arquivo_hash" },
          )
          .select("id")
          .single();
        if (fatErr) throw fatErr;
        novasFaturas.set(f.arquivo_hash, fatura.id);

        // Linhas idênticas na mesma fatura (ex.: duas linhas de telefone de mesmo valor) são gastos
        // distintos: a segunda ocorrência ganha chave própria em vez de ser tomada como já importada.
        const ocorrenciasNaFatura = new Map<string, number>();
        for (const l of f.lancamentos.filter(permitido)) {
          linhasFeitas++;
          setProgresso({
            feitos: Math.min(linhasFeitas, totalLinhas),
            total: totalLinhas,
            etapa: `Gravando ${f.arquivo_nome}`,
          });
          const dup = acoesDuplicata[chaveDup(f.arquivo_hash, l.id)];
          // "Criar um novo" ganha uma chave própria: são dois gastos iguais de
          // verdade, então não podem colidir na chave de deduplicação.
          const chaveBase = dedupKey(l);
          const ocorrencia = (ocorrenciasNaFatura.get(chaveBase) ?? 0) + 1;
          ocorrenciasNaFatura.set(chaveBase, ocorrencia);
          const chaveSequencial = ocorrencia > 1 ? `${chaveBase}#seq${ocorrencia}` : chaveBase;
          // "Criar um novo" usa chave fixa por linha (sem horário): se a confirmação falhar no meio
          // e o usuário tentar de novo, a cópia já criada é reconhecida e não é gravada outra vez.
          // Antes a chave levava Date.now() e cada nova tentativa duplicava a linha.
          const chave = dup?.acao === "novo" ? `${chaveSequencial}#novo-${l.id}` : chaveSequencial;
          const { data: existente } = await supabase
            .from("despesas")
            .select("id")
            .eq("grupo_id", grupoId)
            .eq("dedup_key", chave)
            .maybeSingle();
          // Linha idêntica já importada antes: pula, a não ser que o usuário
          // tenha escolhido no popup o que fazer com ela.
          if (existente && (!dup || dup.acao === "novo")) {
            // A linha já existe. Mas, se esta fatura substitui a anterior do mesmo mês, as
            // parcelas ligadas à fatura antiga foram apagadas antes deste laço; sem refazê-las
            // a compra ficava sem parcela e era apagada no fim como órfã (Petz, Porto Seguro e
            // Spa sumiram assim). Aqui o calendário é completado e reancorado nesta fatura.
            const vencBase = f.vencimento ?? l.data_compra;
            const { data: atuaisExistente } = await supabase
              .from("parcelas")
              .select("id, numero")
              .eq("despesa_id", existente.id);
            const numerosExistentes = new Map<number, string>(
              ((atuaisExistente ?? []) as { id: string; numero: number }[]).map((x) => [
                Number(x.numero),
                x.id,
              ]),
            );
            let refeitas = 0;
            // Despesa fixa tem calendário próprio (recorrência); não é refeita por aqui.
            const totalRefazer = l.tipo === "fixa" ? 0 : Math.max(1, l.parcela_total);
            for (let numero = 1; numero <= totalRefazer; numero++) {
              const vencimento = vencimentoParcela(vencBase, l.parcela_numero, numero);
              const daFatura = numero === l.parcela_numero;
              const idParcela = numerosExistentes.get(numero);
              if (idParcela) {
                if (daFatura) {
                  await supabase
                    .from("parcelas")
                    .update({ vencimento, fatura_id: fatura.id } as any)
                    .eq("id", idParcela);
                }
                continue;
              }
              const { error: eRefaz } = await supabase.from("parcelas").insert({
                despesa_id: existente.id,
                grupo_id: grupoId,
                numero,
                total: Math.max(1, l.parcela_total),
                valor: l.valor,
                moeda: l.moeda,
                vencimento,
                paga: false,
                origem: "importacao",
                valor_estimado: !daFatura,
                fatura_id: daFatura ? fatura.id : null,
              } as any);
              if (eRefaz) throw eRefaz;
              refeitas++;
            }
            await supabase
              .from("despesas")
              .update({ fatura_id: fatura.id } as any)
              .eq("id", existente.id);
            if (refeitas) inseridos++;
            else ignorados++;
            continue;
          }
          if (existente && dup?.acao === "substituir" && !dup.alvoId) {
            dup.alvoId = existente.id;
          }

          const venc = f.vencimento ?? l.data_compra;
          const primeira = vencimentoParcela(venc, l.parcela_numero, 1);

          // Vincula ao cartão pelo final; senão usa o destino escolhido para a fatura.
          const cartaoLinha = acharCartao(f.banco, l.cartao_final);
          const [tipoDestino, idDestino] = String(f.destino ?? "").split(":");
          const cartaoId =
            cartaoLinha?.id ?? (tipoDestino === "cartao" ? (idDestino ?? null) : null);
          const bancoId = cartaoId ? null : tipoDestino === "banco" ? (idDestino ?? null) : null;
          const cartaoDestino = cartaoId
            ? ((cartoes as any[]).find((c) => c.id === cartaoId) ?? null)
            : null;

          // Escolha feita no popup de duplicidade (ver DuplicidadeDialog).
          if (dup?.acao === "manter_existente") {
            ignorados++;
            continue;
          }
          // A compra escolhida para substituir pode ter sido apagada por uma importação anterior
          // (a escolha ficou na tela). Sem ela no banco, grava como lançamento novo, sem FK quebrada.
          if (dup?.acao === "substituir" && dup.alvoId) {
            const { data: alvoAinda } = await supabase
              .from("despesas")
              .select("id")
              .eq("id", dup.alvoId)
              .eq("grupo_id", grupoId)
              .maybeSingle();
            if (!alvoAinda) dup.alvoId = null;
          }
          if (dup?.acao === "substituir" && dup.alvoId && !alvosUsados.has(dup.alvoId)) {
            alvosUsados.add(dup.alvoId);
            const chaveAlvo =
              existente && existente.id !== dup.alvoId ? `${chave}#sub-${dup.alvoId}` : chave;
            const { error: subErro } = await supabase
              .from("despesas")
              .update({
                descricao: l.descricao,
                descricao_normalizada: l.descricao_normalizada,
                valor_total: Number((l.valor * l.parcela_total).toFixed(2)),
                moeda: l.moeda,
                categoria: l.categoria,
                subcategoria: l.subcategoria ?? null,
                categoria_confirmada: l.categoria !== CATEGORIA_A_CONFIRMAR,
                estabelecimento_normalizado: chaveEstabelecimento(l.descricao),
                tipo: l.tipo ?? "variavel",
                data_compra: l.data_compra,
                total_parcelas: l.parcela_total,
                data_primeira_parcela: primeira,
                responsavel: l.responsavel,
                cartao_id: cartaoId,
                banco_id: bancoId,
                cartao_final: l.cartao_final ?? cartaoDestino?.final ?? null,
                direcao: l.direcao,
                origem: "importacao_substituicao",
                fatura_id: fatura.id,
                dedup_key: chaveAlvo,
              } as any)
              .eq("id", dup.alvoId)
              .eq("grupo_id", grupoId);
            if (subErro) throw subErro;
            // Refaz TODAS as parcelas com os dados da fatura, guardando o que
            // já estava pago. Antes só as não pagas eram refeitas, e a parcela
            // paga ficava com o vencimento antigo — o lançamento sumia do mês
            // da fatura e a soma da tela de Despesas não batia com a fatura.
            const { data: antigas } = await supabase
              .from("parcelas")
              .select("numero, paga, data_pagamento")
              .eq("despesa_id", dup.alvoId);
            const pagamentoPorNumero = new Map<number, string | null>(
              (antigas ?? [])
                .filter((x: any) => x.paga && x.data_pagamento)
                .map((x: any) => [Number(x.numero), x.data_pagamento ?? null]),
            );
            const { error: delParc } = await supabase
              .from("parcelas")
              .delete()
              .eq("despesa_id", dup.alvoId);
            if (delParc) throw delParc;
            const novas = Array.from({ length: l.parcela_total }, (_, i) => i + 1).map((numero) => {
              const paga = pagamentoPorNumero.has(numero);
              return {
                despesa_id: dup.alvoId,
                numero,
                total: l.parcela_total,
                valor: l.valor,
                moeda: l.moeda,
                vencimento: vencimentoParcela(venc, l.parcela_numero, numero),
                paga,
                data_pagamento: pagamentoPorNumero.get(numero) ?? null,
                origem: "importacao_substituicao",
                valor_estimado: numero !== l.parcela_numero,
                confianca_data: l.confianca_data,
                fatura_id: fatura.id,
                dedup_key: `${chaveAlvo}#${numero}`,
                grupo_id: grupoId,
              };
            });
            const { error: insParc } = await supabase.from("parcelas").insert(novas as any);
            if (insParc) throw insParc;
            if (cartaoId) cartoesTocados.add(cartaoId);
            inseridos++;
            continue;
          }

          const acaoFixa = acoesFixas[`${f.arquivo_hash}:${l.id}`];
          if (acaoFixa?.acao === "ignorar") {
            ignorados++;
            continue;
          }
          // Regra: depois que o usuário confirma, a importação segue a escolha dele. Nada de
          // conferência que trave aqui (a gravação não é transacional: travar no meio deixava
          // parte das linhas gravadas e gerava cópias a cada nova tentativa).
          const fixaEscolhida =
            acaoFixa &&
            (acaoFixa.acao === "substituir" ||
              acaoFixa.acao === "vincular" ||
              acaoFixa.acao === "ajustar")
              ? (
                  await supabase
                    .from("despesas")
                    .select(
                      "id, descricao, valor_total, tipo, direcao, cartao_id, cartao_final, banco_id, recorrencia_inicio, recorrencia_meses, data_primeira_parcela, total_parcelas",
                    )
                    .eq("id", acaoFixa.fixaId)
                    .eq("grupo_id", grupoId)
                    .maybeSingle()
                ).data
              : null;
          if (acaoFixa && fixaEscolhida) {
            const fixa = fixaEscolhida;
            const competencia = (f.competencia ?? l.data_compra).slice(0, 7);
            if (acaoFixa.acao === "ajustar") {
              await ajustarFixaAPartirDe({
                fixaId: fixa.id,
                grupoId,
                competencia,
                valor: l.valor,
                faturaId: fatura.id,
              });
              inseridos++;
              continue;
            }
            const { data: parcelaExistente, error: parcelaErro } = await supabase
              .from("parcelas")
              .select("id, fatura_id")
              .eq("despesa_id", fixa.id)
              .gte("vencimento", `${competencia}-01`)
              .lt("vencimento", `${somarMeses(competencia, 1)}-01`)
              .maybeSingle();
            if (parcelaErro) throw parcelaErro;
            // Se a ocorrência deste mês já estava ligada a outra fatura (ex.: importação anterior
            // do mesmo mês), ela passa a apontar para esta fatura, como o usuário escolheu.
            const inicio = fixa.recorrencia_inicio ?? fixa.data_primeira_parcela;
            const numero = mesesEntreCompetencias(inicio, competencia) + 1;
            const valores = {
              fatura_id: fatura.id,
              origem:
                acaoFixa.acao === "substituir" ? "importacao_substituicao" : "importacao_vinculo",
              ...(acaoFixa.acao === "substituir" ? { valor: l.valor, valor_estimado: false } : {}),
            };
            if (parcelaExistente) {
              const { error } = await supabase
                .from("parcelas")
                .update(valores)
                .eq("id", parcelaExistente.id);
              if (error) throw error;
            } else {
              const { error } = await supabase.from("parcelas").insert({
                despesa_id: fixa.id,
                grupo_id: grupoId,
                numero,
                total: fixa.recorrencia_meses ?? Math.max(numero, 1),
                valor: acaoFixa.acao === "substituir" ? l.valor : Number(fixa.valor_total),
                moeda: l.moeda,
                vencimento: vencimentoDaCompetencia(inicio, competencia),
                paga: false,
                ...valores,
              });
              if (error) throw error;
            }
            inseridos++;
            continue;
          }

          // Importar faturas de meses anteriores (histórico): a MESMA compra
          // parcelada aparece em várias faturas, só mudando o número da
          // parcela (3/12, 4/12...). O reconhecimento NÃO usa a data da compra: o Nubank,
          // por exemplo, mostra em cada fatura a data de lançamento da parcela (08 AGO na
          // fatura de setembro, 08 SET na de outubro), o que antes criava um parcelamento
          // novo a cada fatura (Wilca e Vetnasa em dobro). A compra é a mesma quando batem
          // estabelecimento, número de parcelas, valor total, cartão e o mês da 1ª parcela
          // calculado pela fatura (vencimento menos as parcelas já passadas).
          // Regra 4: a fatura nova é a verdade, então o calendário inteiro é reancorado nela.
          if (l.parcela_total > 1) {
            const valorTotalLinha = Number((l.valor * l.parcela_total).toFixed(2));
            const finalLinha = l.cartao_final ?? cartaoDestino?.final ?? null;
            const primeiraLinha = vencimentoParcela(venc, l.parcela_numero, 1).slice(0, 7);
            const { data: candidatos } = await supabase
              .from("despesas")
              .select("id, valor_total, cartao_final, data_compra, created_at")
              .eq("grupo_id", grupoId)
              .eq("estabelecimento_normalizado", chaveEstabelecimento(l.descricao))
              .eq("total_parcelas", l.parcela_total)
              .neq("tipo", "fixa")
              .order("created_at", { ascending: false });
            let mesmoParcelamento: { id: string } | null = null;
            for (const c of (candidatos ?? []) as any[]) {
              const valorOk =
                Math.abs(Number(c.valor_total) - valorTotalLinha) <=
                Math.max(0.05, valorTotalLinha * 0.01);
              const cartaoOk = !finalLinha || !c.cartao_final || c.cartao_final === finalLinha;
              if (!valorOk || !cartaoOk) continue;
              if (c.data_compra === l.data_compra) {
                mesmoParcelamento = c;
                break;
              }
              const { data: p1 } = await supabase
                .from("parcelas")
                .select("vencimento")
                .eq("despesa_id", c.id)
                .eq("numero", 1)
                .maybeSingle();
              if (p1?.vencimento && String(p1.vencimento).slice(0, 7) === primeiraLinha) {
                mesmoParcelamento = c;
                break;
              }
            }
            if (mesmoParcelamento) {
              const { data: atuais } = await supabase
                .from("parcelas")
                .select("id, numero")
                .eq("despesa_id", mesmoParcelamento.id);
              const porNumero = new Map<number, string>(
                ((atuais ?? []) as { id: string; numero: number }[]).map((x) => [
                  Number(x.numero),
                  x.id,
                ]),
              );
              for (let numero = 1; numero <= l.parcela_total; numero++) {
                const vencimento = vencimentoParcela(venc, l.parcela_numero, numero);
                const daFatura = numero === l.parcela_numero;
                const idExistente = porNumero.get(numero);
                if (idExistente) {
                  const { error: eAtual } = await supabase
                    .from("parcelas")
                    .update({
                      vencimento,
                      ...(daFatura
                        ? { valor: l.valor, valor_estimado: false, fatura_id: fatura.id }
                        : {}),
                    } as any)
                    .eq("id", idExistente);
                  if (eAtual) throw eAtual;
                } else {
                  const { error: eNova } = await supabase.from("parcelas").insert({
                    despesa_id: mesmoParcelamento.id,
                    numero,
                    total: l.parcela_total,
                    valor: l.valor,
                    moeda: l.moeda,
                    vencimento,
                    paga: false,
                    origem: "importacao",
                    valor_estimado: !daFatura,
                    confianca_data: l.confianca_data,
                    fatura_id: daFatura ? fatura.id : null,
                    grupo_id: grupoId,
                  } as any);
                  if (eNova) throw eNova;
                }
              }
              // Parcelas além do total (de um calendário antigo errado) saem.
              const sobrando = [...porNumero.entries()]
                .filter(([n]) => n > l.parcela_total)
                .map(([, id]) => id);
              if (sobrando.length) {
                await supabase.from("parcelas").delete().in("id", sobrando);
              }
              await supabase
                .from("despesas")
                .update({ data_primeira_parcela: vencimentoParcela(venc, l.parcela_numero, 1) } as any)
                .eq("id", mesmoParcelamento.id);
              if (cartaoId) cartoesTocados.add(cartaoId);
              inseridos++;
              continue;
            }
          }

          // Chegou aqui com a linha já gravada (ex.: a substituição escolhida não se aplicou):
          // gravar de novo duplicaria o gasto e o banco recusa a chave repetida.
          if (existente) {
            ignorados++;
            continue;
          }
          const { data: despesa, error: despErr } = await supabase
            .from("despesas")
            .insert({
              descricao: l.descricao,
              descricao_normalizada: l.descricao_normalizada,
              valor_total: Number((l.valor * l.parcela_total).toFixed(2)),
              moeda: l.moeda,
              categoria: l.categoria,
              subcategoria: l.subcategoria ?? null,
              categoria_sugerida: l.categoria_sugerida ?? null,
              confianca_categoria: l.confianca_categoria ?? null,
              categoria_confirmada: l.categoria !== CATEGORIA_A_CONFIRMAR,
              estabelecimento_normalizado: chaveEstabelecimento(l.descricao),
              tipo: l.tipo ?? "variavel",
              data_compra: l.data_compra,
              total_parcelas: l.parcela_total,
              data_primeira_parcela: primeira,
              // Marcar "Fixa" na importação já registra a recorrência (sem
              // prazo, mensal, sem reajuste) a partir deste mês — assim ela
              // passa a aparecer sozinha em todos os meses futuros, do
              // mesmo jeito que uma despesa fixa cadastrada em /despesas.
              // Só faz sentido pra lançamento não parcelado (parcela 1/1):
              // um item parcelado marcado como fixa por engano não deveria
              // virar recorrência sem prazo pelo valor total das parcelas.
              ...(l.tipo === "fixa" && l.parcela_total <= 1
                ? { recorrencia_inicio: primeira, recorrencia_sem_prazo: true }
                : {}),
              responsavel: l.responsavel,
              cartao_id: cartaoId,
              banco_id: bancoId,
              banco_nome: cartaoDestino?.bancos?.nome ?? BANCO_LABEL[f.banco],
              cartao_final: l.cartao_final ?? cartaoDestino?.final ?? null,
              direcao: l.direcao,
              origem: "importacao",
              fatura_id: fatura.id,
              dedup_key: chave,
              grupo_id: grupoId,
              created_by: user?.id ?? null,
            })
            .select("id")
            .single();
          if (despErr) throw despErr;

          const parcelas = Array.from({ length: l.parcela_total }, (_, i) => {
            const numero = i + 1;
            return {
              despesa_id: despesa.id,
              numero,
              total: l.parcela_total,
              valor: l.valor,
              moeda: l.moeda,
              vencimento: vencimentoParcela(venc, l.parcela_numero, numero),
              // Parcelas nascem em aberto. Só ficam pagas quando o usuário marca, ou quando a
              // fatura seguinte mostra o valor desta fatura como pago (ver pagouAnterior).
              paga: false,
              situacao_temporal:
                numero < l.parcela_numero
                  ? "passada"
                  : numero === l.parcela_numero
                    ? "atual"
                    : "futura",
              origem: "importacao",
              valor_estimado: numero !== l.parcela_numero,
              confianca_data: l.confianca_data,
              fatura_id: fatura.id,
              dedup_key: `${chave}#${numero}`,
              grupo_id: grupoId,
            };
          });
          const { error: parcErr } = await supabase.from("parcelas").insert(parcelas);
          if (parcErr) throw parcErr;
          if (cartaoId) cartoesTocados.add(cartaoId);
          inseridos++;
        }

        // Fatura real chegou: encerra a competência e remove a estimativa do mês.
        const comp = f.competencia ?? (f.vencimento ? f.vencimento.slice(0, 7) : null);
        if (comp && cartoesTocados.size) {
          for (const cartaoId of cartoesTocados) {
            const { data: rapida } = await supabase
              .from("fatura_mes")
              .select("id, despesa_avulsa_id, modo_calculo")
              .eq("cartao_id", cartaoId)
              .eq("competencia", comp)
              .maybeSingle();
            if (!rapida) continue;
            if (rapida.despesa_avulsa_id && rapida.modo_calculo === "somente_total") {
              await supabase
                .from("despesas")
                .update({ origem: "fatura_total_concluida" })
                .eq("id", rapida.despesa_avulsa_id);
            } else if (rapida.despesa_avulsa_id) {
              await supabase.from("parcelas").delete().eq("despesa_id", rapida.despesa_avulsa_id);
              await supabase.from("despesas").delete().eq("id", rapida.despesa_avulsa_id);
            }
            await supabase
              .from("fatura_mes")
              .update({
                status: "fechada",
                fechada_em: new Date().toISOString(),
                despesa_avulsa_id:
                  rapida.modo_calculo === "somente_total" ? rapida.despesa_avulsa_id : null,
                concluida_por_importacao_em: new Date().toISOString(),
                total_real: f.total_declarado ?? null,
              })
              .eq("id", rapida.id);
            fechadas++;
          }
          await supabase
            .from("import_faturas")
            .update({ status: "fechada", fechada_em: new Date().toISOString() })
            .eq("id", fatura.id);
        }

        // A fatura traz o pagamento do mês anterior ("PAGAMENTO DE FATURA",
        // "Pagamento via conta"): isso é a prova de que a fatura passada foi
        // paga. Se as parcelas daquele mês ainda estiverem em aberto, marca
        // como pagas agora, para o mês anterior parar de aparecer como devendo.
        const pagosNaFatura = f.lancamentos
          .filter((l) => l.direcao === "credito" && detectarTipoLancamento(l.descricao, -l.valor) === "pagamento")
          .reduce((s, l) => s + Math.abs(l.valor), 0);
        const anterior = comp ? somarMeses(comp, -1) : null;
        let totalAnterior: number | null = null;
        if (comp && anterior && pagosNaFatura > 0) {
          const consultaAnterior = supabase
            .from("import_faturas")
            .select("total_declarado, total_extraido")
            .eq("grupo_id", grupoId)
            .eq("competencia", anterior);
          const { data: fatAnterior } = await (cartaoPrincipal
            ? consultaAnterior.eq("cartao_id", cartaoPrincipal)
            : consultaAnterior.is("cartao_id", null)
          )
            .order("created_at", { ascending: false })
            .limit(1);
          const ant: any = fatAnterior?.[0];
          const valorAnt = ant?.total_declarado ?? ant?.total_extraido ?? null;
          totalAnterior = valorAnt == null ? null : Number(valorAnt);
        }
        // Regra: a fatura anterior só vira paga quando a nova traz o mesmo valor como pagamento.
        const pagouAnterior =
          totalAnterior != null && Math.abs(pagosNaFatura - totalAnterior) <= 0.01;
        if (pagouAnterior && comp && anterior) {
          const inicio = `${anterior}-01`;
          const fim = `${somarMeses(anterior, 1)}-01`;
          const cartoesParaQuitar = cartoesTocados.size
            ? [...cartoesTocados]
            : cartaoPrincipal
              ? [cartaoPrincipal]
              : [];
          for (const cartaoId of cartoesParaQuitar) {
            const { data: despesasDoCartao } = await supabase
              .from("despesas")
              .select("id")
              .eq("grupo_id", grupoId)
              .eq("cartao_id", cartaoId);
            const ids = (despesasDoCartao ?? []).map((d: { id: string }) => d.id);
            if (!ids.length) continue;
            const { data: emAberto } = await supabase
              .from("parcelas")
              .select("id")
              .in("despesa_id", ids)
              .eq("paga", false)
              .gte("vencimento", inicio)
              .lt("vencimento", fim);
            if (!emAberto?.length) continue;
            const { error: erroQuitar } = await supabase
              .from("parcelas")
              .update({ paga: true, data_pagamento: inicio } as never)
              .in(
                "id",
                emAberto.map((x: { id: string }) => x.id),
              );
            if (erroQuitar) throw erroQuitar;
            quitadas += emAberto.length;
          }
          if (quitadas) {
            await supabase
              .from("fatura_mes")
              .update({ status: "paga" } as never)
              .eq("grupo_id", grupoId)
              .eq("competencia", anterior)
              .in("cartao_id", cartoesParaQuitar);
          }
        }

        // Memoriza o padrão deste emissor para as próximas faturas iguais.
        if (f.assinatura && f.lancamentos.some((l) => l.incluir)) {
          const { data: perfilAtual } = await supabase
            .from("fatura_layouts")
            .select("id, acertos")
            .eq("assinatura", f.assinatura)
            .maybeSingle();
          if (perfilAtual) {
            await supabase
              .from("fatura_layouts")
              .update({
                acertos: (perfilAtual.acertos ?? 1) + 1,
                ultimo_uso: new Date().toISOString(),
                banco: f.banco,
                ...(f.colunas && Object.keys(f.colunas).length ? { colunas: f.colunas } : {}),
              })
              .eq("id", perfilAtual.id);
          } else {
            await supabase.from("fatura_layouts").insert({
              assinatura: f.assinatura,
              banco: f.banco,
              emissor: BANCO_LABEL[f.banco],
              colunas: f.colunas ?? {},
              formato_data: "auto",
              formato_valor: "pt-BR",
            });
          }
        }
      }

      // Depois da gravação: restaura o que a decisão pede (mesclar ou ambas) e
      // anota a fatura nova no backup, para o "Desfazer" saber o que apagar.
      for (const [hash, backupId] of backupPorHash) {
        const decisao = decisaoFaltantes[hash] ?? "nova";
        const { data: bk, error: bkErr } = await (supabase as any)
          .from("importacao_backups")
          .select("dados")
          .eq("id", backupId)
          .single();
        if (bkErr) throw bkErr;
        const dados = (bk?.dados ?? {}) as { despesas: any[]; parcelas: any[]; faltantes_ids: string[] };
        const faltam = new Set(dados.faltantes_ids ?? []);
        const despesasRestaurar =
          decisao === "ambas"
            ? dados.despesas
            : decisao === "mesclar"
              ? dados.despesas.filter((d) => faltam.has(d.id))
              : [];
        const parcelasRestaurar =
          decisao === "ambas"
            ? dados.parcelas
            : decisao === "mesclar"
              ? dados.parcelas.filter((p) => faltam.has(p.despesa_id))
              : [];
        if (despesasRestaurar.length) {
          const { error } = await supabase
            .from("despesas")
            .upsert(despesasRestaurar as any, { onConflict: "id" });
          if (error) throw error;
        }
        if (parcelasRestaurar.length) {
          const { error } = await supabase
            .from("parcelas")
            .upsert(parcelasRestaurar as any, { onConflict: "id" });
          if (error) throw error;
        }
        const nova = novasFaturas.get(hash);
        const { error: upErr } = await (supabase as any)
          .from("importacao_backups")
          .update({ faturas_novas: nova ? [nova] : [], lote_id: lote.id })
          .eq("id", backupId);
        if (upErr) throw upErr;
        // Compras da fatura anterior que ficaram sem parcela saem agora. As que a
        // importação reaproveitou (ainda têm parcela) ficam.
        const idsEscopo = conflitos[hash]?.escopo_despesa_ids ?? [];
        if (idsEscopo.length) {
          const { data: restantes, error: rErr } = await supabase
            .from("parcelas")
            .select("despesa_id")
            .in("despesa_id", idsEscopo);
          if (rErr) throw rErr;
          const comParcela = new Set((restantes ?? []).map((p) => p.despesa_id));
          const orfas = idsEscopo.filter((id) => !comParcela.has(id));
          if (orfas.length) {
            const { error } = await supabase.from("despesas").delete().in("id", orfas);
            if (error) throw error;
          }
        }
      }

      if (fechamentosManuais.length) {
        const { error: fechErr } = await (supabase as any)
          .from("fatura_mes")
          .update({ status: "concluida" })
          .in("id", fechamentosManuais);
        if (fechErr) throw fechErr;
      }

      let falhasDePara = 0;
      for (const regra of regrasAprendidas.values()) {
        try {
          await gravarRegra(regra);
        } catch {
          falhasDePara++;
        }
      }
      return {
        inseridos,
        ignorados,
        fechadas,
        quitadas,
        falhasDePara,
        regrasSalvas: regrasAprendidas.size - falhasDePara,
      };
    },
    onSuccess: ({ inseridos, ignorados, fechadas, quitadas, falhasDePara, regrasSalvas }) => {
      qc.invalidateQueries({ queryKey: ["despesas"] });
      qc.invalidateQueries({ queryKey: ["parcelas"] });
      qc.invalidateQueries({ queryKey: ["fatura-mes"] });
      qc.invalidateQueries({ queryKey: ["import-faturas"] });
      qc.invalidateQueries({ queryKey: ["categoria-regras"] });
      // Modo automático (sem botão "Ensinar"): só a descrição corrigida vira aprendizado do layout.
      // Data e valor não são aprendidos sozinhos, porque a regra valeria para toda linha com a
      // mesma data ou o mesmo valor nas próximas faturas desse layout.
      const paraEnsinar = faturas.flatMap((fat) =>
        fat.assinatura
          ? fat.lancamentos
              .filter((lanc) => baseCorrecao.current.has(`${fat.arquivo_hash}:${lanc.id}`))
              .map((lanc) => ({
                assinatura: fat.assinatura!,
                hash: fat.arquivo_hash,
                l: lanc,
                somenteDescricao: true,
              }))
          : [],
      );
      void Promise.all(paraEnsinar.map((p) => ensinarCorrecao.mutateAsync(p).catch(() => 0)));
      setFaturas([]);
      setAcoesFixas({});
      setDecisaoFatura({});
      setDecisaoFaltantes({});
      setConflitosPorFatura({});
      setAcoesDuplicata({});
      qc.invalidateQueries({ queryKey: ["importacao-backups"] });
      classificacoesEditadas.current.clear();
      toast.success(
        `${inseridos} lançamento(s) importado(s). ${ignorados} duplicado(s) ignorado(s).` +
          (fechadas ? ` ${fechadas} competência(s) fechada(s).` : ""),
      );
      if (quitadas)
        toast.success(
          `A fatura traz o pagamento do mês anterior: ${quitadas} parcela(s) daquele mês foram marcadas como pagas.`,
          { duration: 8000 },
        );
      toast.info(
        "O arquivo enviado foi processado e descartado — nada além dos lançamentos foi armazenado.",
      );
      if (regrasSalvas)
        toast.info(`${regrasSalvas} classificação(ões) aprendida(s) para próximas importações.`);
      if (falhasDePara)
        toast.warning(`${falhasDePara} regra(s) de de-para não puderam ser salvas.`);
    },
    onError: (e: any) => {
      if (e?.linhaId) {
        setLinhaComErro(e.linhaId);
        window.setTimeout(
          () =>
            document
              .getElementById(`linha-${e.linhaId}`)
              ?.scrollIntoView({ behavior: "smooth", block: "center" }),
          60,
        );
      }
      toast.error(e?.message ?? "Falha ao importar.", { duration: 15000 });
    },
    onSettled: () => setProgresso(null),
  });

  // Etapa D (plano-importacao-v2.md): permissão granular de importação por
  // usuário. "Ver" bloqueia a tela inteira; as outras três controlam,
  // dentro da tela, o que pode efetivamente ser enviado.
  const podeVerImportar = can("importar", "ver");
  const podeImportarLancamentos = canImportar("lancamentos");
  const podeImportarParcelamentos = canImportar("parcelamentos");
  const podeImportarLimite = canImportar("limite");

  if (!podeVerImportar) {
    return (
      <AppLayout title="Importar Lançamentos">
        <Card>
          <CardContent className="flex flex-col items-center gap-2 py-16 text-center">
            <ShieldCheck className="size-8 text-muted-foreground" />
            <p className="text-sm text-muted-foreground">
              Seu usuário não tem permissão para importar lançamentos. Fale com um administrador se
              precisar desse acesso.
            </p>
          </CardContent>
        </Card>
      </AppLayout>
    );
  }

  return (
    <AppLayout
      title="Importar Lançamentos"
      description="Envie PDFs de fatura, planilha ou cole os lançamentos, revise linha a linha e confirme."
      actions={
        faturas.length > 0 ? (
          <Button onClick={() => void prepararImportacao()} disabled={confirmar.isPending || preparando}>
            {confirmar.isPending || preparando ? (
              <Loader2 className="mr-2 size-4 animate-spin" />
            ) : (
              <CheckCircle2 className="mr-2 size-4" />
            )}
            Confirmar importação
          </Button>
        ) : undefined
      }
    >
      {(confirmar.isPending || preparando) && (
        <div
          className="sticky top-2 z-30 mb-3 rounded-lg border bg-background/95 p-3 shadow-sm backdrop-blur"
          role="status"
          aria-live="polite"
        >
          {confirmar.isPending && progresso ? (
            (() => {
              const pct = Math.min(99, Math.round((progresso.feitos / progresso.total) * 100));
              return (
                <>
                  <div className="mb-1 flex items-center justify-between gap-2 text-xs">
                    <span className="truncate">{progresso.etapa}</span>
                    <span className="font-semibold tabular-nums">{pct}%</span>
                  </div>
                  <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
                    <div
                      className="h-full rounded-full bg-primary transition-[width] duration-300"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                  <p className="mt-1 text-[11px] text-muted-foreground">
                    {progresso.feitos} de {progresso.total} lançamentos gravados
                  </p>
                </>
              );
            })()
          ) : (
            <p className="flex items-center gap-2 text-xs">
              <Loader2 className="size-3.5 animate-spin" aria-hidden="true" /> Conferindo duplicidades
              e faturas do mesmo mês antes de gravar...
            </p>
          )}
        </div>
      )}
      {(backupsRecentes.data ?? []).length > 0 && (
        <Card className="mb-4">
          <CardContent className="space-y-2 py-3 text-sm">
            <p className="font-medium">Substituições de fatura fechada</p>
            {(backupsRecentes.data ?? []).map((b) => (
              <div key={b.id} className="flex flex-wrap items-center gap-2 text-xs">
                <span className="mr-auto">
                  {rotuloCartao(b.cartao_id)} · {monthLabelLong(b.competencia)} · substituída em{" "}
                  {new Date(b.criado_em).toLocaleString("pt-BR")}
                </span>
                <Button
                  size="sm"
                  variant="outline"
                  className="h-7 text-[11px]"
                  disabled={desfazerSubstituicao.isPending}
                  onClick={() => {
                    if (
                      window.confirm(
                        "Desfazer a substituição? Os lançamentos desta importação saem e a fatura anterior volta como estava.",
                      )
                    )
                      desfazerSubstituicao.mutate(b.id);
                  }}
                >
                  Desfazer
                </Button>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      <PrimeiraFaturaAviso onImportar={() => inputRef.current?.click()} />
      <PrimeiraCategoriaGuia tipo="despesa" className="mb-3" />
      <Card>
        <CardContent className="p-4">
          <Tabs defaultValue="pdf">
            <TabsList className="mb-3">
              <TabsTrigger value="pdf">
                <FileText className="mr-2 size-4" /> Fatura em PDF
              </TabsTrigger>
              <TabsTrigger value="texto">
                <ClipboardPaste className="mr-2 size-4" /> Colar lançamentos
              </TabsTrigger>
              <TabsTrigger value="prints">
                <ImageIcon className="mr-2 size-4" /> Prints
              </TabsTrigger>
              <TabsTrigger value="planilha">
                <FileSpreadsheet className="mr-2 size-4" /> Planilha
              </TabsTrigger>
              <TabsTrigger value="fechadas">
                <ShieldCheck className="mr-2 size-4" /> Faturas fechadas
              </TabsTrigger>
            </TabsList>

            <TabsContent value="pdf">
              <div className="mb-3 flex items-stretch gap-2">
                <div
                  className="flex flex-1 cursor-pointer flex-wrap items-center gap-x-3 gap-y-1 rounded-lg border border-dashed px-4 py-2.5 text-left transition-colors hover:bg-muted/50"
                  onClick={() => inputRef.current?.click()}
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={(e) => {
                    e.preventDefault();
                    void onFiles(e.dataTransfer.files);
                  }}
                >
                  {lendo ? (
                    <Loader2 className="size-6 animate-spin text-muted-foreground" />
                  ) : (
                    <Upload className="size-6 text-muted-foreground" />
                  )}
                  <p className="text-sm font-medium">Arraste os PDFs ou clique para selecionar</p>
                  <p className="text-xs text-muted-foreground">
                    Itaú, Nubank, Pernambucanas e Santander · vários arquivos por vez
                  </p>
                  <input
                    ref={inputRef}
                    type="file"
                    accept="application/pdf"
                    multiple
                    className="hidden"
                    onChange={(e) => void onFiles(e.target.files)}
                  />
                </div>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button size="sm" variant="outline" className="h-auto shrink-0 gap-1.5 text-xs">
                      Banco não reconhecido?
                      {solicitacoesAnalise.length > 0 && (
                        <span className="text-muted-foreground">· {solicitacoesAnalise.length} enviada(s)</span>
                      )}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent align="end" className="w-80 space-y-3 p-3 text-xs">
                    <p className="text-muted-foreground">
                      Envie uma cópia para modelagem. Os dados não serão usados e o arquivo será descartado em até 30 dias.
                    </p>
                    <div className="flex flex-wrap gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        disabled={enviandoLayout}
                        onClick={() => layoutRef.current?.click()}
                      >
                        {enviandoLayout ? "Enviando…" : "Enviar para análise"}
                      </Button>
                      {solicitacoesAnalise.length > 0 && (
                        <Button size="sm" variant="ghost" className="text-xs" onClick={() => setModalAnaliseOpen(true)}>
                          <FileText className="mr-1 size-3.5" /> Faturas enviadas ({solicitacoesAnalise.length})
                        </Button>
                      )}
                    </div>
                  </PopoverContent>
                </Popover>
                <input
                  ref={layoutRef}
                  className="hidden"
                  type="file"
                  accept="application/pdf,image/jpeg,image/png"
                  onChange={(e) => void enviarParaModelagem(e.target.files)}
                />
              </div>

              {pdfsComSenha.length > 0 && (
                <div className="mt-3 space-y-2">
                  {pdfsComSenha.map((p) => (
                    <div
                      key={p.file.name + p.file.size}
                      className="flex flex-col gap-2 rounded-lg border border-amber-300 bg-amber-50 p-3 dark:border-amber-900 dark:bg-amber-950/40 sm:flex-row sm:items-center"
                    >
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-medium">{p.file.name}</p>
                        <p className="text-xs text-muted-foreground">
                          PDF protegido por senha — informe a senha para ler.
                        </p>
                        {p.erro && <p className="text-xs text-destructive">{p.erro}</p>}
                      </div>
                      <div className="flex gap-2">
                        <Input
                          type="password"
                          placeholder="Senha do PDF"
                          value={p.senha}
                          className="h-9 w-40"
                          onChange={(e) =>
                            setPdfsComSenha((prev) =>
                              prev.map((x) =>
                                x.file === p.file ? { ...x, senha: e.target.value } : x,
                              ),
                            )
                          }
                          onKeyDown={(e) => {
                            if (e.key === "Enter") void tentarComSenha(p.file);
                          }}
                        />
                        <Button
                          size="sm"
                          disabled={!p.senha || p.tentando}
                          onClick={() => void tentarComSenha(p.file)}
                        >
                          {p.tentando ? <Loader2 className="size-4 animate-spin" /> : "Desbloquear"}
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() =>
                            setPdfsComSenha((prev) => prev.filter((x) => x.file !== p.file))
                          }
                        >
                          <Trash2 className="size-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="texto" className="space-y-3">
              <Textarea
                rows={8}
                placeholder={
                  "Cole aqui uma linha por lançamento, contendo data, descrição e valor.\n\n12/08 iFood 54,90\n15/08 Uber 23,40\nNetflix 55,90 dia 20"
                }
                value={colado}
                onChange={(e) => setColado(e.target.value)}
              />
              <div className="flex items-center justify-between gap-2">
                <p className="text-xs text-muted-foreground">
                  As categorias são sugeridas pelo de-para e pelas palavras-chave; tudo continua
                  editável na prévia.
                </p>
                <Button onClick={() => void importarColado()} disabled={!colado.trim()}>
                  <ClipboardPaste className="mr-2 size-4" /> Interpretar
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="prints" className="space-y-3">
              <div
                className="flex cursor-pointer flex-wrap items-center gap-x-3 gap-y-1 rounded-lg border border-dashed px-4 py-2.5 text-left transition-colors hover:bg-muted/50"
                onClick={() => imgInputRef.current?.click()}
                onDragOver={(e) => e.preventDefault()}
                onDrop={(e) => {
                  e.preventDefault();
                  void onImages(e.dataTransfer.files);
                }}
              >
                {lendoImagens ? (
                  <Loader2 className="size-6 animate-spin text-muted-foreground" />
                ) : (
                  <ImageIcon className="size-6 text-muted-foreground" />
                )}
                <p className="text-sm font-medium">Arraste prints ou clique para selecionar</p>
                <p className="text-xs text-muted-foreground">
                  PNG, JPG ou WEBP · até 10 por vez · OCR no navegador (sem custo de IA)
                </p>
                <input
                  ref={imgInputRef}
                  type="file"
                  accept="image/png,image/jpeg,image/webp"
                  multiple
                  className="hidden"
                  onChange={(e) => void onImages(e.target.files)}
                />
              </div>
              <p className="text-xs text-muted-foreground">
                O texto é lido por OCR no próprio navegador e passa pelo mesmo parser das faturas em
                PDF. Linhas sem data/descrição/valor ficam em branco para preencher manualmente na
                prévia.
              </p>
            </TabsContent>

            <TabsContent value="planilha" className="space-y-3">
              <div
                className="flex cursor-pointer flex-wrap items-center gap-x-3 gap-y-1 rounded-lg border border-dashed px-4 py-2.5 text-left transition-colors hover:bg-muted/50"
                onClick={() => planilhaInputRef.current?.click()}
                onDragOver={(e) => e.preventDefault()}
                onDrop={(e) => {
                  e.preventDefault();
                  void importarPlanilha(e.dataTransfer.files);
                }}
              >
                {lendoPlanilha ? (
                  <Loader2 className="size-6 animate-spin text-muted-foreground" />
                ) : (
                  <FileSpreadsheet className="size-6 text-muted-foreground" />
                )}
                <p className="text-sm font-medium">Arraste a planilha ou clique para selecionar</p>
                <p className="text-xs text-muted-foreground">
                  .xlsx ou .csv de qualquer banco · até 5 MB · colunas detectadas automaticamente
                  (Data, Descrição, Valor e Parcela, quando existir)
                </p>
                <input
                  ref={planilhaInputRef}
                  type="file"
                  accept=".xlsx,.csv"
                  multiple
                  className="hidden"
                  onChange={(e) => void importarPlanilha(e.target.files)}
                />
              </div>
              <div className="flex items-center justify-between gap-2 text-xs text-muted-foreground">
                <span>
                  Não precisa ser de um banco específico — funciona com qualquer planilha que tenha
                  colunas de data, descrição e valor.
                </span>
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-7 shrink-0 text-xs"
                  onClick={() => {
                    const blob = new Blob([modeloCsvPlanilha()], {
                      type: "text/csv;charset=utf-8",
                    });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement("a");
                    a.href = url;
                    a.download = "modelo-importacao.csv";
                    a.click();
                    URL.revokeObjectURL(url);
                  }}
                >
                  Baixar modelo .csv
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="fechadas">
              <div className="space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <p className="text-sm font-semibold">Faturas registradas por competência</p>
                    <p className="text-xs text-muted-foreground">
                      Consulte as faturas já salvas no banco. Você pode excluir uma competência específica (com backup e desfazer) ou substituir por uma nova versão. O passado nunca é apagado.
                    </p>
                  </div>
                </div>

                {faturasFechadasLista.isLoading ? (
                  <p className="py-6 text-center text-xs text-muted-foreground">Carregando faturas…</p>
                ) : (faturasFechadasLista.data ?? []).length === 0 ? (
                  <div className="rounded-xl border border-dashed py-8 text-center text-xs text-muted-foreground">
                    Nenhuma fatura fechada registrada ainda.
                  </div>
                ) : (
                  <div className="space-y-2">
                    {(faturasFechadasLista.data ?? []).map((fat: any) => (
                      <div
                        key={fat.id}
                        className="flex flex-wrap items-center justify-between gap-3 rounded-lg border bg-muted/20 p-3 text-xs"
                      >
                        <div className="min-w-0 flex-1 space-y-0.5">
                          <div className="flex items-center gap-2">
                            <span className="font-semibold text-foreground">
                              {fat.cartao_id ? rotuloCartao(fat.cartao_id) : BANCO_LABEL[fat.banco as BancoFatura] ?? fat.banco}
                            </span>
                            <Badge variant="secondary" className="text-[10px]">
                              {fat.competencia ? monthLabelLong(fat.competencia) : "Sem competência"}
                            </Badge>
                            {fat.status === "fechada" && (
                              <Badge variant="default" className="bg-emerald-600 text-[10px]">
                                Fechada
                              </Badge>
                            )}
                          </div>
                          <p className="truncate text-muted-foreground">
                            {fat.arquivo_nome} · Total declarado: {fat.total_declarado !== null ? formatBRL(fat.total_declarado) : "—"} · Extraído: {fat.total_extraido !== null ? formatBRL(fat.total_extraido) : "—"}
                          </p>
                          <p className="text-[10px] text-muted-foreground">
                            Registrada em {new Date(fat.created_at).toLocaleString("pt-BR")}
                          </p>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            className="h-8 text-xs gap-1"
                            onClick={() => {
                              inputRef.current?.click();
                              toast.info(`Selecione o novo PDF para substituir a fatura de ${fat.competencia ? monthLabelLong(fat.competencia) : ""}.`);
                            }}
                          >
                            <Upload className="size-3.5" />
                            Substituir
                          </Button>
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            className="h-8 text-xs text-destructive hover:bg-destructive/10 hover:text-destructive gap-1"
                            disabled={excluirFaturaFechada.isPending}
                            onClick={() => {
                              if (
                                window.confirm(
                                  `Excluir a fatura de ${fat.competencia ? monthLabelLong(fat.competencia) : fat.arquivo_nome}? Os lançamentos desta competência serão removidos (com opção de desfazer mantida). O passado nunca é apagado.`
                                )
                              ) {
                                excluirFaturaFechada.mutate(fat);
                              }
                            }}
                          >
                            <Trash2 className="size-3.5" />
                            Excluir
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>

          {faturas.length > 0 && (
            <div className="mt-3 flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
              <span>{totais.arquivos} lote(s)</span>
              <span>{totais.linhas} lançamento(s) selecionado(s)</span>
              <span className="font-medium text-foreground">{formatBRL(totais.valor)}</span>
            </div>
          )}
        </CardContent>
      </Card>

      {faturas.map((f, idx) => (
        <Card key={f.arquivo_hash} className="mt-4">
          <CardHeader className="gap-3 pb-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <CardTitle className="flex items-center gap-2 text-base">
                <FileText className="size-4" />
                <span className="truncate">{f.arquivo_nome}</span>
              </CardTitle>
              <div className="flex items-center gap-2">
                {f.duplicada && (
                  <Badge variant="destructive" className="gap-1">
                    <AlertTriangle className="size-3" /> Arquivo já importado
                  </Badge>
                )}
                {competenciaAnterior(f) && (
                  <Badge variant="outline" className="gap-1 border-sky-500 text-sky-700 dark:text-sky-300">
                    <AlertTriangle className="size-3" /> Competência {rotuloCompetencia(competenciaAnterior(f)!)},
                    anterior ao mês atual. Pode importar normalmente.
                  </Badge>
                )}
                {f.conflitoMes && (
                  <Badge variant="outline" className="gap-1 border-amber-500 text-amber-700 dark:text-amber-300">
                    <AlertTriangle className="size-3" /> Já existe fatura deste cartão neste mês (
                    {f.conflitoMes.arquivo_nome}, importada em{" "}
                    {new Date(f.conflitoMes.created_at).toLocaleDateString("pt-BR")})
                  </Badge>
                )}
                <Button
                  variant="outline"
                  size="sm"
                  className="h-8 gap-1 text-xs"
                  title="Troca o sinal de todos os lançamentos desta fatura (débito vira crédito e vice-versa)"
                  onClick={() =>
                    setFaturas((prev) =>
                      prev.map((x, i) =>
                        i === idx
                          ? {
                              ...x,
                              lancamentos: x.lancamentos.map((l) => ({
                                ...l,
                                direcao: l.direcao === "credito" ? "debito" : "credito",
                              })),
                            }
                          : x,
                      ),
                    )
                  }
                >
                  <ArrowLeftRight className="size-3.5" aria-hidden="true" /> Inverter sinal da fatura
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setFaturas((prev) => prev.filter((_, i) => i !== idx))}
                >
                  <Trash2 className="size-4" />
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-4">
              <div className="space-y-1 sm:col-span-2">
                <div className="flex items-center gap-2">
                  <Label className="text-xs">Cartão / conta de destino</Label>
                  {!f.destino && (
                    <Badge
                      variant="outline"
                      className="border-amber-500/40 text-[10px] text-amber-600 dark:text-amber-400"
                    >
                      Não cadastrado
                    </Badge>
                  )}
                </div>
                <Select
                  value={f.destino || "nenhum"}
                  onValueChange={(v) => atualizarFatura(idx, { destino: v === "nenhum" ? "" : v })}
                >
                  <SelectTrigger className="h-9">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="nenhum">Não vincular</SelectItem>
                    {(cartoes as any[]).map((c) => (
                      <SelectItem key={c.id} value={`cartao:${c.id}`}>
                        {c.apelido ?? c.bandeira ?? "Cartão"} •{c.final} ·{" "}
                        {c.titular?.trim().split(/\s+/)[0] || "Titular não informado"} ·{" "}
                        {c.bancos?.nome ?? c.bandeira}
                      </SelectItem>
                    ))}
                    {(bancos as any[]).map((b) => (
                      <SelectItem key={b.id} value={`banco:${b.id}`}>
                        {b.nome} (conta)
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <div className="mt-1 flex flex-wrap gap-2">
                  <Button
                    type="button"
                    size="sm"
                    variant="ghost"
                    className="h-7 px-1 text-xs"
                    onClick={() => {
                      setNomeBancoNovo(f.banco === "desconhecido" ? "" : BANCO_LABEL[f.banco]);
                      setCadastroDestino({ arquivoHash: f.arquivo_hash, tipo: "banco" });
                    }}
                  >
                    <Plus className="mr-1 size-3" /> Cadastrar banco
                  </Button>
                  <Button
                    type="button"
                    size="sm"
                    variant="ghost"
                    className="h-7 px-1 text-xs"
                    onClick={() => {
                      setCartaoNovo({
                        apelido: "",
                        final: f.finais[0] ?? "",
                        titular: profiles[0]?.nome ?? "",
                        bancoId: "",
                      });
                      setCadastroDestino({ arquivoHash: f.arquivo_hash, tipo: "cartao" });
                    }}
                  >
                    <Plus className="mr-1 size-3" /> Cadastrar cartão
                  </Button>
                </div>
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Banco</Label>
                <Select
                  value={f.banco}
                  onValueChange={(v) =>
                    atualizarFatura(idx, {
                      banco: v as BancoFatura,
                      destino: destinoPadrao({ ...f, banco: v as BancoFatura }),
                    })
                  }
                >
                  <SelectTrigger className="h-9">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {BANCOS.map((b) => (
                      <SelectItem key={b} value={b}>
                        {BANCO_LABEL[b]}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Vencimento da fatura</Label>
                <Input
                  type="date"
                  className="h-9"
                  value={f.vencimento ?? ""}
                  onChange={(e) =>
                    atualizarFatura(idx, {
                      vencimento: e.target.value || null,
                      competencia: e.target.value ? e.target.value.slice(0, 7) : null,
                    })
                  }
                />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Total da fatura</Label>
                <Input
                  className="h-9"
                  type="text"
                  inputMode="decimal"
                  placeholder="0,00"
                  value={
                    f.total_declarado_edicao ??
                    (f.total_declarado == null ? "" : String(f.total_declarado).replace(".", ","))
                  }
                  onChange={(e) => {
                    const digitado = e.target.value;
                    if (!/^\d*(?:[.,]\d{0,2})?$/.test(digitado)) return;

                    const normalizado = digitado.replace(",", ".");
                    const valor =
                      normalizado && !/[.,]$/.test(digitado) ? Number(normalizado) : null;
                    atualizarFatura(idx, {
                      total_declarado_edicao: digitado,
                      ...(valor != null && Number.isFinite(valor)
                        ? { total_declarado: valor }
                        : digitado === ""
                          ? { total_declarado: null }
                          : {}),
                    });
                  }}
                  onBlur={() =>
                    atualizarFatura(idx, {
                      total_declarado_edicao:
                        f.total_declarado == null
                          ? ""
                          : f.total_declarado.toFixed(2).replace(".", ","),
                    })
                  }
                />
                <p className="text-[11px] text-muted-foreground">
                  Pré-preenchido com a soma dos lançamentos (exceto pagamento de fatura). Troque
                  pelo valor real da sua fatura para conferir se falta algum lançamento.
                </p>
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Finais detectados</Label>
                <div className="flex items-center gap-1">
                  <Input
                    className="h-9 text-sm"
                    placeholder="0000, 0000"
                    value={f.finais.join(", ")}
                    onChange={(e) =>
                      atualizarFatura(idx, {
                        finais: e.target.value
                          .split(/[,\s]+/)
                          .map((v) => v.replace(/\D/g, "").slice(0, 4))
                          .filter(Boolean),
                      })
                    }
                  />
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    className="h-9 shrink-0 whitespace-nowrap px-2 text-xs"
                    disabled={!f.finais.length}
                    title="Usa o primeiro final da lista em todos os lançamentos abaixo"
                    onClick={() => {
                      const final = f.finais[0] ?? null;
                      setFaturas((prev) =>
                        prev.map((x, i) =>
                          i === idx
                            ? {
                                ...x,
                                lancamentos: x.lancamentos.map((l) => ({
                                  ...l,
                                  cartao_final: final,
                                })),
                              }
                            : x,
                        ),
                      );
                    }}
                  >
                    Aplicar a todos
                  </Button>
                </div>
              </div>
              <div className="space-y-1 sm:col-span-2">
                <Label className="text-xs">Responsável de todas as linhas</Label>
                <Select
                  value={responsavelDeTodos[f.arquivo_hash] ?? "manter"}
                  onValueChange={(v) => {
                    // Mostra no botão quem foi escolhido (antes voltava sempre
                    // para "Aplicar a todos…" e parecia que não tinha aplicado).
                    setResponsavelDeTodos((atual) => ({ ...atual, [f.arquivo_hash]: v }));
                    setFaturas((prev) =>
                      prev.map((x, i) =>
                        i === idx
                          ? {
                              ...x,
                              lancamentos: x.lancamentos.map((l) => ({
                                ...l,
                                responsavel: v === "manter" ? l.responsavel : v === "nenhum" ? null : v,
                              })),
                            }
                          : x,
                      ),
                    );
                  }}
                >
                  <SelectTrigger className="h-9">
                    <SelectValue placeholder="Aplicar a todos" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="manter">Aplicar a todos…</SelectItem>
                    <SelectItem value="nenhum">Sem responsável</SelectItem>
                    {opcoesResponsavel.map((r) => (
                      <SelectItem key={r} value={r}>
                        {r}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {(() => {
              const comDuplicata = f.lancamentos.filter((l) => candidatasDe(f, l).length);
              if (!comDuplicata.length) return null;
              const pendentes = comDuplicata.filter(
                (l) => acaoDuplicataDe(f, l) === "decidir",
              ).length;
              return (
                <div className="flex flex-wrap items-center gap-2 rounded-lg border border-amber-500/40 bg-amber-500/10 px-3 py-2 text-xs">
                  <span className="mr-auto">
                    <b>{comDuplicata.length} lançamento(s)</b> desta fatura já têm algo parecido
                    cadastrado
                    {pendentes ? `, ${pendentes} sem decisão` : " e já estão resolvidos"}. Clique no
                    aviso de cada linha para ver a origem e escolher.
                  </span>
                  <Button
                    type="button"
                    size="sm"
                    variant="outline"
                    className="h-7 shrink-0 text-[11px]"
                    onClick={() => substituirTodasDuplicatas(f)}
                  >
                    <ClipboardPaste className="mr-1 size-3.5" aria-hidden="true" /> Substituir todos
                    pela importação
                  </Button>
                </div>
              );
            })()}

            {(f.portadores?.length || f.futuros_ignorados || f.total_impresso != null) && (
              <div className="flex flex-wrap items-center gap-1.5 rounded-lg border bg-muted/30 px-3 py-2 text-xs">
                {f.portadores?.map((p) => (
                  <Badge key={`${p.nome}-${p.final ?? ""}`} variant="outline" className="gap-1 font-normal">
                    {p.nome}
                    <span className="text-muted-foreground">
                      {p.final ? `· final ${p.final}` : "· final não impresso"}
                    </span>
                  </Badge>
                ))}
                {f.total_impresso != null && (
                  <span className="text-muted-foreground">
                    Total impresso na fatura: <b className="text-foreground">{formatBRL(f.total_impresso)}</b>
                  </span>
                )}
                {!!f.futuros_ignorados && (
                  <span className="text-muted-foreground">
                    · {f.futuros_ignorados} parcela(s) de próximas faturas deixada(s) de fora (não são
                    deste mês)
                  </span>
                )}
              </div>
            )}

            {(() => {
              // Recalculada a cada render (não é mais o snapshot da extração):
              // reflete lançamentos desmarcados/editados e qualquer valor que
              // o usuário tenha digitado em "Total da fatura" — é assim que o
              // usuário percebe, na hora, se ficou faltando algo.
              const incluidos = f.lancamentos.filter((l) => l.incluir);
              const conf = conferirTotal(incluidos, f.total_declarado);
              return (
                <div
                  className={`rounded-lg border px-3 py-2 text-sm ${
                    conf.ok
                      ? "border-emerald-500/40 bg-emerald-500/10"
                      : "border-amber-500/40 bg-amber-500/10"
                  }`}
                >
                  {conf.ok ? (
                    <span>
                      Leitura conferida: {incluidos.length} lançamento(s), soma{" "}
                      {formatBRL(conf.soma)}
                      {f.leitura === "perfil" ? " (padrão deste banco já memorizado)" : ""}.
                    </span>
                  ) : (
                    <span>
                      A soma dos lançamentos ({formatBRL(conf.soma)}){" "}
                      {conf.diferenca != null
                        ? `está ${formatBRL(Math.abs(conf.diferenca))} ${
                            conf.diferenca > 0 ? "abaixo" : "acima"
                          } do total da fatura`
                        : "não pôde ser comparada com o total da fatura"}
                      . Confira as linhas abaixo antes de salvar.
                    </span>
                  )}
                </div>
              );
            })()}

            {!podeImportarLimite && (
              <p className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
                <ShieldCheck className="size-3.5 shrink-0" />
                Seu usuário não tem permissão para importar o limite do cartão — esses campos não
                serão salvos.
              </p>
            )}
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
              <div className="space-y-1">
                <Label className="text-xs">Limite total</Label>
                <Input
                  className="h-8 text-xs font-medium tabular-nums"
                  type="text"
                  inputMode="decimal"
                  placeholder="Não identificado"
                  disabled={!podeImportarLimite}
                  value={
                    podeImportarLimite && f.limite_total != null
                      ? String(f.limite_total).replace(".", ",")
                      : ""
                  }
                  onChange={(e) => {
                    const digitado = e.target.value.replace(/\./g, "").replace(",", ".");
                    const num = parseFloat(digitado);
                    atualizarFatura(idx, { limite_total: isNaN(num) ? null : num });
                  }}
                />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Limite utilizado</Label>
                <Input
                  className="h-8 text-xs font-medium tabular-nums"
                  type="text"
                  inputMode="decimal"
                  placeholder="Não identificado"
                  disabled={!podeImportarLimite}
                  value={
                    podeImportarLimite && f.limite_utilizado != null
                      ? String(f.limite_utilizado).replace(".", ",")
                      : ""
                  }
                  onChange={(e) => {
                    const digitado = e.target.value.replace(/\./g, "").replace(",", ".");
                    const num = parseFloat(digitado);
                    atualizarFatura(idx, { limite_utilizado: isNaN(num) ? null : num });
                  }}
                />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Limite disponível</Label>
                <Input
                  className="h-8 text-xs font-medium tabular-nums"
                  type="text"
                  inputMode="decimal"
                  placeholder="Não identificado"
                  disabled={!podeImportarLimite}
                  value={
                    podeImportarLimite && f.limite_disponivel != null
                      ? String(f.limite_disponivel).replace(".", ",")
                      : ""
                  }
                  onChange={(e) => {
                    const digitado = e.target.value.replace(/\./g, "").replace(",", ".");
                    const num = parseFloat(digitado);
                    atualizarFatura(idx, { limite_disponivel: isNaN(num) ? null : num });
                  }}
                />
              </div>
            </div>
          </CardHeader>

          <CardContent className="p-0">
            {f.lancamentos.length === 0 ? (
              <p className="px-6 pb-6 text-sm text-muted-foreground">
                Não consegui identificar lançamentos neste layout. O leitor específico deste banco
                será calibrado com o PDF de referência.
              </p>
            ) : (
              <div>
                <div className="flex items-center justify-between border-b bg-muted/30 px-3 py-1.5 text-xs text-muted-foreground">
                  <span>
                    <span className="font-medium text-foreground">
                      {f.lancamentos.filter((l) => l.incluir).length}
                    </span>{" "}
                    de {f.lancamentos.length} lançamento(s) selecionado(s) nesta fatura
                  </span>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full min-w-[920px] table-fixed text-xs">
                    <thead className="bg-muted/50 text-[10px] uppercase tracking-wide text-muted-foreground">
                      <tr>
                        <th className="w-6 p-0.5"></th>
                        <th className="w-[96px] p-0.5 text-left">Data</th>
                        <th className="w-[22%] p-1 text-left">Descrição</th>
                        <th className="w-[72px] p-0.5 text-left">Parcela</th>
                        <th className="w-[9%] p-1 text-left">Tipo</th>
                        <th className="w-[7%] p-1 text-left">Final</th>
                        <th className="w-[9%] p-1 text-left">Responsável</th>
                        <th className="w-[16%] p-1 text-left">Categoria</th>
                        <th className="w-[11%] p-1 text-left">Subcategoria</th>
                        <th className="w-[12%] p-1 text-right">Valor</th>
                      </tr>
                    </thead>
                    <tbody>
                      {f.lancamentos.map((l) => {
                        // Etapa D: lançamento com parcela_total > 1 é um
                        // parcelamento; parcela_total === 1 é lançamento
                        // simples (ver gravação mais abaixo, mesmo critério).
                        const ehParcelamento = l.parcela_total > 1;
                        const permitidoPorTipo = ehParcelamento
                          ? podeImportarParcelamentos
                          : podeImportarLancamentos;
                        return (
                          <tr
                            key={l.id}
                            id={`linha-${l.id}`}
                            className={cn(
                              "border-t align-top",
                              l.categoria === CATEGORIA_A_CONFIRMAR && "bg-violet-500/10",
                              linhaComErro === l.id &&
                                "bg-destructive/10 outline outline-2 -outline-offset-2 outline-destructive",
                            )}
                          >
                            <td className="p-0.5">
                              <Checkbox
                                checked={l.incluir && permitidoPorTipo}
                                disabled={!permitidoPorTipo}
                                title={
                                  !permitidoPorTipo
                                    ? ehParcelamento
                                      ? "Seu usuário não tem permissão para importar parcelamentos"
                                      : "Seu usuário não tem permissão para importar lançamentos simples"
                                    : undefined
                                }
                                onCheckedChange={(v) =>
                                  atualizarLancamento(idx, l.id, {
                                    incluir: !!v && permitidoPorTipo,
                                  })
                                }
                              />
                            </td>
                            <td className="p-0.5">
                              <Input
                                type="date"
                                className="h-6 w-full min-w-0 px-1 text-[11px]"
                                value={l.data_compra}
                                onChange={(e) =>
                                  atualizarLancamento(idx, l.id, { data_compra: e.target.value })
                                }
                              />
                            </td>
                            <td className="p-0.5">
                              <Textarea
                                className="min-h-7 w-full min-w-0 resize-none overflow-hidden rounded-md px-1.5 py-1 text-[11px] leading-tight"
                                rows={1}
                                value={l.descricao}
                                onChange={(e) => {
                                  atualizarLancamento(idx, l.id, { descricao: e.target.value });
                                  e.target.style.height = "auto";
                                  e.target.style.height = `${e.target.scrollHeight}px`;
                                }}
                                ref={(el) => {
                                  if (!el) return;
                                  el.style.height = "auto";
                                  el.style.height = `${el.scrollHeight}px`;
                                }}
                              />
                              {(() => {
                                const candidatas = candidatasDe(f, l);
                                if (!candidatas.length) return null;
                                const acao = acaoDuplicataDe(f, l);
                                const rotulos: Record<AcaoDuplicata, string> = {
                                  decidir: `${candidatas.length} parecido(s): resolver`,
                                  substituir: "Vai substituir o existente",
                                  manter_existente: "Mantém o que já existe",
                                  novo: "Vai criar um novo",
                                };
                                return (
                                  <button
                                    type="button"
                                    onClick={() =>
                                      setDuplicataAberta({ faturaIdx: idx, lancamentoId: l.id })
                                    }
                                    className={cn(
                                      "mt-1 inline-flex max-w-full items-center gap-1 rounded-md border px-2 py-1 text-left text-[10px] font-semibold",
                                      acao === "decidir"
                                        ? "border-amber-500/50 bg-amber-500/15 text-amber-800 hover:bg-amber-500/25 dark:text-amber-300"
                                        : "border-primary/40 bg-primary/10 text-primary hover:bg-primary/20",
                                    )}
                                  >
                                    <AlertTriangle className="size-3 shrink-0" aria-hidden="true" />
                                    <span className="truncate">{rotulos[acao]}</span>
                                  </button>
                                );
                              })()}
                            </td>
                            <td className="p-0.5">
                              <div className="flex items-center gap-0.5">
                                <Input
                                  type="number"
                                  min={1}
                                  className="h-6 w-9 min-w-0 px-0.5 text-center text-[11px] [appearance:textfield] [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:appearance-none"
                                  value={l.parcela_numero}
                                  onChange={(e) =>
                                    atualizarLancamento(idx, l.id, {
                                      parcela_numero: Math.max(1, Number(e.target.value) || 1),
                                    })
                                  }
                                />
                                <span className="text-[10px] text-muted-foreground">/</span>
                                <Input
                                  type="number"
                                  min={1}
                                  className="h-6 w-9 min-w-0 px-0.5 text-center text-[11px] [appearance:textfield] [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:appearance-none"
                                  value={l.parcela_total}
                                  onChange={(e) =>
                                    atualizarLancamento(idx, l.id, {
                                      parcela_total: Math.max(1, Number(e.target.value) || 1),
                                    })
                                  }
                                />
                              </div>
                            </td>
                            <td className="p-0.5">
                              <Select
                                value={l.tipo ?? "variavel"}
                                onValueChange={(v) =>
                                  atualizarLancamento(idx, l.id, { tipo: v as "fixa" | "variavel" })
                                }
                              >
                                <SelectTrigger className="h-6 w-full min-w-0 px-1 text-[11px]">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="variavel">Variável</SelectItem>
                                  <SelectItem value="fixa">Fixa</SelectItem>
                                </SelectContent>
                              </Select>
                              {(() => {
                                const cartaoLinha = acharCartao(f.banco, l.cartao_final);
                                const [tipoDestino, idDestino] = String(f.destino ?? "").split(":");
                                const correspondencia = encontrarCorrespondenciaFixa(
                                  despesasFixas,
                                  {
                                    descricao: l.descricao,
                                    valor: l.valor,
                                    direcao: l.direcao,
                                    data_compra: l.data_compra,
                                    parcela_total: l.parcela_total,
                                    cartao_final: l.cartao_final,
                                    cartao_id:
                                      cartaoLinha?.id ??
                                      (tipoDestino === "cartao" ? (idDestino ?? null) : null),
                                    banco_id: tipoDestino === "banco" ? (idDestino ?? null) : null,
                                    competencia: f.competencia,
                                  },
                                );
                                const chaveAcao = `${f.arquivo_hash}:${l.id}`;
                                return correspondencia ? (
                                  <AvisoCorrespondenciaFixa
                                    titulo={correspondencia.titulo}
                                    fixaDescricao={correspondencia.fixa.descricao}
                                    fixaValor={Number(correspondencia.fixa.valor_total)}
                                    motivos={correspondencia.motivos}
                                    valorImportado={l.valor}
                                    competenciaRotulo={monthLabelLong(
                                      (f.competencia ?? l.data_compra).slice(0, 7),
                                    )}
                                    acao={acoesFixas[chaveAcao]?.acao ?? "manter"}
                                    onAcao={(acao) => {
                                      setAcoesFixas((atual) => ({
                                        ...atual,
                                        [chaveAcao]: { acao, fixaId: correspondencia.fixa.id },
                                      }));
                                      atualizarLancamento(idx, l.id, {
                                        incluir: acao !== "ignorar",
                                      });
                                      // Guarda a escolha para repetir na próxima fatura.
                                      salvarPreferenciaImportacao.mutate({
                                        descricao: l.descricao,
                                        escopo: "fixa",
                                        acao,
                                        despesaId: correspondencia.fixa.id,
                                      });
                                    }}
                                  />
                                ) : null;
                              })()}
                            </td>
                            <td className="p-0.5">
                              <Input
                                className="h-6 w-full min-w-0 px-1 text-[11px]"
                                placeholder="0000"
                                maxLength={4}
                                value={l.cartao_final ?? ""}
                                onChange={(e) =>
                                  atualizarLancamento(idx, l.id, {
                                    cartao_final:
                                      e.target.value.replace(/\D/g, "").slice(0, 4) || null,
                                  })
                                }
                              />
                            </td>
                            <td className="p-0.5">
                              <Select
                                value={l.responsavel ?? "none"}
                                onValueChange={(v) =>
                                  atualizarLancamento(idx, l.id, {
                                    responsavel: v === "none" ? null : v,
                                  })
                                }
                              >
                                <SelectTrigger className="h-6 w-full min-w-0 px-1 text-[11px]">
                                  <SelectValue placeholder="—" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="none">—</SelectItem>
                                  {opcoesResponsavel.map((r) => (
                                    <SelectItem key={r} value={r}>
                                      {r}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </td>
                            <td className="p-0.5">
                              <div className="flex items-center gap-1">
                                <SeletorCategoria
                                  campo="categoria"
                                  className="h-7 min-w-0 px-1 text-[11px]"
                                  ariaLabel="Categoria do lançamento"
                                  placeholder="Categoria"
                                  valor={l.categoria}
                                  estrutura={estrutura}
                                  onEscolher={(cat, sub) =>
                                    atualizarLancamento(idx, l.id, { categoria: cat, subcategoria: sub })
                                  }
                                  onCriarMacro={(texto) =>
                                    setNovaCategoria({
                                      nome: texto,
                                      faturaIdx: idx,
                                      lancamentoId: l.id,
                                    })
                                  }
                                />
                              </div>
                              {l.confianca_categoria && (
                                <p className="mt-1 text-[10px] text-muted-foreground">
                                  Confiança: {CONFIANCA_LABEL[l.confianca_categoria]}
                                </p>
                              )}
                            </td>
                            <td className="p-0.5">
                              <SeletorCategoria
                                campo="subcategoria"
                                className="h-6 w-full min-w-0 px-1 text-[11px]"
                                ariaLabel="Subcategoria do lançamento"
                                placeholder="—"
                                valor={l.subcategoria ?? null}
                                categoriaAtual={l.categoria}
                                estrutura={estrutura}
                                onEscolher={(_cat, sub) => atualizarLancamento(idx, l.id, { subcategoria: sub })}
                                onCriarSub={(macro, nome) =>
                                  criarSubcategoria.mutate(
                                    { categoria: macro, nome },
                                    {
                                      onSuccess: () =>
                                        atualizarLancamento(idx, l.id, { subcategoria: nome.trim() }),
                                    },
                                  )
                                }
                              />
                            </td>
                            <td className="p-0.5 text-right">
                              <Input
                                type="number"
                                step="0.01"
                                className={`h-7 w-full min-w-0 px-1 text-right text-[11px] font-medium ${
                                  l.direcao === "credito" ? "text-success" : "text-destructive"
                                }`}
                                value={l.valor}
                                onChange={(e) =>
                                  atualizarLancamento(idx, l.id, {
                                    valor: Number(e.target.value) || 0,
                                  })
                                }
                              />
                              <p
                                className={`mt-1 text-[10px] font-medium ${
                                  l.direcao === "credito" ? "text-success" : "text-destructive"
                                }`}
                              >
                                {l.direcao === "credito" ? "crédito" : "débito"} ·{" "}
                                {formatBRL(l.valor * l.parcela_total)}
                              </p>
                              <button
                                type="button"
                                title="Inverter o sinal: débito vira crédito e vice-versa"
                                aria-label="Inverter o sinal deste lançamento"
                                className="mt-0.5 inline-flex items-center gap-1 text-[10px] text-muted-foreground hover:text-foreground"
                                onClick={() =>
                                  atualizarLancamento(idx, l.id, {
                                    direcao: l.direcao === "credito" ? "debito" : "credito",
                                  })
                                }
                              >
                                <ArrowLeftRight className="size-3" aria-hidden="true" /> inverter sinal
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      ))}
      <Dialog
        open={!!cadastroDestino}
        onOpenChange={(aberto) => !aberto && setCadastroDestino(null)}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {cadastroDestino?.tipo === "banco" ? "Cadastrar banco ou conta" : "Cadastrar cartão"}
            </DialogTitle>
          </DialogHeader>
          {cadastroDestino?.tipo === "banco" ? (
            <div className="space-y-2">
              <Label htmlFor="novo-banco-importacao">Nome do banco ou conta</Label>
              <Input
                id="novo-banco-importacao"
                value={nomeBancoNovo}
                onChange={(evento) => setNomeBancoNovo(evento.target.value)}
              />
            </div>
          ) : (
            <div className="space-y-3">
              <div className="space-y-1">
                <Label htmlFor="novo-cartao-apelido">Apelido do cartão (opcional)</Label>
                <Input
                  id="novo-cartao-apelido"
                  value={cartaoNovo.apelido}
                  onChange={(evento) =>
                    setCartaoNovo({ ...cartaoNovo, apelido: evento.target.value })
                  }
                />
              </div>
              <div className="space-y-1">
                <Label htmlFor="novo-cartao-final">Quatro últimos dígitos</Label>
                <Input
                  id="novo-cartao-final"
                  inputMode="numeric"
                  maxLength={4}
                  value={cartaoNovo.final}
                  onChange={(evento) =>
                    setCartaoNovo({ ...cartaoNovo, final: evento.target.value.replace(/\D/g, "") })
                  }
                />
              </div>
              <div className="space-y-1">
                <Label htmlFor="novo-cartao-titular">Titular</Label>
                <Input
                  id="novo-cartao-titular"
                  value={cartaoNovo.titular}
                  onChange={(evento) =>
                    setCartaoNovo({ ...cartaoNovo, titular: evento.target.value })
                  }
                />
              </div>
              <div className="space-y-1">
                <Label>Banco cadastrado (opcional)</Label>
                <Select
                  value={cartaoNovo.bancoId || "nenhum"}
                  onValueChange={(valor) =>
                    setCartaoNovo({ ...cartaoNovo, bancoId: valor === "nenhum" ? "" : valor })
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="nenhum">Sem banco vinculado</SelectItem>
                    {bancos.map((banco) => (
                      <SelectItem key={banco.id} value={banco.id}>
                        {banco.nome}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setCadastroDestino(null)}>
              Cancelar
            </Button>
            <Button
              type="button"
              disabled={cadastrarDestino.isPending}
              onClick={() => cadastrarDestino.mutate()}
            >
              {cadastrarDestino.isPending ? "Salvando..." : "Salvar e continuar"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={dialogoSubst === "modo"} onOpenChange={(o) => !o && setDialogoSubst(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Este cartão já tem fatura neste mês</DialogTitle>
            <DialogDescription>
              A fatura que você enviou é fechada ou parcial? Fechada substitui o que está cadastrado
              deste cartão no mês, com backup para desfazer. Parcial só adiciona e pergunta sobre os
              parecidos.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            {Object.values(conflitosPorFatura)
              .filter((c) => !decisaoFatura[c.arquivo_hash])
              .map((c) => (
                <div key={c.arquivo_hash} className="space-y-2 rounded-lg border p-3">
                  <p className="text-sm font-medium">{c.rotulo}</p>
                  <p className="text-xs text-muted-foreground">{c.arquivo_nome}</p>
                  <div className="grid gap-2 sm:grid-cols-2">
                    <Button
                      type="button"
                      variant="outline"
                      className="h-auto flex-col items-start gap-0.5 whitespace-normal py-2 text-left"
                      onClick={() => setDecisaoFatura((p) => ({ ...p, [c.arquivo_hash]: "fechada" }))}
                    >
                      <span className="text-xs font-semibold">Fatura fechada</span>
                      <span className="text-[11px] font-normal opacity-80">
                        Substitui o que está cadastrado deste cartão no mês.
                      </span>
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      className="h-auto flex-col items-start gap-0.5 whitespace-normal py-2 text-left"
                      onClick={() => setDecisaoFatura((p) => ({ ...p, [c.arquivo_hash]: "parcial" }))}
                    >
                      <span className="text-xs font-semibold">Fatura parcial</span>
                      <span className="text-[11px] font-normal opacity-80">
                        Só adiciona. Pergunta sobre os parecidos.
                      </span>
                    </Button>
                  </div>
                </div>
              ))}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogoSubst(null)}>
              Cancelar
            </Button>
            <Button
              disabled={Object.values(conflitosPorFatura).some((c) => !decisaoFatura[c.arquivo_hash])}
              onClick={() => {
                setDialogoSubst(null);
                void decidirSubstituicoes(false);
              }}
            >
              Continuar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={dialogoSubst === "faltantes"} onOpenChange={(o) => !o && setDialogoSubst(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>A fatura anterior tinha lançamentos que a nova não traz</DialogTitle>
            <DialogDescription>
              Escolha o que fazer com eles em cada cartão. Nada é restaurado sem a sua escolha.
            </DialogDescription>
          </DialogHeader>
          <div className="max-h-[55vh] space-y-3 overflow-y-auto">
            {faltantesPendentes.map((p) => (
              <div key={p.arquivo_hash} className="space-y-2 rounded-lg border p-3">
                <p className="text-sm font-medium">
                  {p.rotulo} · {p.itens.length} lançamento(s) só na fatura anterior
                </p>
                <div className="max-h-32 space-y-0.5 overflow-y-auto text-xs text-muted-foreground">
                  {p.itens.map((i) => (
                    <div key={i.id} className="flex justify-between gap-2">
                      <span className="truncate">{i.descricao}</span>
                      <span className="shrink-0">{formatBRL(i.valor)}</span>
                    </div>
                  ))}
                </div>
                <div className="grid gap-2 sm:grid-cols-3">
                  {(
                    [
                      ["nova", "Manter só a nova", "Os que faltam saem do mês."],
                      ["mesclar", "Mesclar", "Nova mais os que faltam na nova."],
                      ["ambas", "Manter as duas", "Restaura todos da anterior. Pode duplicar."],
                    ] as const
                  ).map(([valor, titulo, texto]) => (
                    <Button
                      key={valor}
                      type="button"
                      variant={decisaoFaltantes[p.arquivo_hash] === valor ? "default" : "outline"}
                      className="h-auto flex-col items-start gap-0.5 whitespace-normal py-2 text-left"
                      onClick={() =>
                        setDecisaoFaltantes((d) => ({ ...d, [p.arquivo_hash]: valor }))
                      }
                    >
                      <span className="text-xs font-semibold">{titulo}</span>
                      <span className="text-[11px] font-normal opacity-80">{texto}</span>
                    </Button>
                  ))}
                </div>
              </div>
            ))}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogoSubst(null)}>
              Cancelar
            </Button>
            <Button
              disabled={faltantesPendentes.some((p) => !decisaoFaltantes[p.arquivo_hash])}
              onClick={() => {
                setDialogoSubst(null);
                void decidirSubstituicoes(false);
              }}
            >
              Continuar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={modalAnaliseOpen} onOpenChange={setModalAnaliseOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Faturas Enviadas para Análise</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <p className="text-xs text-muted-foreground">
              Abaixo estão os arquivos de fatura que você enviou para a nossa equipe calibrar o
              leitor de PDF.
            </p>
            {solicitacoesAnalise.length === 0 ? (
              <p className="py-4 text-center text-sm text-muted-foreground">
                Nenhuma fatura enviada para análise.
              </p>
            ) : (
              <div className="max-h-80 space-y-2 overflow-y-auto">
                {solicitacoesAnalise.map((item: any) => (
                  <div key={item.id} className="rounded-lg border p-3 text-xs">
                    <div className="flex items-center justify-between gap-2">
                      <b className="truncate text-sm">{item.arquivo_nome}</b>
                      <Badge variant="outline" className="shrink-0 text-[10px]">
                        {item.status === "corrigida"
                          ? "✓ Concluída / Tratada"
                          : item.status === "descartada"
                            ? "Descartada"
                            : item.status === "em_modelagem"
                              ? "Em análise"
                              : "Recebida"}
                      </Badge>
                    </div>
                    <p className="mt-1 text-muted-foreground">
                      Enviado em {new Date(item.criado_em).toLocaleDateString("pt-BR")}
                      {item.banco_informado ? ` · Banco: ${item.banco_informado}` : ""}
                      {item.cartao_final ? ` · Final: ${item.cartao_final}` : ""}
                    </p>
                    {item.protocolo && (
                      <p className="mt-0.5 font-mono text-[10px] text-muted-foreground/70">
                        Protocolo: {item.protocolo.substring(0, 8)}…
                      </p>
                    )}
                    {item.resposta_admin && (
                      <p className="mt-1 font-medium text-emerald-600">
                        Resposta: {item.resposta_admin}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
          <DialogFooter>
            <Button onClick={() => setModalAnaliseOpen(false)}>Fechar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!novaCategoria} onOpenChange={(o) => !o && setNovaCategoria(null)}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Nova categoria</DialogTitle>
            <DialogDescription>
              A categoria é criada agora e já fica selecionada nesta linha. Ela passa a aparecer em
              todas as listas de categoria do site.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-1">
            <Label className="text-xs">Nome</Label>
            <Input
              autoFocus
              value={novaCategoria?.nome ?? ""}
              placeholder="Ex.: Assinaturas, Pet, Educação"
              onChange={(e) =>
                setNovaCategoria((a) => (a ? { ...a, nome: e.target.value } : a))
              }
              onKeyDown={(e) => {
                if (e.key === "Enter" && novaCategoria?.nome.trim())
                  criarCategoria.mutate(novaCategoria);
              }}
            />
          </div>
          <DialogFooter className="gap-2 sm:gap-2">
            <Button variant="outline" onClick={() => setNovaCategoria(null)}>
              Cancelar
            </Button>
            <Button
              disabled={!novaCategoria?.nome.trim() || criarCategoria.isPending}
              onClick={() => novaCategoria && criarCategoria.mutate(novaCategoria)}
            >
              Criar e usar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {(() => {
        const f = duplicataAberta ? faturas[duplicataAberta.faturaIdx] : null;
        const l = f?.lancamentos.find((x) => x.id === duplicataAberta?.lancamentoId) ?? null;
        const chave = f && l ? chaveDup(f.arquivo_hash, l.id) : "";
        return (
          <DuplicidadeDialog
            aberto={!!f && !!l}
            onAberto={(v) => !v && setDuplicataAberta(null)}
            lancamento={l}
            candidatas={f && l ? candidatasDe(f, l) : []}
            acao={acoesDuplicata[chave]?.acao ?? "decidir"}
            alvoId={acoesDuplicata[chave]?.alvoId ?? null}
            onEscolher={(acao, alvoId) => f && l && definirAcaoDuplicata(f, l, acao, alvoId)}
          />
        );
      })()}
    </AppLayout>
  );
}
