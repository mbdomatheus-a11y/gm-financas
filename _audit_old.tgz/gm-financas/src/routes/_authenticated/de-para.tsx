import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useMemo, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Download, Globe, Loader2, Plus, Save, Search, Sparkles, Trash2, Upload } from "lucide-react";
import { toast } from "sonner";
import { identificarEstabelecimentoWeb } from "@/lib/depara-web.functions";

import { AppLayout } from "@/components/AppLayout";
import { AvisoPrimeiraVezDePara } from "@/components/AvisoPrimeiraVezDePara";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { usePermissoes, useSession } from "@/hooks/useAuthData";
import { useCategorias } from "@/hooks/useFinance";
import { chaveEstabelecimento, regrasBaseDoSistema } from "@/lib/categorizacao";
import {
  CABECALHO_DEPARA,
  EXEMPLOS_DEPARA,
  lerPlanilhaDePara,
  modeloCsv,
  type LinhaDePara,
} from "@/lib/depara";
import { baixarTxt, baixarXlsx } from "@/lib/exportar-planilha";

export const Route = createFileRoute("/_authenticated/de-para")({
  head: () => ({
    meta: [
      { title: "De-para de categorias — Control ALL" },
      {
        name: "description",
        content:
          "Suba uma planilha Excel ou CSV com o de-para de descrição para categoria e mantenha a categorização automática das despesas sempre calibrada.",
      },
      { property: "og:title", content: "De-para de categorias — Control ALL" },
      {
        property: "og:description",
        content: "Regras de categorização automática alimentadas por planilha Excel ou CSV.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: DeParaPage,
});

function DeParaPage() {
  const qc = useQueryClient();
  const { user } = useSession();
  const { exclusaoBloqueada } = usePermissoes();
  const inputRef = useRef<HTMLInputElement>(null);
  const { data: categorias = [] } = useCategorias("despesa");

  const [previa, setPrevia] = useState<LinhaDePara[]>([]);
  const [arquivo, setArquivo] = useState<string>("");
  const [lendo, setLendo] = useState(false);
  const [busca, setBusca] = useState("");
  const [nova, setNova] = useState({ descricao: "", categoria: "", subcategoria: "" });
  const [sel, setSel] = useState<Set<string>>(new Set());
  const [confirmar, setConfirmar] = useState<null | "selecionadas" | "todas">(null);
  const identificarWeb = useServerFn(identificarEstabelecimentoWeb);
  const [identificando, setIdentificando] = useState(false);
  const [explicacaoIa, setExplicacaoIa] = useState<string | null>(null);

  async function consultarSegmentoWeb(termo: string) {
    const limpo = termo.split("\n")[0]?.trim() || "";
    if (!limpo) {
      toast.info("Digite o nome do estabelecimento primeiro.");
      return;
    }
    setIdentificando(true);
    setExplicacaoIa(null);
    try {
      const res = await identificarWeb({ data: { termo: limpo } });
      setNova((n) => ({
        ...n,
        categoria: res.categoria,
        subcategoria: res.subcategoria || "",
      }));
      setExplicacaoIa(res.explicacao);
      toast.success(
        `Identificado: ${res.categoria}${res.subcategoria ? ` / ${res.subcategoria}` : ""} (${res.confianca === "alta" ? "Alta confiança" : "Confiança média"}).`
      );
    } catch (e: any) {
      toast.error(e?.message ?? "Não foi possível identificar o estabelecimento online.");
    } finally {
      setIdentificando(false);
    }
  }

  const { data: regras = [], isLoading } = useQuery({
    queryKey: ["categoria-regras"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("categoria_regras")
        .select("*")
        .order("categoria")
        .order("estabelecimento_normalizado");
      if (error) throw error;
      return data ?? [];
    },
  });

  const nomesCategorias = useMemo(
    () => new Set((categorias as any[]).map((c) => c.nome.toLowerCase())),
    [categorias],
  );

  const categoriasNovas = useMemo(
    () =>
      Array.from(
        new Set(
          previa.map((l) => l.categoria).filter((c) => !nomesCategorias.has(c.toLowerCase())),
        ),
      ),
    [previa, nomesCategorias],
  );

  const filtradas = useMemo(() => {
    const q = busca.trim().toLowerCase();
    if (!q) return regras as any[];
    return (regras as any[]).filter(
      (r) =>
        String(r.texto_original ?? "")
          .toLowerCase()
          .includes(q) ||
        String(r.estabelecimento_normalizado ?? "")
          .toLowerCase()
          .includes(q) ||
        String(r.categoria ?? "")
          .toLowerCase()
          .includes(q),
    );
  }, [regras, busca]);

  async function onFile(file: File | null | undefined) {
    if (!file) return;
    setLendo(true);
    try {
      const linhas = await lerPlanilhaDePara(file);
      if (!linhas.length) {
        toast.error("Não encontrei colunas de estabelecimento e categoria na planilha.");
        return;
      }
      setPrevia(linhas);
      setArquivo(file.name);
      toast.success(`${linhas.length} linha(s) lida(s).`);
    } catch (erro) {
      toast.error(
        erro instanceof Error
          ? erro.message
          : "Não consegui ler este arquivo. Use Excel (.xlsx) ou CSV.",
      );
    } finally {
      setLendo(false);
      if (inputRef.current) inputRef.current.value = "";
    }
  }

  const salvar = useMutation({
    mutationFn: async (linhas: LinhaDePara[]) => {
      const faltantes = Array.from(
        new Set(
          linhas.map((l) => l.categoria).filter((c) => !nomesCategorias.has(c.toLowerCase())),
        ),
      );
      if (faltantes.length) {
        const { error } = await supabase
          .from("categorias")
          .insert(faltantes.map((nome) => ({ nome, tipo: "despesa" })));
        if (error) throw error;
      }

      const payload = linhas.map((l) => ({
        texto_original: l.descricao,
        estabelecimento_normalizado: l.estabelecimento_normalizado,
        // Bloco 4: quando a linha não traz variações extras, a regra fica
        // com um padrão só — igual ao comportamento de sempre.
        padroes: l.padroes && l.padroes.length > 0 ? l.padroes : [l.estabelecimento_normalizado],
        tipo_regra: "de_para",
        categoria: l.categoria,
        subcategoria: l.subcategoria,
        prioridade: l.prioridade,
        ativo: true,
        origem_arquivo: arquivo || null,
        created_by: user?.id ?? null,
      }));

      for (const item of payload) {
        const { data: existente } = await supabase
          .from("categoria_regras")
          .select("id")
          .eq("estabelecimento_normalizado", item.estabelecimento_normalizado)
          .eq("tipo_regra", "de_para")
          .maybeSingle();
        if (existente) {
          const { error } = await supabase
            .from("categoria_regras")
            .update(item)
            .eq("id", existente.id);
          if (error) throw error;
        } else {
          const { error } = await supabase.from("categoria_regras").insert(item);
          if (error) throw error;
        }
      }
      return { total: payload.length, novas: faltantes.length };
    },
    onSuccess: ({ total, novas }) => {
      qc.invalidateQueries({ queryKey: ["categoria-regras"] });
      qc.invalidateQueries({ queryKey: ["categorias", "despesa"] });
      setPrevia([]);
      setArquivo("");
      toast.success(`${total} regra(s) salvas. ${novas} categoria(s) criada(s).`);
    },
    onError: (e: any) => toast.error(e?.message ?? "Falha ao salvar as regras."),
  });

  const atualizar = useMutation({
    mutationFn: async ({
      id,
      patch,
    }: {
      id: string;
      patch: Partial<{
        categoria: string;
        subcategoria: string | null;
        ativo: boolean;
        padroes: string[];
        estabelecimento_normalizado: string;
      }>;
    }) => {
      const { error } = await supabase.from("categoria_regras").update(patch).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["categoria-regras"] }),
    onError: (e: any) => toast.error(e?.message ?? "Falha ao atualizar."),
  });

  const remover = useMutation({
    mutationFn: async (id: string) => {
      if (exclusaoBloqueada) throw new Error("Seu perfil não possui permissão para excluir dados.");
      const { error } = await supabase.from("categoria_regras").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["categoria-regras"] });
      toast.success("Regra removida.");
    },
  });

  const { data: aprendidas = [], isLoading: carregandoAprendidas } = useQuery({
    queryKey: ["classificacoes-aprendidas"],
    queryFn: async () => {
      const { data, error } = await (supabase as any)
        .from("importacao_preferencias")
        .select("id,chave,acao,atualizado_em")
        .eq("escopo", "classificacao")
        .order("chave");
      if (error) throw error;
      return (data ?? []).map((r: any) => {
        let acao: any = {};
        try {
          acao = JSON.parse(r.acao ?? "{}");
        } catch {
          /* linha antiga ou inválida: aparece sem categoria */
        }
        return {
          id: r.id as string,
          chave: r.chave as string,
          categoria: (acao.categoria as string) ?? "",
          subcategoria: (acao.subcategoria as string | null) ?? null,
          atualizado_em: (r.atualizado_em as string | null) ?? null,
        };
      });
    },
  });

  const esquecer = useMutation({
    mutationFn: async (chave: string) => {
      if (exclusaoBloqueada) throw new Error("Seu perfil não possui permissão para excluir dados.");
      const { error } = await (supabase as any).rpc("esquecer_classificacao", { p_chave: chave });
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["classificacoes-aprendidas"] });
      toast.success("Classificação esquecida.");
    },
    onError: (e: any) => toast.error(e?.message ?? "Não foi possível esquecer a classificação."),
  });

  const excluirVarias = useMutation({
    mutationFn: async (ids: string[]) => {
      if (exclusaoBloqueada) throw new Error("Seu perfil não possui permissão para excluir dados.");
      if (ids.length === 0) return;
      const { error } = await supabase.from("categoria_regras").delete().in("id", ids);
      if (error) throw error;
    },
    onSuccess: (_r, ids) => {
      qc.invalidateQueries({ queryKey: ["categoria-regras"] });
      setSel(new Set());
      setConfirmar(null);
      toast.success(`${ids.length} regra(s) removida(s).`);
    },
    onError: (e: any) => toast.error(e.message),
  });

  /** Exportação: regras do sistema e as suas, com a coluna "origem". */
  function baixarDeParaCompleto(incluirSistema: boolean) {
    const linhas: string[][] = [];
    if (incluirSistema)
      for (const r of regrasBaseDoSistema())
        linhas.push([r.estabelecimento, r.categoria, r.subcategoria ?? "", "sistema"]);
    for (const r of regras as any[])
      linhas.push([
        String(r.texto_original ?? r.estabelecimento_normalizado),
        String(r.categoria ?? ""),
        String(r.subcategoria ?? ""),
        "usuario",
      ]);
    baixarTxt(incluirSistema ? "de-para-completo" : "backup-de-para", [...CABECALHO_DEPARA, "origem"], linhas);
  }

  const idsRegras = (regras as any[]).map((r) => r.id as string);
  const todasMarcadas = idsRegras.length > 0 && idsRegras.every((id) => sel.has(id));

  function alternarSel(id: string) {
    setSel((a) => {
      const n = new Set(a);
      if (n.has(id)) n.delete(id);
      else n.add(id);
      return n;
    });
  }

  function baixarModelo() {
    const blob = new Blob([modeloCsv()], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "modelo-de-para.csv";
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <AppLayout
      title="De-para de categorias"
      description="Suba a planilha com estabelecimento → categoria. Toda importação passa a usar essas regras."
    >
      <AvisoPrimeiraVezDePara />
      <Card>
        <CardContent className="p-4">
          <div
            className="flex cursor-pointer flex-wrap items-center gap-x-3 gap-y-1 rounded-lg border border-dashed px-4 py-2.5 text-left transition-colors hover:bg-muted/50"
            onClick={() => inputRef.current?.click()}
            onDragOver={(e) => e.preventDefault()}
            onDrop={(e) => {
              e.preventDefault();
              void onFile(e.dataTransfer.files?.[0]);
            }}
          >
            {lendo ? (
              <Loader2 className="size-6 animate-spin text-muted-foreground" />
            ) : (
              <Upload className="size-6 text-muted-foreground" />
            )}
            <p className="text-sm font-medium">Arraste a planilha ou clique para selecionar</p>
            <p className="text-xs text-muted-foreground">
              Excel (.xlsx), CSV ou TXT · colunas: estabelecimento, categoria, subcategoria (opcional)
            </p>
            <input
              ref={inputRef}
              type="file"
              accept=".xlsx,.csv,.txt,text/csv,text/plain"
              className="hidden"
              onChange={(e) => void onFile(e.target.files?.[0])}
            />
          </div>
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <span className="text-xs text-muted-foreground">Baixar modelo:</span>
            <Button variant="outline" size="sm" onClick={() => baixarXlsx("modelo-de-para", CABECALHO_DEPARA, EXEMPLOS_DEPARA)}>
              <Download className="mr-2 size-4" /> Excel
            </Button>
            <Button variant="outline" size="sm" onClick={() => baixarDeParaCompleto(true)}>
              <Download className="mr-2 size-4" /> TXT
            </Button>
            <Button variant="outline" size="sm" onClick={baixarModelo}>
              <Download className="mr-2 size-4" /> CSV
            </Button>
          </div>
        </CardContent>
      </Card>

      {previa.length > 0 && (
        <Card className="mt-4">
          <CardHeader className="flex-row items-center justify-between gap-2 pb-3">
            <CardTitle className="text-base">
              Prévia de {arquivo} · {previa.length} linha(s)
            </CardTitle>
            <div className="flex items-center gap-2">
              <Button variant="ghost" onClick={() => setPrevia([])}>
                Cancelar
              </Button>
              <Button onClick={() => salvar.mutate(previa)} disabled={salvar.isPending}>
                {salvar.isPending ? (
                  <Loader2 className="mr-2 size-4 animate-spin" />
                ) : (
                  <Save className="mr-2 size-4" />
                )}
                Salvar regras
              </Button>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            {idsRegras.length > 0 && (
              <div className="flex flex-wrap items-center gap-2 border-b px-4 py-2">
                <label className="flex items-center gap-2 text-xs">
                  <Checkbox
                    checked={todasMarcadas}
                    onCheckedChange={(v) => setSel(v ? new Set(idsRegras) : new Set())}
                    aria-label="Selecionar todas as regras"
                  />
                  Selecionar todas
                </label>
                <div className="ml-auto flex flex-wrap items-center gap-2">
                  <Button variant="outline" size="sm" onClick={() => baixarDeParaCompleto(false)}>
                    <Download className="mr-2 size-4" /> Backup das minhas
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => baixarDeParaCompleto(true)}>
                    <Download className="mr-2 size-4" /> Baixar tudo (sistema + minhas)
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={sel.size === 0 || exclusaoBloqueada}
                    onClick={() => setConfirmar("selecionadas")}
                  >
                    <Trash2 className="mr-2 size-4" /> Excluir selecionadas ({sel.size})
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="text-destructive"
                    disabled={exclusaoBloqueada}
                    onClick={() => setConfirmar("todas")}
                  >
                    Excluir todas
                  </Button>
                </div>
              </div>
            )}
            {categoriasNovas.length > 0 && (
              <p className="px-6 pb-3 text-xs text-muted-foreground">
                Serão criadas {categoriasNovas.length} categoria(s) nova(s):{" "}
                <span className="font-medium text-foreground">{categoriasNovas.join(", ")}</span>
              </p>
            )}
            <div className="max-h-[420px] overflow-auto">
              <table className="w-full text-sm">
                <thead className="sticky top-0 bg-muted/50 text-xs text-muted-foreground">
                  <tr>
                    <th className="p-2 text-left">Estabelecimento</th>
                    <th className="p-2 text-left">Categoria</th>
                    <th className="p-2 text-left">Subcategoria</th>
                    <th className="w-10 p-2"></th>
                  </tr>
                </thead>
                <tbody>
                  {previa.map((l, i) => (
                    <tr key={l.estabelecimento_normalizado} className="border-t">
                      <td className="p-2">
                        <Input
                          className="h-8"
                          value={l.descricao}
                          onChange={(e) =>
                            setPrevia((p) =>
                              p.map((x, j) =>
                                j === i
                                  ? {
                                      ...x,
                                      descricao: e.target.value,
                                      estabelecimento_normalizado: chaveEstabelecimento(
                                        e.target.value,
                                      ),
                                    }
                                  : x,
                              ),
                            )
                          }
                        />
                      </td>
                      <td className="p-2">
                        <Input
                          className="h-8"
                          value={l.categoria}
                          onChange={(e) =>
                            setPrevia((p) =>
                              p.map((x, j) => (j === i ? { ...x, categoria: e.target.value } : x)),
                            )
                          }
                        />
                      </td>
                      <td className="p-2">
                        <Input
                          className="h-8"
                          value={l.subcategoria ?? ""}
                          onChange={(e) =>
                            setPrevia((p) =>
                              p.map((x, j) =>
                                j === i ? { ...x, subcategoria: e.target.value || null } : x,
                              ),
                            )
                          }
                        />
                      </td>
                      <td className="p-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => setPrevia((p) => p.filter((_, j) => j !== i))}
                        >
                          <Trash2 className="size-4" />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      <Card className="mt-4">
        <CardHeader className="gap-3 pb-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <CardTitle className="text-base">Regras ativas ({regras.length})</CardTitle>
            <div className="relative">
              <Search className="absolute left-2 top-2.5 size-4 text-muted-foreground" />
              <Input
                className="h-9 w-[220px] pl-8"
                placeholder="Buscar regra"
                value={busca}
                onChange={(e) => setBusca(e.target.value)}
              />
            </div>
          </div>
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-[1fr_1fr_1fr_auto]">
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <Label className="text-xs">Estabelecimento (uma variação por linha)</Label>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="h-5 px-1.5 text-[11px] gap-1 text-primary hover:text-primary hover:bg-primary/10"
                  disabled={identificando || !nova.descricao.trim()}
                  onClick={() => void consultarSegmentoWeb(nova.descricao)}
                >
                  <Sparkles className="size-3" />
                  {identificando ? "Pesquisando…" : "Identificar na Web"}
                </Button>
              </div>
              <Textarea
                className="min-h-9 py-2 text-sm"
                rows={1}
                placeholder="Ex.: MERCADO X"
                value={nova.descricao}
                onChange={(e) => setNova((n) => ({ ...n, descricao: e.target.value }))}
              />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Categoria</Label>
              <Input
                className="h-9"
                value={nova.categoria}
                onChange={(e) => setNova((n) => ({ ...n, categoria: e.target.value }))}
              />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Subcategoria</Label>
              <Input
                className="h-9"
                value={nova.subcategoria}
                onChange={(e) => setNova((n) => ({ ...n, subcategoria: e.target.value }))}
              />
            </div>
            <div className="flex items-end">
              <Button
                className="h-9"
                disabled={!nova.descricao.trim() || !nova.categoria.trim() || salvar.isPending}
                onClick={() => {
                  // Bloco 4: cada linha da textarea é uma variação de
                  // descrição que deve bater na mesma regra/categoria.
                  const linhas = Array.from(
                    new Set(
                      nova.descricao
                        .split("\n")
                        .map((l) => l.trim())
                        .filter(Boolean),
                    ),
                  );
                  const principal = linhas[0] ?? nova.descricao.trim();
                  salvar.mutate([
                    {
                      descricao: principal,
                      estabelecimento_normalizado: chaveEstabelecimento(principal),
                      padroes: linhas,
                      categoria: nova.categoria.trim(),
                      subcategoria: nova.subcategoria.trim() || null,
                      prioridade: 300,
                    },
                  ]);
                  setNova({ descricao: "", categoria: "", subcategoria: "" });
                }}
              >
                <Plus className="mr-2 size-4" /> Adicionar
              </Button>
            </div>
          </div>
          {explicacaoIa && (
            <div className="flex items-start justify-between gap-2 rounded-lg border border-primary/30 bg-primary/5 p-2.5 text-xs">
              <div className="flex items-start gap-2">
                <Sparkles className="mt-0.5 size-3.5 shrink-0 text-primary" />
                <p className="text-foreground">{explicacaoIa}</p>
              </div>
              <button
                type="button"
                onClick={() => setExplicacaoIa(null)}
                className="text-[10px] text-muted-foreground hover:text-foreground"
              >
                Dispensar
              </button>
            </div>
          )}
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <p className="px-6 pb-6 text-sm text-muted-foreground">Carregando…</p>
          ) : filtradas.length === 0 ? (
            <p className="px-6 pb-6 text-sm text-muted-foreground">
              Nenhuma regra cadastrada ainda.
            </p>
          ) : (
            <div className="max-h-[520px] overflow-auto">
              <table className="w-full text-sm">
                <thead className="sticky top-0 bg-muted/50 text-xs text-muted-foreground">
                  <tr>
                    <th className="w-8 p-2"></th>
                    <th className="p-2 text-left">Estabelecimento</th>
                    <th className="p-2 text-left">Categoria</th>
                    <th className="p-2 text-left">Subcategoria</th>
                    <th className="p-2 text-left">Origem</th>
                    <th className="p-2 text-left">Ativa</th>
                    <th className="w-10 p-2"></th>
                  </tr>
                </thead>
                <tbody>
                  {filtradas.map((r) => (
                    <tr key={r.id} className="border-t">
                      <td className="p-2">
                        <Checkbox
                          checked={sel.has(r.id)}
                          onCheckedChange={() => alternarSel(r.id)}
                          aria-label={`Selecionar regra ${r.texto_original ?? r.estabelecimento_normalizado}`}
                        />
                      </td>
                      <td className="p-2">
                        <div className="flex items-center justify-between gap-1">
                          <p className="font-medium">
                            {r.texto_original ?? r.estabelecimento_normalizado}
                          </p>
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            className="size-6 text-muted-foreground hover:text-primary"
                            title="Pesquisar segmento deste estabelecimento na Web"
                            onClick={async () => {
                              const termo = r.texto_original ?? r.estabelecimento_normalizado;
                              try {
                                const res = await identificarWeb({ data: { termo } });
                                atualizar.mutate({
                                  id: r.id,
                                  patch: {
                                    categoria: res.categoria,
                                    subcategoria: res.subcategoria,
                                  },
                                });
                                toast.success(`${termo}: ${res.categoria}${res.subcategoria ? ` / ${res.subcategoria}` : ""} (${res.explicacao})`);
                              } catch {
                                toast.error("Não foi possível pesquisar este estabelecimento online.");
                              }
                            }}
                          >
                            <Sparkles className="size-3" />
                          </Button>
                        </div>
                        {/* Bloco 4: edita as variações que casam com essa regra,
                            uma por linha — primeira linha vira o padrão principal
                            (estabelecimento_normalizado), mantido por compatibilidade. */}
                        <Textarea
                          className="mt-1 min-h-7 py-1 text-[11px] text-muted-foreground"
                          rows={1}
                          defaultValue={(r.padroes?.length ? r.padroes : [r.estabelecimento_normalizado]).join(
                            "\n",
                          )}
                          onBlur={(e) => {
                            const linhas = Array.from(
                              new Set(
                                e.target.value
                                  .split("\n")
                                  .map((l: string) => l.trim())
                                  .filter(Boolean),
                              ),
                            );
                            if (linhas.length === 0) return;
                            const principal = chaveEstabelecimento(linhas[0]!);
                            const mudou =
                              linhas.join("\n") !==
                              (r.padroes?.length ? r.padroes : [r.estabelecimento_normalizado]).join(
                                "\n",
                              );
                            if (mudou)
                              atualizar.mutate({
                                id: r.id,
                                patch: { padroes: linhas, estabelecimento_normalizado: principal },
                              });
                          }}
                        />
                      </td>
                      <td className="p-2">
                        <Input
                          className="h-8"
                          defaultValue={r.categoria}
                          onBlur={(e) =>
                            e.target.value !== r.categoria &&
                            atualizar.mutate({ id: r.id, patch: { categoria: e.target.value } })
                          }
                        />
                      </td>
                      <td className="p-2">
                        <Input
                          className="h-8"
                          defaultValue={r.subcategoria ?? ""}
                          onBlur={(e) =>
                            (e.target.value || null) !== r.subcategoria &&
                            atualizar.mutate({
                              id: r.id,
                              patch: { subcategoria: e.target.value || null },
                            })
                          }
                        />
                      </td>
                      <td className="p-2 text-xs text-muted-foreground">
                        <Badge variant="secondary">{r.origem_arquivo ?? r.tipo_regra}</Badge>
                      </td>
                      <td className="p-2">
                        <Switch
                          checked={r.ativo !== false}
                          onCheckedChange={(v) =>
                            atualizar.mutate({ id: r.id, patch: { ativo: v } })
                          }
                        />
                      </td>
                      <td className="p-2">
                        <Button variant="ghost" size="icon" onClick={() => remover.mutate(r.id)}>
                          <Trash2 className="size-4" />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
      <Card className="mt-4">
        <CardHeader>
          <CardTitle className="text-base">Classificações aprendidas</CardTitle>
          <p className="text-sm text-muted-foreground">
            Estabelecimentos que a importação lembra para o seu grupo. Ao esquecer, a próxima importação
            volta a perguntar ou usar o aprendizado geral. Nenhum lançamento já salvo muda.
          </p>
        </CardHeader>
        <CardContent className="p-0">
          {carregandoAprendidas ? (
            <p className="p-4 text-sm text-muted-foreground">Carregando…</p>
          ) : aprendidas.length === 0 ? (
            <p className="p-4 text-sm text-muted-foreground">Nenhuma classificação aprendida ainda.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted/50 text-left text-xs uppercase text-muted-foreground">
                  <tr>
                    <th className="px-4 py-2">Estabelecimento</th>
                    <th className="px-4 py-2">Categoria</th>
                    <th className="px-4 py-2">Subcategoria</th>
                    <th className="px-4 py-2 text-right">Ação</th>
                  </tr>
                </thead>
                <tbody>
                  {(aprendidas as any[]).map((a) => (
                    <tr key={a.id} className="border-t">
                      <td className="px-4 py-2 font-medium">{a.chave}</td>
                      <td className="px-4 py-2">{a.categoria || "—"}</td>
                      <td className="px-4 py-2">{a.subcategoria || "—"}</td>
                      <td className="px-4 py-2 text-right">
                        <Button
                          variant="ghost"
                          size="sm"
                          disabled={esquecer.isPending}
                          onClick={() => esquecer.mutate(a.chave)}
                        >
                          <Trash2 className="mr-1 size-4" /> Esquecer
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
      <AlertDialog open={confirmar !== null} onOpenChange={(o) => !o && setConfirmar(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {confirmar === "todas" ? "Excluir todas as regras de de-para?" : `Excluir ${sel.size} regra(s)?`}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {confirmar === "todas"
                ? `Serão removidas ${idsRegras.length} regra(s) suas. As regras do sistema não são afetadas.`
                : `Serão removidas ${sel.size} regra(s) selecionada(s).`}{" "}
              Lançamentos já categorizados não mudam. Esta ação não pode ser desfeita. Antes de excluir, baixe um backup.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="flex-col gap-2 sm:flex-row">
            <Button variant="outline" onClick={() => baixarDeParaCompleto(false)}>
              <Download className="mr-2 size-4" /> Baixar backup
            </Button>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              disabled={excluirVarias.isPending}
              onClick={(ev) => {
                ev.preventDefault();
                excluirVarias.mutate(confirmar === "todas" ? idsRegras : [...sel]);
              }}
            >
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AppLayout>
  );
}
