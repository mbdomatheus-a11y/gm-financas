import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Bell } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { alertasDosVeiculos } from "@/lib/veiculo-alertas";
import { diasRestantes } from "@/lib/nfe";
import { proximaVirada } from "@/lib/periodo-vigente";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { useServerFn } from "@tanstack/react-start";
import {
  limparVersoesSite,
  meuHistoricoAlertas,
  minhasChavesAlertasLidos,
  marcarAlertasLidosLote,
  versoesAtivasSite,
} from "@/lib/comunicados.functions";
import { useIsSiteAdmin } from "@/hooks/useAuthData";
import { useModoCliente } from "@/lib/modo-cliente";
import {
  agendarLembretesNoApp,
  ehAppNativo,
  momentoLembrete,
  ponteNativa,
  type LembreteApp,
} from "@/lib/app-nativo";

type Aviso = {
  chave: string;
  texto: string;
  destino?: "/notas" | "/veiculos" | "/lista-compras" | "/cartoes" | "/despesas";
};

// Fatura de cartão (fechamento/vencimento, pedido explícito do usuário em
// 2026-10-02): limiares mais curtos que os de garantia/veículo (crítico
// ≤15/atenção ≤30 dias) porque o ciclo é mensal — um limiar de 30 dias
// disparia quase sempre, pra qualquer cartão, o tempo todo.
const LIMIAR_ATENCAO_FATURA_DIAS = 7;
const LIMIAR_CRITICO_FATURA_DIAS = 3;
// Contas/parcelas a vencer (idem, pedido explícito do usuário): mesma
// janela e limiares já usados pra garantia de nota fiscal e alertas do
// veículo (crítico ≤15/atenção ≤30 dias), aplicados sobre `parcelas` reais
// não pagas — nunca projeta parcela que não existe de verdade.
const JANELA_PARCELAS_DIAS = 30;

export function AlertsBell() {
  const historicoFn = useServerFn(meuHistoricoAlertas);
  const chavesFn = useServerFn(minhasChavesAlertasLidos);
  const marcarLoteFn = useServerFn(marcarAlertasLidosLote);
  const [aberto, setAberto] = useState(false);
  const [vistos, setVistos] = useState<Aviso[]>([]);
  const versoesFn = useServerFn(versoesAtivasSite);
  const limparFn = useServerFn(limparVersoesSite);
  const { data: isSiteAdminRaw } = useIsSiteAdmin();
  const modoCliente = useModoCliente();
  const isSiteAdminUser = !!isSiteAdminRaw && !modoCliente;
  // Dentro do app do iPhone: sem avisos de deploy do site e com botão de testar notificação.
  const [ehApp, setEhApp] = useState(false);
  useEffect(() => {
    setEhApp(ehAppNativo());
    const aoResponder = (ev: Event) => {
      const r = (ev as CustomEvent<{ ok: boolean; erro?: string }>).detail;
      if (!r?.ok) toast.error(r?.erro ?? "Não consegui agendar a notificação de teste.");
    };
    window.addEventListener("notificacao-app-resultado", aoResponder);
    return () => window.removeEventListener("notificacao-app-resultado", aoResponder);
  }, []);
  function testarNotificacao() {
    const ponte = ponteNativa("notificacoesApp");
    if (!ponte) {
      toast.error("Atualize o app pelo TestFlight para testar notificações.");
      return;
    }
    ponte.postMessage({ acao: "testar" });
    toast.success("Bloqueie a tela agora: a notificação chega em 5 segundos.");
  }
  const { data: versoes = [], refetch: refetchVersoes } = useQuery({
    queryKey: ["versoes-site"],
    queryFn: () => versoesFn(),
  });
  const { data: chavesLidas = [], refetch: refetchLidas } = useQuery({
    queryKey: ["alertas-lidos"],
    queryFn: () => chavesFn(),
  });
  const { data: historico = [] } = useQuery({
    queryKey: ["historico-alertas"],
    queryFn: () => historicoFn(),
  });
  const { data: avisos = [] } = useQuery({
    queryKey: ["alertas-globais"],
    queryFn: async (): Promise<Aviso[]> => {
      const [veiculos, notas, compras, cartoes, parcelas] = await Promise.all([
        supabase
          .from("veiculos")
          .select(
            "id,nome,km_atual,km_proxima_troca_oleo,data_proxima_troca_oleo,data_vencimento_ipva,data_vencimento_seguro",
          ),
        supabase
          .from("notas_fiscais")
          .select("id,estabelecimento,descricao,garantia_fim")
          .not("garantia_fim", "is", null),
        supabase
          .from("lista_compras")
          .select("id,nome,comprado,aprovacoes_necessarias,aprovado_por,alerta_em")
          .eq("comprado", false),
        supabase.from("cartoes").select("id,apelido,dia_fechamento,dia_vencimento"),
        supabase
          .from("parcelas")
          .select("id,vencimento,despesas(descricao,cartao_id)")
          .eq("paga", false)
          .order("vencimento", { ascending: true })
          .limit(200),
      ]);
      if (veiculos.error || notas.error || compras.error || cartoes.error || parcelas.error)
        throw new Error("Não foi possível carregar os alertas.");
      const alertas: Aviso[] = alertasDosVeiculos(veiculos.data ?? []).map((alerta) => {
        const veiculo = (veiculos.data ?? []).find((item) => item.id === alerta.veiculoId);
        const referencia =
          alerta.tipo === "oleo"
            ? `${veiculo?.km_proxima_troca_oleo ?? ""}:${veiculo?.data_proxima_troca_oleo ?? ""}`
            : alerta.tipo === "ipva"
              ? veiculo?.data_vencimento_ipva
              : veiculo?.data_vencimento_seguro;
        return {
          chave: `veiculo:${alerta.veiculoId}:${alerta.tipo}:${referencia ?? "sem-data"}`,
          texto: `${alerta.veiculoNome}: ${alerta.mensagem}`,
          destino: "/veiculos",
        };
      });
      for (const nota of notas.data ?? []) {
        if (!nota.garantia_fim) continue;
        const dias = diasRestantes(nota.garantia_fim);
        if (dias !== null && dias >= -30 && dias <= 30)
          alertas.push({
            chave: `garantia:${nota.id}:${nota.garantia_fim}`,
            texto: `${nota.estabelecimento ?? nota.descricao ?? "Nota fiscal"}: garantia ${dias < 0 ? `vencida há ${Math.abs(dias)} dias` : `vence em ${dias} dias`}`,
            destino: "/notas",
          });
      }
      for (const compra of compras.data ?? []) {
        const aprovadores = Array.isArray(compra.aprovado_por) ? compra.aprovado_por : [];
        if (
          (compra.aprovacoes_necessarias ?? 0) > 0 &&
          aprovadores.length >= (compra.aprovacoes_necessarias ?? 0)
        ) {
          alertas.push({
            chave: `compra-aprovada:${compra.id}:${aprovadores.length}`,
            texto: `${compra.nome}: compra aprovada`,
            destino: "/lista-compras",
          });
        } else if (compra.alerta_em && compra.alerta_em <= new Date().toISOString().slice(0, 10)) {
          alertas.push({
            chave: `compra-alerta:${compra.id}:${compra.alerta_em}`,
            texto: `${compra.nome}: lembrete da lista de compras`,
            destino: "/lista-compras",
          });
        }
      }
      // Fatura de cartão fechando/vencendo em breve — pedido explícito do
      // usuário em 2026-10-02 (central de avisos, item "notificações").
      const hoje = new Date();
      for (const cartao of cartoes.data ?? []) {
        const checagens: { tipo: string; dia: number | null; rotulo: string }[] = [
          { tipo: "fechamento", dia: cartao.dia_fechamento, rotulo: "Fechamento da fatura" },
          { tipo: "vencimento", dia: cartao.dia_vencimento, rotulo: "Vencimento da fatura" },
        ];
        for (const c of checagens) {
          if (!c.dia) continue;
          const proxima = proximaVirada(hoje, c.dia);
          const dias = Math.round(
            (proxima.getTime() - new Date(hoje.toDateString()).getTime()) / 86400000,
          );
          if (dias > LIMIAR_ATENCAO_FATURA_DIAS) continue;
          alertas.push({
            chave: `cartao:${cartao.id}:${c.tipo}:${proxima.toISOString().slice(0, 10)}`,
            texto: `${cartao.apelido}: ${c.rotulo.toLowerCase()} ${dias === 0 ? "é hoje" : `em ${dias}d`}${dias <= LIMIAR_CRITICO_FATURA_DIAS ? " !" : ""}`,
            destino: "/cartoes",
          });
        }
      }
      // Contas e parcelas a vencer — mesmo pedido, só parcelas reais e não
      // pagas (nunca inventa parcela projetada de despesa fixa sem prazo).
      for (const parcela of parcelas.data ?? []) {
        const dias = diasRestantes(parcela.vencimento);
        if (dias === null || dias < -JANELA_PARCELAS_DIAS || dias > JANELA_PARCELAS_DIAS) continue;
        const descricao = (parcela as { despesas?: { descricao?: string } | null }).despesas
          ?.descricao;
        alertas.push({
          chave: `parcela:${parcela.id}:${parcela.vencimento}`,
          texto: `${descricao ?? "Despesa"}: parcela ${
            dias < 0
              ? `venceu há ${Math.abs(dias)}d`
              : dias === 0
                ? "vence hoje"
                : `vence em ${dias}d`
          }`,
          destino: "/despesas",
        });
      }
      // No app do iPhone: agenda notificações na tela de bloqueio para os próximos vencimentos
      // (funciona com o app fechado, sem servidor de push). No navegador não faz nada.
      if (ehAppNativo()) {
        const lembretes: LembreteApp[] = [];
        const hojeLocal = new Date();
        for (const cartao of cartoes.data ?? []) {
          const nome = cartao.apelido || "cartão";
          if (cartao.dia_vencimento) {
            const venc = proximaVirada(new Date(hojeLocal.getTime() - 86400000), cartao.dia_vencimento);
            lembretes.push(
              { id: `fatura-${cartao.id}-vespera`, titulo: "Fatura vence amanhã", corpo: `A fatura do ${nome} vence amanhã.`, quando: momentoLembrete(venc, 9, 1), destino: "/despesas" },
              { id: `fatura-${cartao.id}-dia`, titulo: "Fatura vence hoje", corpo: `A fatura do ${nome} vence hoje.`, quando: momentoLembrete(venc, 9, 0), destino: "/despesas" },
            );
          }
          if (cartao.dia_fechamento) {
            const fecha = proximaVirada(new Date(hojeLocal.getTime() - 86400000), cartao.dia_fechamento);
            lembretes.push({ id: `fechamento-${cartao.id}`, titulo: "Fatura fecha hoje", corpo: `A fatura do ${nome} fecha hoje. Compras a partir de agora vão para a próxima.`, quando: momentoLembrete(fecha, 9, 0), destino: "/despesas" });
          }
        }
        // Contas fora do cartão (o cartão já é avisado pela fatura), agrupadas por dia.
        const porDia = new Map<string, string[]>();
        for (const parcela of parcelas.data ?? []) {
          const despesa = (parcela as { despesas?: { descricao?: string; cartao_id?: string | null } | null }).despesas;
          if (despesa?.cartao_id) continue;
          const dia = String(parcela.vencimento).slice(0, 10);
          porDia.set(dia, [...(porDia.get(dia) ?? []), despesa?.descricao ?? "Conta"]);
        }
        for (const [dia, nomes] of porDia) {
          const resumo = nomes.length === 1 ? nomes[0]! : `${nomes.length} contas (${nomes.slice(0, 3).join(", ")}${nomes.length > 3 ? "…" : ""})`;
          lembretes.push(
            { id: `contas-${dia}-vespera`, titulo: "Conta vence amanhã", corpo: `${resumo} vence amanhã.`, quando: momentoLembrete(dia, 9, 1), destino: "/despesas" },
            { id: `contas-${dia}-dia`, titulo: "Conta vence hoje", corpo: `${resumo} vence hoje.`, quando: momentoLembrete(dia, 9, 0), destino: "/despesas" },
          );
        }
        for (const nota of notas.data ?? []) {
          if (!nota.garantia_fim) continue;
          const nome = nota.estabelecimento ?? nota.descricao ?? "compra";
          lembretes.push({ id: `garantia-${nota.id}`, titulo: "Garantia termina em 7 dias", corpo: `A garantia de ${nome} termina em 7 dias.`, quando: momentoLembrete(nota.garantia_fim, 9, 7), destino: "/notas" });
        }
        agendarLembretesNoApp(lembretes);
      }
      return alertas.slice(0, 50);
    },
    refetchInterval: 60_000,
  });
  const avisosComVersao: Aviso[] = [
    ...avisos,
    ...(ehApp ? [] : versoes).map((v: any) => ({
      chave: `versao:${v.versao}`,
      texto: `Nova versão publicada: build ${v.versao} · ${new Date(v.build_em ?? v.criado_em).toLocaleString("pt-BR")}`,
    })),
  ];
  const naoLidos = avisosComVersao.filter((aviso) => !chavesLidas.includes(aviso.chave));
  // Ao abrir o sino, os avisos novos ficam visíveis enquanto ele está aberto e
  // já contam como vistos: ao fechar, somem e vão para o histórico de 7 dias.
  // Só reaparece algo se chegar um aviso novo.
  const lista = aberto ? vistos : naoLidos;

  function aoAbrir(valor: boolean) {
    setAberto(valor);
    if (valor) {
      setVistos(naoLidos);
      if (naoLidos.length > 0) {
        void marcarLoteFn({
          data: {
            itens: naoLidos.slice(0, 60).map((a) => ({
              chave: a.chave,
              titulo: a.chave.startsWith("versao:") ? "Atualização do Control ALL" : "Alerta do Control ALL",
              mensagem: a.texto,
            })),
          },
        }).then(() => refetchLidas());
      }
    }
  }

  return (
    <Popover open={aberto} onOpenChange={aoAbrir}>
      <PopoverTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          aria-label={`${naoLidos.length} alertas não lidos`}
          className="relative"
        >
          <Bell className="size-5" />
          {naoLidos.length > 0 && (
            <span className="absolute -right-1 -top-1 rounded-full bg-destructive px-1.5 text-[10px] font-bold text-destructive-foreground">
              {naoLidos.length}
            </span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent align="end" className="max-h-96 w-80 overflow-y-auto p-2">
        <p className="px-2 py-1 text-sm font-semibold">Alertas novos ({lista.length})</p>
        {lista.length === 0 ? (
          <p className="px-2 py-3 text-sm text-muted-foreground">Nenhum alerta no momento.</p>
        ) : (
          lista.map((aviso, indice) =>
            aviso.destino ? (
              <Link
                key={`${aviso.destino}-${indice}`}
                to={aviso.destino}
                onClick={() => setAberto(false)}
                className="block rounded-md px-2 py-2 text-sm hover:bg-accent"
              >
                {aviso.texto}
              </Link>
            ) : (
              <button
                key={aviso.chave}
                className="block w-full rounded-md px-2 py-2 text-left text-sm hover:bg-accent"
              >
                {aviso.texto}
              </button>
            ),
          )
        )}
        {isSiteAdminUser && versoes.length > 0 && (
          <Button
            variant="outline"
            size="sm"
            className="mt-2 w-full"
            onClick={() => void limparFn().then(() => refetchVersoes())}
          >
            Limpar versões para todos
          </Button>
        )}
        {ehApp && (
          <Button variant="outline" size="sm" className="mt-2 w-full" onClick={testarNotificacao}>
            Testar notificação no iPhone
          </Button>
        )}
        {historico.length > 0 && (
          <>
            <p className="mt-2 border-t px-2 py-2 text-xs font-semibold uppercase text-muted-foreground">
              Histórico (últimos 7 dias)
            </p>
            {historico.slice(0, 8).map((aviso: any) => (
              <div key={aviso.id} className="rounded-md px-2 py-2 text-sm">
                <p className="font-medium">{aviso.titulo}</p>
                <p className="line-clamp-2 text-xs text-muted-foreground">{aviso.mensagem}</p>
              </div>
            ))}
          </>
        )}
      </PopoverContent>
    </Popover>
  );
}
