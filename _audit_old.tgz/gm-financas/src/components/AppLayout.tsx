import { AppEmBreve } from "@/components/AppEmBreve";
import { ConvitesRecebidosAviso } from "@/components/ConvitesGrupo";
import { AvisoSincronizacaoPluggy } from "@/components/AvisoSincronizacaoPluggy";
import { useEffect, useState, type MouseEvent, type ReactNode } from "react";
import { lembrarUrlRetorno, limparUrlRetorno } from "@/lib/return-url";
import { useServerFn } from "@tanstack/react-start";
import { encerrarSessao } from "@/lib/login-protecao.functions";
import { Link, useNavigate, useRouter, useRouterState } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  LayoutDashboard,
  TrendingUp,
  TrendingDown,
  CreditCard,
  PiggyBank,
  Share2,
  Users,
  Settings,
  LogOut,
  Menu,
  Wallet,
  Tags,
  FileUp,
  Home,
  ShoppingCart,
  DatabaseBackup,
  ReceiptText,
  ArrowLeftRight,
  Calculator,
  Car,
  PawPrint,
  MapPin,
  FileHeart,
  ShieldCheck,
  CalendarDays,
  Headphones,
  Link2,
  ArrowLeft,
  ChevronDown,
  Landmark,
  PieChart,
} from "lucide-react";

import type { LucideIcon } from "lucide-react";
import { Plus } from "lucide-react";
import { Fragment } from "react";
import { AvatarPerfil } from "@/components/AvatarPerfil";
import { SeletorIdioma } from "@/components/SeletorIdioma";
import { SincronizadorAgendaApp } from "@/components/SincronizadorAgendaApp";
import { useIdioma } from "@/hooks/useIdioma";
import type { ChaveTraducao } from "@/lib/i18n/traducoes";
import { supabase } from "@/integrations/supabase/client";
import {
  useModulosGlobais,
  useProfile,
  usePermissoes,
  type Modulo,
  type ModuloGlobal,
} from "@/hooks/useAuthData";
import { useApplyPreferencias, usePreferencias } from "@/hooks/usePreferencias";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTitle } from "@/components/ui/sheet";
import { AlertsBell } from "@/components/AlertsBell";
import { CalculadoraRapida } from "@/components/CalculadoraRapida";
import { ConviteRapidoBotao } from "@/components/ConviteAmigosBanner";
import { BrandMark } from "@/components/BrandMark";
import { BotaoLancamentoRapido } from "@/components/LancamentoRapido/BotaoLancamentoRapido";
import { obterUsoOracleDoMeuGrupo } from "@/lib/oracle-admin.functions";
import { definirModoCliente, useModoCliente } from "@/lib/modo-cliente";
import { usePrivacidadeValores } from "@/hooks/usePrivacidadeValores";
import { definirOcultarValoresNaArea } from "@/lib/format";
import { useMascaraValores } from "@/hooks/useMascaraValores";
import { Eye, EyeOff } from "lucide-react";
import { ADMIN_ONLY_TAG, AREAS, ORDEM_AREAS, type AreaId } from "@/lib/areas";

/** Item 16 (backlog 2026-09-27): mostra a cota de armazenamento Oracle do
 * PRÓPRIO grupo do usuário (nunca de outro grupo), embaixo do nome do site
 * e do usuário, com escala de cor conforme o uso (verde/amarelo/vermelho).
 * Fica em branco (não renderiza nada) se o Oracle não estiver habilitado
 * para o grupo — evita confundir quem nunca usou essa área. */
function OracleQuotaBadge() {
  const obterFn = useServerFn(obterUsoOracleDoMeuGrupo);
  const { data } = useQuery({
    queryKey: ["oracle-quota-meu-grupo"],
    queryFn: () => obterFn(),
    staleTime: 60_000,
  });

  if (!data || !data.habilitado || data.cotaBytes <= 0) return null;

  const pct = Math.min(100, (data.usadoBytes / data.cotaBytes) * 100);
  const cor = pct >= 90 ? "bg-destructive" : pct >= 70 ? "bg-warning" : "bg-success";
  const corTexto = pct >= 90 ? "text-destructive" : pct >= 70 ? "text-warning" : "text-success";

  const formatarMb = (bytes: number) => `${(bytes / (1024 * 1024)).toFixed(0)} MB`;

  return (
    <div
      className="mt-1.5 px-2"
      title={`${formatarMb(data.usadoBytes)} de ${formatarMb(data.cotaBytes)} usados`}
    >
      <div className="flex items-center justify-between gap-2">
        <span className="text-[10px] text-muted-foreground">Armazenamento</span>
        <span className={`text-[10px] font-semibold tabular-nums ${corTexto}`}>
          {formatarMb(data.usadoBytes)} / {formatarMb(data.cotaBytes)}
        </span>
      </div>
      <div className="mt-0.5 h-1 overflow-hidden rounded-full bg-muted">
        <div className={`h-full rounded-full ${cor}`} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

type NavTo =
  | "/inicio"
  | "/links-temporarios"
  | "/dashboard"
  | "/receitas"
  | "/despesas"
  | "/importar"
  | "/categorias"
  | "/de-para"
  | "/lista-compras"
  | "/notas"
  | "/links"
  | "/cartoes"
  | "/investimentos"
  | "/veiculos"
  | "/compartilhar"
  | "/ferramentas"
  | "/usuarios"
  | "/backup"
  | "/personalizacao"
  | "/conta"
  | "/configuracoes"
  | "/pets"
  | "/onde-esta"
  | "/exames"
  | "/administracao"
  | "/pluggy"
  | "/para-onde-vai"
  | "/calendario"
  | "/casa"
  | "/documentos"
  | "/suporte";

type NavItem = {
  to: NavTo;
  label: string;
  short: string;
  icon: typeof LayoutDashboard;
  modulo?: Modulo;
  adminOnly?: boolean;
  grupoAdmin?: boolean;
  moduloGlobal?: ModuloGlobal;
};

type MundoId =
  "financas" | "lista" | "notas" | "calculadora" | "pet" | "onde_esta" | "veiculo" | "exames" | "links";

/**
 * Navegação em "mundos" (2026-09-18, revisado em 2026-09-26): cada módulo
 * da Início (Finanças, Lista, Notas, Calculadora, Pet, Onde está?, Veículo,
 * Exames) vira seu próprio "mundo", com o mesmo nome exibido nos dois
 * lugares — antes "Vida" e "Veículo" ficavam agrupados/escondidos dentro de
 * outros mundos e não apareciam como opção própria na barra do topo. Dentro
 * de cada mundo, o menu lateral mostra só os itens daquele mundo — pra não
 * misturar despesas/investimentos com a lista de compras, por exemplo.
 * "Início" fica sempre fixo no topo do menu como botão de voltar.
 * Ferramentas administrativas/utilitárias (Compartilhar, Usuários, Backup,
 * Personalização, Conta) ficam numa seção global, visível o tempo todo,
 * independente do mundo atual.
 */
/** Rotas com rótulo já traduzido; as demais seguem em português por enquanto. */
const CHAVE_NAV: Partial<Record<NavTo, ChaveTraducao>> = {
  "/inicio": "nav.inicio",
  "/dashboard": "nav.dashboard",
  "/receitas": "nav.receitas",
  "/despesas": "nav.despesas",
  "/cartoes": "nav.cartoes",
  "/investimentos": "nav.investimentos",
  "/importar": "nav.importar",
  "/para-onde-vai": "nav.paraOndeVai",
  "/lista-compras": "nav.lista",
  "/veiculos": "nav.veiculo",
  "/pets": "nav.pet",
  "/exames": "nav.exames",
  "/notas": "nav.notas",
  "/links": "nav.anotacoes",
  "/ferramentas": "nav.calculadora",
  "/configuracoes": "nav.configuracoes",
  "/conta": "nav.conta",
};

const MUNDOS: Record<MundoId, { titulo: string; home: NavTo; items: NavItem[] }> = {
  financas: {
    titulo: "Finanças",
    home: "/dashboard",
    items: [
      {
        to: "/dashboard",
        label: "Dashboard",
        short: "Dashboard",
        icon: LayoutDashboard,
        moduloGlobal: "financas",
      },
      {
        to: "/receitas",
        label: "Receitas",
        short: "Receitas",
        icon: TrendingUp,
        modulo: "receitas",
      },
      {
        to: "/despesas",
        label: "Despesas",
        short: "Despesas",
        icon: TrendingDown,
        modulo: "despesas",
      },
      {
        to: "/para-onde-vai",
        label: "Para onde vai meu dinheiro",
        short: "Para onde vai",
        icon: PieChart,
        modulo: "despesas",
      },
      {
        to: "/importar",
        label: "Importar Faturas",
        short: "Faturas",
        icon: FileUp,
        // Etapa D (plano-importacao-v2.md): módulo próprio em vez de
        // reaproveitar "despesas" — permite ao admin bloquear o acesso à
        // importação sem afetar a visualização normal de despesas.
        modulo: "importar",
      },
      { to: "/categorias", label: "Categorias", short: "Categ.", icon: Tags },
      {
        to: "/de-para",
        label: "De-para de categorias",
        short: "De-para",
        icon: ArrowLeftRight,
        modulo: "despesas",
      },
      {
        to: "/cartoes",
        label: "Cartões e Bancos",
        short: "Cartões",
        icon: CreditCard,
        modulo: "cartoes",
      },
      {
        to: "/investimentos",
        label: "Investimentos",
        short: "Invest.",
        icon: PiggyBank,
        modulo: "investimentos",
      },
    ],
  },
  lista: {
    titulo: "Lista",
    home: "/lista-compras",
    items: [
      {
        to: "/lista-compras",
        label: "Lista de compras",
        short: "Compras",
        icon: ShoppingCart,
        moduloGlobal: "lista",
      },
    ],
  },
  notas: {
    titulo: "Notas",
    home: "/notas",
    items: [
      {
        to: "/notas",
        label: "Notas fiscais",
        short: "Notas",
        icon: ReceiptText,
        moduloGlobal: "notas",
      },
    ],
  },
  links: {
    titulo: "Links",
    home: "/links",
    items: [
      {
        to: "/links",
        label: "Links",
        short: "Links",
        icon: Link2,
        moduloGlobal: "links",
      },
    ],
  },
  calculadora: {
    titulo: "Utilidades",
    home: "/ferramentas",
    items: [
      {
        to: "/ferramentas",
        label: "Calculadoras",
        short: "Calculadoras",
        icon: Calculator,
        moduloGlobal: "calculadora",
      },
      {
        to: "/links-temporarios",
        label: "Link temporário",
        short: "Link",
        icon: Link2,
        moduloGlobal: "calculadora",
      },
    ],
  },
  pet: {
    titulo: "Pet",
    home: "/pets",
    items: [{ to: "/pets", label: "Pet", short: "Pet", icon: PawPrint, moduloGlobal: "pet" }],
  },
  onde_esta: {
    titulo: "Onde está?",
    home: "/onde-esta",
    items: [
      {
        to: "/onde-esta",
        label: "Onde está?",
        short: "Onde",
        icon: MapPin,
        moduloGlobal: "onde_esta",
      },
    ],
  },
  veiculo: {
    titulo: "Veículo",
    home: "/veiculos",
    items: [
      {
        to: "/veiculos",
        label: "Meu Veículo",
        short: "Veículo",
        icon: Car,
        modulo: "veiculos",
        moduloGlobal: "veiculo",
      },
    ],
  },
  exames: {
    titulo: "Exames",
    home: "/exames",
    items: [
      { to: "/exames", label: "Exames", short: "Exames", icon: FileHeart, moduloGlobal: "exames" },
    ],
  },
};

/** Itens sempre visíveis, independente do mundo atual (ou de estar na Home). */
const GLOBAL: NavItem[] = [
  {
    to: "/compartilhar",
    label: "Compartilhar",
    short: "Compart.",
    icon: Share2,
    modulo: "compartilhar",
  },
  {
    to: "/usuarios",
    label: "Usuários e Privilégios",
    short: "Usuários",
    icon: Users,
    adminOnly: true,
  },
  {
    to: "/pluggy",
    label: "Bancos (teste)",
    short: "Bancos",
    icon: Landmark,
    adminOnly: true,
  },
  {
    to: "/administracao",
    label: "Administração do site",
    short: "Admin",
    icon: ShieldCheck,
    adminOnly: true,
  },
  {
    to: "/backup",
    label: "Backup e Reset",
    short: "Backup",
    icon: DatabaseBackup,
    grupoAdmin: true,
  },
  {
    to: "/configuracoes",
    label: "Configurações",
    short: "Config.",
    icon: Settings,
  },
  { to: "/suporte", label: "Suporte", short: "Suporte", icon: Headphones },
];

/** Atalhos da barra inferior no celular (Início fica fixo ao lado). */
/** Versão do app iOS instalada (o app nativo informa em window.__controlAllApp). No navegador não aparece. */
function VersaoDoApp() {
  const [info, setInfo] = useState<{ versao: string; build: string } | null>(null);
  useEffect(() => {
    const app = (window as unknown as { __controlAllApp?: { versao: string; build: string } }).__controlAllApp;
    if (app?.versao) setInfo({ versao: app.versao, build: app.build });
  }, []);
  if (!info) return null;
  return (
    <p className="mt-auto border-t px-2 pt-3 text-center text-[11px] text-muted-foreground">
      Control ALL para iPhone · versão {info.versao} (build {info.build})
    </p>
  );
}

const ATALHOS_MOBILE: { id: MundoId; rotulo: string; icon: LucideIcon }[] = [
  { id: "financas", rotulo: "Finanças", icon: Wallet },
  { id: "notas", rotulo: "Notas", icon: ReceiptText },
  { id: "lista", rotulo: "Lista", icon: ShoppingCart },
];

const CALENDARIO: NavItem = {
  to: "/calendario",
  label: "Calendário",
  short: "Agenda",
  icon: CalendarDays,
};

const INICIO: NavItem = { to: "/inicio", label: "Início", short: "Início", icon: Home };

/** Descobre em qual "mundo" a rota atual está, se estiver em algum. */
function mundoAtual(pathname: string): MundoId | null {
  for (const [id, mundo] of Object.entries(MUNDOS) as [MundoId, (typeof MUNDOS)[MundoId]][]) {
    if (mundo.items.some((i) => i.to === pathname)) return id;
  }
  return null;
}

export function AppLayout({
  title,
  description,
  actions,
  children,
}: {
  title: string;
  description?: string;
  actions?: ReactNode;
  children: ReactNode;
}) {
  useApplyPreferencias();
  const { prefs } = usePreferencias();
  const { data: profile } = useProfile();
  const { can, isSiteAdmin, isAdmin } = usePermissoes();
  const modoCliente = useModoCliente();
  const { t } = useIdioma();
  /** Rótulo do item no idioma escolhido; sem tradução ainda, mantém o original. */
  const rotuloNav = (item: NavItem) => {
    const chave = CHAVE_NAV[item.to];
    return chave ? t(chave) : item.label;
  };
  const { ocultarValores, toggle: alternarOcultarValores } = usePrivacidadeValores();
  // Olho global: liga a máscara antes de desenhar a página e remonta o conteúdo ao alternar,
  // para que todas as cifras (formatBRL/formatUSD) sigam a escolha na hora.
  definirOcultarValoresNaArea(ocultarValores);
  useEffect(() => () => definirOcultarValoresNaArea(false), []);
  const { habilitado, liberadoGeral } = useModulosGlobais();
  useMascaraValores(ocultarValores);
  const navigate = useNavigate();
  const router = useRouter();
  const qc = useQueryClient();
  const registrarEncerramento = useServerFn(encerrarSessao);
  const [open, setOpen] = useState(false);
  const location = useRouterState({ select: (s) => s.location });
  const pathname = location.pathname;

  // Preserva o caminho atual e parâmetros para recuperar se a sessão for reconectada
  if (typeof window !== "undefined" && pathname && pathname !== "/entrar" && pathname !== "/") {
    const currentFullUrl = `${location.pathname}${location.searchStr ?? ""}`;
    lembrarUrlRetorno(currentFullUrl);
  }

  const podeVer = (i: NavItem) => {
    if (modoCliente && (i.adminOnly || i.grupoAdmin)) return false;
    if (i.adminOnly) return isSiteAdmin;
    if (i.grupoAdmin) return isAdmin;
    if (i.moduloGlobal && !habilitado(i.moduloGlobal)) return false;
    if (i.modulo) return can(i.modulo, "ver");
    return true;
  };

  const mundoId = mundoAtual(pathname);
  const mundo = mundoId ? MUNDOS[mundoId] : null;
  const mundoGlobal: Partial<Record<MundoId, ModuloGlobal>> = {
    financas: "financas",
    lista: "lista",
    notas: "notas",
    calculadora: "calculadora",
    pet: "pet",
    onde_esta: "onde_esta",
    veiculo: "veiculo",
    exames: "exames",
    links: "links",
  };
  const mundoVisivel = (id: MundoId) => {
    const m = MUNDOS[id];
    const global = mundoGlobal[id];
    if (global && !habilitado(global)) return false;
    return m.items.filter(podeVer).length > 0;
  };
  const mundosVisiveis = (Object.keys(MUNDOS) as MundoId[]).filter(mundoVisivel);
  const areasVisiveis = ORDEM_AREAS.filter((a) =>
    AREAS[a].modulos.some((m) => mundosVisiveis.includes(m as MundoId)),
  );
  const areaId: AreaId | null =
    ORDEM_AREAS.find(
      (a) =>
        pathname === AREAS[a].to ||
        (mundoId !== null && AREAS[a].modulos.includes(mundoId as ModuloGlobal)),
    ) ?? null;
  const area = areaId ? AREAS[areaId] : null;
  const soAdminItem = (i: NavItem) =>
    isSiteAdmin && !!i.moduloGlobal && !liberadoGeral(i.moduloGlobal);
  const itensDoMundo = (
    mundo && (!mundoId || !mundoGlobal[mundoId] || habilitado(mundoGlobal[mundoId]!))
      ? mundo.items
      : []
  ).filter(podeVer);
  const itensGlobais = GLOBAL.filter(podeVer).filter((i) => !i.adminOnly);
  const itensAdmin = GLOBAL.filter(podeVer).filter((i) => i.adminOnly);
  // Botão central da barra do celular: ação principal de cada área (só onde existe uma ação única).
  const podeLancar = can("despesas", "editar") || can("receitas", "editar");
  const acaoCentral: { rotulo: string; curto: string; evento: string } | null = pathname.startsWith("/notas")
    ? { rotulo: "Nova nota", curto: "Nota", evento: "abrir-nova-nota" }
    : pathname.startsWith("/lista-compras")
      ? { rotulo: "Novo item", curto: "Item", evento: "abrir-novo-item-lista" }
      : pathname.startsWith("/onde-esta")
        ? { rotulo: "Novo item", curto: "Item", evento: "abrir-novo-item-onde-esta" }
        : pathname.startsWith("/veiculos")
          ? { rotulo: "Novo veículo", curto: "Veículo", evento: "abrir-novo-veiculo" }
          : mundoId === "financas" && !pathname.startsWith("/despesas") && podeLancar
            ? { rotulo: "Lançar", curto: "Lançar", evento: "abrir-lancamento-rapido" }
            : null;
  // No modo usuário comum, páginas exclusivas de admin mostram aviso em vez do conteúdo.
  const rotaAdminBloqueada =
    modoCliente &&
    [...GLOBAL, ...Object.values(MUNDOS).flatMap((m) => m.items)].some(
      (i) => (i.adminOnly || i.grupoAdmin) && i.to === pathname,
    );
  // "superior": menu horizontal no desktop. Padrão ("lateral"): barra lateral.
  const topMenu = prefs.layout_menu === "superior";
  const [abertas, setAbertas] = useState<Record<string, boolean>>({});
  useEffect(() => setAbertas({}), [areaId]);

  async function signOut() {
    try {
      await registrarEncerramento({ data: { motivo: "usuario" } });
    } catch {
      // Falha de telemetria não impede sair.
    }
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    sessionStorage.removeItem("control-all-sessao-iniciada");
    sessionStorage.removeItem("control-all-sessao-max-min");
    limparUrlRetorno();
    navigate({ to: "/entrar", replace: true });
  }
  // Tela Ajustes do app pede para sair por evento (o sair completo mora aqui).
  useEffect(() => {
    const sair = () => void signOut();
    window.addEventListener("sair-da-conta", sair);
    return () => window.removeEventListener("sair-da-conta", sair);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const NavLink = ({
      item,
      onNavigate,
      ativo,
      recuo,
      soAdmin,
      aoClicar,
      aberto,
    }: {
      item: NavItem;
      onNavigate?: (() => void) | undefined;
      ativo?: boolean | undefined;
      recuo?: boolean | undefined;
      soAdmin?: boolean | undefined;
      aoClicar?: ((e: MouseEvent) => void) | undefined;
      aberto?: boolean | undefined;
    }) => {
    const active = ativo ?? pathname === item.to;
    const Icon = item.icon;
    return (
      <Link
        to={item.to}
        onClick={(e: MouseEvent<HTMLAnchorElement>) => {
          aoClicar?.(e);
          if (!e.defaultPrevented) onNavigate?.();
        }}
        aria-expanded={aberto}
        className={cn(
          "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors",
          recuo && "ml-4 py-2 text-[13px]",
          soAdmin && !active && "bg-violet-500/[0.07] text-violet-700 dark:text-violet-300",
          active
            ? "bg-primary/10 text-primary shadow-[inset_3px_0_0_var(--brand)]"
            : "text-muted-foreground hover:bg-sidebar-accent/60 hover:text-sidebar-accent-foreground",
        )}
      >
        <Icon className={cn("size-4.5 shrink-0", active && "text-primary")} />
        <span className="truncate">{rotuloNav(item)}</span>
        {soAdmin && <span className={cn(ADMIN_ONLY_TAG, "ml-auto")}>Admin</span>}
        {aberto !== undefined && (
          <ChevronDown
            aria-hidden="true"
            className={cn("ml-auto size-4 shrink-0 transition-transform", aberto && "rotate-180")}
          />
        )}
      </Link>
    );
  };

  const NavLinks = ({ onNavigate }: { onNavigate?: (() => void) | undefined }) => (
    <nav className="flex flex-1 flex-col gap-1 overflow-y-auto">
      <NavLink item={INICIO} onNavigate={onNavigate} />
      <NavLink item={CALENDARIO} onNavigate={onNavigate} />

      {areasVisiveis.length > 0 && (
        <p className="mt-3 px-3 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground/70">
          Áreas
        </p>
      )}
      {areasVisiveis.map((id) => {
        const a = AREAS[id];
        const ativa = areaId === id;
        const aberta = abertas[id] ?? ativa;
        const entrada: NavItem = { to: a.to, label: a.titulo, short: a.titulo, icon: a.icon };
        const filhos = a.modulos
          .filter((m) => mundosVisiveis.includes(m as MundoId))
          .flatMap((m) => MUNDOS[m as MundoId].items)
          .filter(podeVer)
          .filter((i) => i.to !== a.to);
        return (
          <div key={id} className="flex flex-col gap-1">
            <NavLink
              item={entrada}
              onNavigate={onNavigate}
              ativo={ativa && pathname === a.to}
              aberto={filhos.length > 0 ? aberta : undefined}
              aoClicar={(e) => {
                // Segundo clique na área já aberta recolhe as opções.
                if (aberta && pathname === a.to) {
                  e.preventDefault();
                  setAbertas((s) => ({ ...s, [id]: false }));
                } else {
                  setAbertas((s) => ({ ...s, [id]: true }));
                }
              }}
            />
            {aberta &&
              filhos.map((item) => (
                <NavLink key={item.to} item={item} onNavigate={onNavigate} recuo soAdmin={soAdminItem(item)} />
              ))}
          </div>
        );
      })}

      <p className="mt-3 px-3 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground/70">
        Geral
      </p>
      {itensGlobais.map((item) => (
        <NavLink key={item.to} item={item} onNavigate={onNavigate} />
      ))}

      {itensAdmin.length > 0 && (
        <>
          <p className="mt-3 px-3 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground/70">
            Administração
          </p>
          {itensAdmin.map((item) => (
            <NavLink key={item.to} item={item} onNavigate={onNavigate} soAdmin />
          ))}
        </>
      )}
    </nav>
  );

  const SidebarInner = ({ onNavigate }: { onNavigate?: (() => void) | undefined }) => (
    <div className="flex h-full flex-col gap-4 p-4">
      <Link to="/dashboard" onClick={onNavigate} className="flex items-center gap-3 px-2 py-1">
        <BrandMark className="size-9 rounded-xl" />
        <div className="min-w-0">
          <p className="truncate text-sm font-bold leading-tight">Control ALL</p>
          <p className="truncate text-[11px] font-medium text-primary">Você no controle de tudo</p>
          <p className="truncate text-xs text-muted-foreground">{profile?.nome ?? ""}</p>
        </div>
      </Link>
      <OracleQuotaBadge />
      {/* Só no app do iPhone: tela de Ajustes própria (idioma, notificações, agenda, versão). */}
      <Link
        to="/ajustes-app"
        onClick={onNavigate}
        className="hidden items-center gap-3 rounded-xl border bg-card px-3 py-2.5 text-sm font-medium native:flex"
      >
        <span className="flex size-8 items-center justify-center rounded-lg bg-slate-700 text-white">
          <Settings className="size-4.5" aria-hidden="true" />
        </span>
        Ajustes do app
      </Link>
      <NavLinks onNavigate={onNavigate} />
      <Button
        variant="ghost"
        className="justify-start gap-3 text-muted-foreground"
        onClick={signOut}
      >
        <LogOut className="size-4.5" /> Sair
      </Button>
      <VersaoDoApp />
    </div>
  );

  const linkTopo = (active: boolean) =>
    cn(
      "inline-flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
      active ? "bg-primary/10 text-primary" : "text-muted-foreground hover:bg-muted hover:text-foreground",
    );

  const TopMenuBar = () => (
    <div className="sticky top-0 z-30 hidden h-14 items-center gap-1 border-b bg-sidebar px-4 lg:flex">
      <Link to="/dashboard" className="mr-3 flex items-center gap-2">
        <BrandMark className="size-8 rounded-lg" />
        <span className="text-sm font-bold">Control ALL</span>
      </Link>
      {[INICIO, CALENDARIO].map((item) => {
        const Icon = item.icon;
        return (
          <Link key={item.to} to={item.to} className={linkTopo(pathname === item.to)}>
            <Icon className="size-4" aria-hidden="true" /> {rotuloNav(item)}
          </Link>
        );
      })}
      {areasVisiveis.map((id) => {
        const a = AREAS[id];
        const Icon = a.icon;
        const filhos = a.modulos
          .filter((m) => mundosVisiveis.includes(m as MundoId))
          .flatMap((m) => MUNDOS[m as MundoId].items)
          .filter(podeVer)
          .filter((i) => i.to !== a.to);
        const ativa = areaId === id;
        if (filhos.length === 0) {
          return (
            <Link key={id} to={a.to} className={linkTopo(ativa)}>
              <Icon className="size-4" aria-hidden="true" /> {a.titulo}
            </Link>
          );
        }
        return (
          <DropdownMenu key={id}>
            <DropdownMenuTrigger className={linkTopo(ativa)}>
              <Icon className="size-4" aria-hidden="true" /> {a.titulo}
              <ChevronDown className="size-3.5" aria-hidden="true" />
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="min-w-52">
              <DropdownMenuItem asChild>
                <Link to={a.to}>Visão geral</Link>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              {filhos.map((item) => {
                const IconeItem = item.icon;
                return (
                  <DropdownMenuItem key={item.to} asChild>
                    <Link to={item.to} className="flex items-center gap-2">
                      <IconeItem className="size-4" aria-hidden="true" /> {rotuloNav(item)}
                      {soAdminItem(item) && <span className={cn(ADMIN_ONLY_TAG, "ml-auto")}>Admin</span>}
                    </Link>
                  </DropdownMenuItem>
                );
              })}
            </DropdownMenuContent>
          </DropdownMenu>
        );
      })}
      <div className="ml-auto flex items-center gap-1">
        <DropdownMenu>
          <DropdownMenuTrigger className={linkTopo(false)}>
            {profile?.nome ?? "Conta"} <ChevronDown className="size-3.5" aria-hidden="true" />
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="min-w-56">
            {itensGlobais.map((item) => {
              const IconeItem = item.icon;
              return (
                <DropdownMenuItem key={item.to} asChild>
                  <Link to={item.to} className="flex items-center gap-2">
                    <IconeItem className="size-4" aria-hidden="true" /> {rotuloNav(item)}
                  </Link>
                </DropdownMenuItem>
              );
            })}
            {itensAdmin.length > 0 && <DropdownMenuSeparator />}
            {itensAdmin.map((item) => {
              const IconeItem = item.icon;
              return (
                <DropdownMenuItem key={item.to} asChild className="bg-violet-500/[0.07]">
                  <Link to={item.to} className="flex items-center gap-2">
                    <IconeItem className="size-4" aria-hidden="true" /> {rotuloNav(item)}
                    <span className={cn(ADMIN_ONLY_TAG, "ml-auto")}>Admin</span>
                  </Link>
                </DropdownMenuItem>
              );
            })}
            <DropdownMenuSeparator />
            <DropdownMenuItem onSelect={() => void signOut()}>
              <LogOut className="size-4" aria-hidden="true" /> Sair
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background">
      {!topMenu && (
        <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 border-r bg-sidebar lg:block">
          <SidebarInner />
        </aside>
      )}

      <div className={cn(!topMenu && "lg:pl-64")}>
        {topMenu && <TopMenuBar />}
        <ConvitesRecebidosAviso />
        <AvisoSincronizacaoPluggy />
        <header
          className={cn(
            "sticky top-0 z-20 border-b border-border bg-background shadow-sm",
            topMenu && "lg:top-14",
          )}
        >
          <div className="flex items-center gap-3 px-4 py-3">
            {pathname !== "/inicio" && (
              <Button
                variant="ghost"
                size="sm"
                className="shrink-0 gap-1.5 px-2"
                aria-label="Voltar"
                title="Voltar para a tela anterior"
                onClick={() => {
                  if (typeof window !== "undefined" && window.history.length > 1) router.history.back();
                  else void navigate({ to: "/inicio" });
                }}
              >
                <ArrowLeft className="size-4.5" aria-hidden="true" />
                <span className="hidden text-xs font-medium sm:inline">Voltar</span>
              </Button>
            )}
            <div className="min-w-0 flex-1">
              <h1 className="truncate text-base font-semibold leading-tight sm:text-lg">{title}</h1>
              {description && (
                <p className="truncate text-xs text-muted-foreground">{description}</p>
              )}
            </div>
            <div className="flex shrink-0 items-center gap-0.5 sm:gap-2">
              <Button
                variant={ocultarValores ? "default" : "ghost"}
                size={ocultarValores ? "sm" : "icon"}
                className={cn(ocultarValores && "gap-1.5 animate-pulse")}
                onClick={alternarOcultarValores}
                aria-label={ocultarValores ? "Mostrar valores em R$" : "Ocultar valores em R$"}
                title={
                  ocultarValores
                    ? "Mostrar valores em R$ (global)"
                    : "Ocultar valores em R$ (global) — cada caixa também tem seu próprio olho"
                }
              >
                {ocultarValores ? <EyeOff className="size-4.5" /> : <Eye className="size-4.5" />}
                {ocultarValores && <span className="text-xs font-semibold">Mostrar valores</span>}
              </Button>
              <Button asChild variant="ghost" size="sm" className="hidden gap-1.5 px-2 sm:inline-flex">
                <Link to="/calendario" aria-label="Abrir calendário" title="Calendário">
                  <CalendarDays className="size-4.5" />
                  <span className="hidden text-xs font-medium sm:inline">Calendário</span>
                </Link>
              </Button>
              {/* No app o idioma fica em Ajustes; no site continua aqui no topo. */}
              <span className="contents native:hidden">
                <SeletorIdioma />
              </span>
              <CalculadoraRapida />
              <AvatarPerfil tamanho="size-8" className="ml-1" />
              <span className="hidden sm:contents">
                <ConviteRapidoBotao />
              </span>
              <AlertsBell />
              {actions}
            </div>
          </div>
          {mundo && itensDoMundo.length > 0 && (
            <nav
              aria-label={`Páginas de ${mundo.titulo}`}
              className="overflow-x-auto border-t px-4 py-2 [scrollbar-width:none] lg:hidden [&::-webkit-scrollbar]:hidden"
            >
              <div className="flex w-max gap-2">
                <Link
                  to="/inicio"
                  className="inline-flex items-center gap-1 rounded-full border px-3 py-1.5 text-xs font-medium text-muted-foreground"
                >
                  <Home className="size-3.5" />
                  Início
                </Link>
                {itensDoMundo.map((i) => {
                  const Ic = i.icon;
                  const ativo = pathname === i.to;
                  return (
                    <Link
                      key={i.to}
                      to={i.to}
                      aria-current={ativo ? "page" : undefined}
                      className={cn(
                        "inline-flex items-center gap-1 rounded-full border px-3 py-1.5 text-xs font-medium",
                        ativo
                          ? "border-primary bg-primary text-primary-foreground"
                          : "text-muted-foreground",
                      )}
                    >
                      <Ic className="size-3.5" />
                      {i.short}
                    </Link>
                  );
                })}
              </div>
            </nav>
          )}
        </header>

        {modoCliente && (
          <div className="mx-auto mt-3 flex w-full max-w-7xl flex-wrap items-center justify-between gap-2 rounded-md border border-amber-400 bg-amber-100 px-4 py-2 text-sm text-amber-900 dark:bg-amber-900/40 dark:text-amber-100 native:hidden">
            <span>Modo usuário comum ativo. Itens administrativos ficam ocultos.</span>
            <Button size="sm" variant="outline" onClick={() => definirModoCliente(false)}>
              Voltar à visão admin
            </Button>
          </div>
        )}
        <main className="mx-auto w-full max-w-7xl px-4 pb-28 pt-6 lg:px-8 lg:pb-10 native:pb-[calc(5.5rem+var(--app-inset-bottom,0px))]">
          {rotaAdminBloqueada ? (
            <div className="rounded-md border p-6 text-center text-sm text-muted-foreground">
              Esta área é exclusiva do administrador. Volte à visão admin para acessá-la.
            </div>
          ) : (
            <Fragment key={ocultarValores ? "valores-ocultos" : "valores-visiveis"}>{children}</Fragment>
          )}
          <AppEmBreve className="mt-10 native:hidden" />
          <SincronizadorAgendaApp />
        </main>
      </div>

      <Sheet open={open} onOpenChange={setOpen}>
        <SheetContent
          side="left"
          className="w-72 bg-sidebar p-0 native:overflow-y-auto native:pb-[var(--app-inset-bottom,0px)]"
        >
          <SheetTitle className="sr-only">Menu</SheetTitle>
          <div className="border-b p-3 lg:hidden">
            <Button
              className="w-full gap-2"
              disabled={!podeLancar}
              onClick={() => {
                setOpen(false);
                window.dispatchEvent(new Event("abrir-lancamento-rapido"));
              }}
            >
              <Plus className="size-4" /> Lançar despesa ou receita
            </Button>
          </div>
          <SidebarInner onNavigate={() => setOpen(false)} />
        </SheetContent>
      </Sheet>

      <nav
        aria-label="Navegação principal"
        className={cn(
          "barra-app fixed inset-x-2 bottom-[calc(env(safe-area-inset-bottom)+0.5rem)] z-30 grid h-16 grid-cols-6 items-end rounded-2xl border border-border bg-background px-1.5 shadow-lg lg:hidden",
          // No app iOS: barra colada embaixo, cobrindo a área do indicador de início.
          "native:inset-x-0 native:bottom-0 native:h-[calc(3.5rem+var(--app-inset-bottom,0px))] native:items-stretch native:rounded-none native:border-x-0 native:border-b-0 native:bg-background/90 native:px-1 native:pb-[var(--app-inset-bottom,0px)] native:shadow-none native:backdrop-blur-xl",
          // Com o botão + no centro, ele ganha coluna própria (não fica por cima dos vizinhos).
          acaoCentral && "native:grid-cols-7",
        )}
      >
        <Link
          to="/inicio"
          className={cn(
            "flex h-full flex-col items-center justify-end gap-0.5 pb-1.5 text-[10px] font-medium leading-none native:justify-center native:gap-1 native:pb-0 native:[&>svg]:size-6",
            pathname === "/inicio" ? "text-primary" : "text-muted-foreground",
          )}
        >
          <Home className="size-5" />
          Início
        </Link>
        <Link
          to="/calendario"
          className={cn(
            "flex h-full flex-col items-center justify-end gap-0.5 pb-1.5 text-[10px] font-medium leading-none native:justify-center native:gap-1 native:pb-0 native:[&>svg]:size-6",
            pathname === "/calendario" ? "text-primary" : "text-muted-foreground",
          )}
        >
          <CalendarDays className="size-5" />
          Calendário
        </Link>
        {(() => {
          const visiveis = ATALHOS_MOBILE.filter((m) => mundoVisivel(m.id));
          const renderAtalho = (m: (typeof ATALHOS_MOBILE)[number]) => {
            const Icon = m.icon;
            return (
              <Link
                key={m.id}
                to={MUNDOS[m.id].home}
                className={cn(
                  "flex h-full flex-col items-center justify-end gap-0.5 pb-1.5 text-[10px] font-medium leading-none native:justify-center native:gap-1 native:pb-0 native:[&>svg]:size-6",
                  mundoId === m.id ? "text-primary" : "text-muted-foreground",
                )}
              >
                <Icon className="size-5" />
                {m.rotulo}
              </Link>
            );
          };
          return (
            <Fragment>
              {visiveis.slice(0, 1).map(renderAtalho)}
              {acaoCentral && (
                <div className="hidden items-center justify-center native:flex">
                  <button
                    type="button"
                    aria-label={acaoCentral.rotulo}
                    onClick={() => window.dispatchEvent(new Event(acaoCentral.evento))}
                    className="flex size-12 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-md transition-transform active:scale-95"
                  >
                    <Plus className="size-6" />
                  </button>
                </div>
              )}
              {visiveis.slice(1).map(renderAtalho)}
            </Fragment>
          );
        })()}
        <button
          type="button"
          onClick={() => setOpen(true)}
          className="flex h-full flex-col items-center justify-end gap-0.5 pb-1.5 text-[10px] font-medium leading-none native:justify-center native:gap-1 native:pb-0 native:[&>svg]:size-6 text-muted-foreground"
        >
          <Menu className="size-5" />
          Menu
        </button>
        {acaoCentral && (
          <button
            type="button"
            aria-label={acaoCentral.rotulo}
            onClick={() => window.dispatchEvent(new Event(acaoCentral.evento))}
            className="absolute left-1/2 -top-8 flex size-14 -translate-x-1/2 flex-col items-center justify-center gap-0.5 rounded-full bg-primary text-primary-foreground shadow-lg ring-4 ring-background transition-transform active:scale-95 native:hidden"
          >
            <Plus className="size-6" />
            <span className="text-[10px] font-semibold leading-none">{acaoCentral.curto}</span>
          </button>
        )}
      </nav>

      {/* Lançamento rápido por texto/áudio (IA) — pedido explícito do usuário
          (2026-10-01): botão flutuante acessível de qualquer tela
          autenticada, não escondido dentro dos formulários de
          despesas/receitas. Ver claude/plano-lancamento-ia-2026-10-01.md. */}
      <BotaoLancamentoRapido flutuante={mundoId === "financas" || pathname === "/inicio"} />
    </div>
  );
}
