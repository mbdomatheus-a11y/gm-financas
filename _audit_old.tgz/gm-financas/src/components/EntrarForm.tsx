import { useEffect, useState } from "react";
import { urlRetornoSegura } from "@/lib/return-url";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Link, useNavigate } from "@tanstack/react-router";
import { Eye, EyeOff, Loader2 } from "lucide-react";
import { toast } from "sonner";

import { supabase } from "@/integrations/supabase/client";
import { cpfToEmail, isValidCpf, maskCpf, onlyDigits } from "@/lib/cpf";
import { registrarSucessoLogin } from "@/lib/login-protecao.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { obterConfiguracaoAcesso } from "@/lib/configuracoes-site.functions";
import { confirmarSegundoFator, iniciarLoginSeguro } from "@/lib/seguranca-conta.functions";
import { rotaDaTelaInicial } from "@/lib/tela-inicial-padrao";
import { SocialAuthButtons } from "@/components/SocialAuthButtons";

/**
 * Formulário de login por e-mail (contas novas) OU CPF (contas antigas,
 * compatibilidade) — extraído de `entrar.tsx` (item 6 do backlog de
 * 2026-09-26) pra ser reaproveitado tanto na página completa `/entrar`
 * quanto no popup de login da home (`EntrarDialog`), sem duplicar lógica.
 */
const IDENTIFICADOR_SALVO = "control-all-identificador";
const DOMINIOS_EMAIL = [
  "gmail.com",
  "hotmail.com",
  "outlook.com",
  "icloud.com",
  "yahoo.com.br",
  "uol.com.br",
];

export function EntrarForm({
  next,
  onSucesso,
  esqueciSenhaComoLink = true,
}: {
  next?: string;
  /** Chamado após a sessão ser aberta com sucesso, antes do redirecionamento. Útil pra fechar um dialog. */
  onSucesso?: () => void;
  /** Se falso, "Esqueci minha senha" não usa <Link> (útil dentro de um Dialog, onde a navegação já fecha o popup naturalmente — mantém <Link> por padrão). */
  esqueciSenhaComoLink?: boolean;
}) {
  const navigate = useNavigate();
  const [identificador, setIdentificador] = useState("");
  const [senha, setSenha] = useState("");
  const [mostrarSenha, setMostrarSenha] = useState(false);
  const [lembrarIdentificador, setLembrarIdentificador] = useState(false);
  const [loading, setLoading] = useState(false);
  const [desafio2fa, setDesafio2fa] = useState<{
    id: string;
    email: string;
    senhaTemporaria: boolean;
    minutos: number;
  } | null>(null);
  const [codigo2fa, setCodigo2fa] = useState("");
  const obterConfig = useServerFn(obterConfiguracaoAcesso);
  const loginSeguro = useServerFn(iniciarLoginSeguro);
  const confirmar2fa = useServerFn(confirmarSegundoFator);
  const { data: config } = useQuery({
    queryKey: ["configuracao-acesso-publica"],
    queryFn: () => obterConfig(),
    staleTime: 60_000,
  });
  const registrarSucesso = useServerFn(registrarSucessoLogin);

  useEffect(() => {
    try {
      const salvo = localStorage.getItem(IDENTIFICADOR_SALVO);
      if (salvo) {
        setIdentificador(salvo);
        setLembrarIdentificador(true);
      }
    } catch {
      // Navegação privada pode bloquear armazenamento local.
    }
  }, []);

  const modo = config?.modo_login ?? "ambos";
  const ehEmail = identificador.includes("@");

  // Sugestões de domínio em botões (o <datalist> do navegador não funciona ao tocar no iPhone).
  const sugestoesEmail = (() => {
    const texto = identificador.trim();
    if (!texto || !/[a-z]/i.test(texto)) return [];
    const [usuario, parcial = ""] = texto.split("@");
    if (!usuario) return [];
    if (!texto.includes("@")) return DOMINIOS_EMAIL.slice(0, 4).map((d) => `${usuario}@${d}`);
    if (DOMINIOS_EMAIL.includes(parcial)) return [];
    return DOMINIOS_EMAIL.filter((d) => d.startsWith(parcial.toLowerCase()))
      .slice(0, 4)
      .map((d) => `${usuario}@${d}`);
  })();
  const cpfDigitado = ehEmail ? "" : identificador;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (modo === "email" && !ehEmail) {
      toast.error("O acesso está configurado somente por e-mail.");
      return;
    }
    if (modo === "cpf" && ehEmail) {
      toast.error("O acesso está configurado somente por CPF.");
      return;
    }
    let email: string;
    if (ehEmail) {
      email = identificador.trim();
    } else {
      if (!isValidCpf(cpfDigitado)) {
        toast.error("CPF inválido");
        return;
      }
      email = cpfToEmail(cpfDigitado);
    }
    if (senha.length < 6) {
      toast.error("A senha deve ter ao menos 6 caracteres");
      return;
    }
    setLoading(true);
    let resultado;
    try {
      resultado = await loginSeguro({ data: { identificador: identificador.trim(), senha } });
    } catch (error) {
      setLoading(false);
      const mensagem = error instanceof Error ? error.message : "";
      toast.error(
        mensagem.includes("LOGIN_BLOQUEADO")
          ? "Três tentativas incorretas. O acesso foi bloqueado por 15 minutos."
          : mensagem.includes("LOGIN_MODO_CPF")
            ? "O acesso está configurado somente por CPF."
            : mensagem.includes("LOGIN_MODO_EMAIL")
              ? "O acesso está configurado somente por e-mail."
              : "Credenciais incorretas",
      );
      return;
    }
    if (resultado.exige2fa) {
      setLoading(false);
      setDesafio2fa({
        id: resultado.desafioId,
        email: resultado.emailMascarado,
        senhaTemporaria: resultado.senhaTemporaria,
        minutos: resultado.sessaoMaximaMinutos,
      });
      toast.success("Código de segurança enviado por e-mail.");
      return;
    }
    const { error } = await supabase.auth.setSession({
      access_token: resultado.accessToken,
      refresh_token: resultado.refreshToken,
    });
    setLoading(false);
    if (error) {
      toast.error("Não foi possível abrir a sessão.");
      return;
    }
    void registrarSucesso({ data: { identificador: email } });
    sessionStorage.setItem("control-all-sessao-iniciada", String(Date.now()));
    sessionStorage.setItem("control-all-sessao-max-min", String(resultado.sessaoMaximaMinutos));
    try {
      if (lembrarIdentificador) {
        localStorage.setItem(IDENTIFICADOR_SALVO, identificador.trim());
      } else {
        localStorage.removeItem(IDENTIFICADOR_SALVO);
      }
    } catch {
      // O acesso continua funcionando mesmo sem armazenamento local.
    }
    toast.success("Bem-vindo de volta!");
    onSucesso?.();
    if (resultado.senhaTemporaria) {
      navigate({ to: "/nova-senha" });
    } else {
      window.location.assign(urlRetornoSegura(next) ?? rotaDaTelaInicial(config?.tela_inicial_padrao));
    }
  }

  async function validar2fa(e: React.FormEvent) {
    e.preventDefault();
    if (!desafio2fa) return;
    setLoading(true);
    try {
      const { tokenHash } = await confirmar2fa({
        data: { desafioId: desafio2fa.id, codigo: codigo2fa },
      });
      const { error } = await supabase.auth.verifyOtp({ token_hash: tokenHash, type: "magiclink" });
      if (error) throw error;
      sessionStorage.setItem("control-all-sessao-iniciada", String(Date.now()));
      sessionStorage.setItem("control-all-sessao-max-min", String(desafio2fa.minutos));
      onSucesso?.();
      window.location.assign(
        desafio2fa.senhaTemporaria
          ? "/nova-senha"
          : (urlRetornoSegura(next) ?? rotaDaTelaInicial(config?.tela_inicial_padrao)),
      );
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Código inválido");
    } finally {
      setLoading(false);
    }
  }

  if (desafio2fa)
    return (
      <form onSubmit={validar2fa} className="space-y-4 rounded-2xl border bg-card p-6 shadow-card">
        <div>
          <h2 className="font-semibold">Confirmação em duas etapas</h2>
          <p className="mt-1 text-xs text-muted-foreground">
            Digite o código de 6 números enviado para {desafio2fa.email}.
          </p>
        </div>
        <Input
          inputMode="numeric"
          autoComplete="one-time-code"
          maxLength={6}
          value={codigo2fa}
          onChange={(e) => setCodigo2fa(onlyDigits(e.target.value).slice(0, 6))}
          placeholder="000000"
          className="h-12 text-center text-xl tracking-[.4em]"
        />
        <Button type="submit" className="w-full" disabled={codigo2fa.length !== 6 || loading}>
          {loading && <Loader2 className="mr-2 size-4 animate-spin" />}Validar e entrar
        </Button>
        <Button
          type="button"
          variant="ghost"
          className="w-full"
          onClick={() => {
            setDesafio2fa(null);
            setCodigo2fa("");
          }}
        >
          Voltar
        </Button>
      </form>
    );

  return (
    <form onSubmit={handleSubmit} className="space-y-4 rounded-2xl border bg-card p-6 shadow-card">
      <div className="space-y-2">
        <Label htmlFor="identificador">
          E-mail
        </Label>
        <Input
          id="identificador"
          name="username"
          autoComplete="username"
          autoCapitalize="none"
          autoCorrect="off"
          spellCheck={false}
          inputMode={modo === "cpf" ? "numeric" : "email"}
          placeholder={
            modo === "cpf"
              ? "000.000.000-00"
              : modo === "email"
                ? "voce@email.com"
                : "voce@email.com"
          }
          value={
            // Só aplica a máscara de CPF quando o que já foi digitado é
            // compatível com CPF (dígitos/pontuação) — caso contrário
            // (qualquer letra, típico de e-mail) mostra o valor cru, senão
            // a máscara apagaria cada letra digitada e pareceria que o
            // campo "não aceita letra".
            modo !== "email" && /^[\d.-]*$/.test(identificador)
              ? maskCpf(identificador)
              : identificador
          }
          onChange={(e) => setIdentificador(e.target.value)}
          className="h-11"
        />
        {sugestoesEmail.length > 0 && (
          <div className="flex gap-1.5 overflow-x-auto [scrollbar-width:none]" aria-label="Sugestões de e-mail">
            {sugestoesEmail.map((sugestao) => (
              <button
                key={sugestao}
                type="button"
                // Não tira o foco do campo antes do toque (senão a lista some antes do clique).
                onPointerDown={(e) => e.preventDefault()}
                onClick={() => {
                  setIdentificador(sugestao);
                  document.getElementById("senha")?.focus();
                }}
                className="shrink-0 rounded-full border bg-muted/50 px-3 py-1.5 text-xs font-medium text-muted-foreground transition-colors active:bg-muted"
              >
                @{sugestao.split("@")[1]}
              </button>
            ))}
          </div>
        )}
        {!ehEmail && onlyDigits(cpfDigitado).length === 11 && !isValidCpf(cpfDigitado) && (
          <p className="text-xs text-destructive">CPF inválido</p>
        )}
      </div>
      <div className="space-y-2">
        <Label htmlFor="senha">Senha</Label>
        <div className="relative">
          <Input
            id="senha"
            name="password"
            type={mostrarSenha ? "text" : "password"}
            autoComplete="current-password"
            autoCapitalize="none"
            autoCorrect="off"
            placeholder="••••••••"
            value={senha}
            onChange={(e) => setSenha(e.target.value)}
            className="h-11 pr-11"
          />
          <button
            type="button"
            onClick={() => setMostrarSenha((v) => !v)}
            aria-label={mostrarSenha ? "Ocultar senha" : "Mostrar senha"}
            className="absolute inset-y-0 right-0 flex w-11 items-center justify-center text-muted-foreground"
          >
            {mostrarSenha ? <EyeOff className="size-4.5" /> : <Eye className="size-4.5" />}
          </button>
        </div>
      </div>
      <label className="flex items-center gap-2 text-xs text-muted-foreground">
        <Checkbox
          checked={lembrarIdentificador}
          onCheckedChange={(checked) => {
            const lembrar = checked === true;
            setLembrarIdentificador(lembrar);
            if (!lembrar) {
              try {
                localStorage.removeItem(IDENTIFICADOR_SALVO);
              } catch {
                /* indisponível */
              }
            }
          }}
        />
        Lembrar e-mail neste
        dispositivo. A senha nunca é salva pelo site.
      </label>
      <Button type="submit" className="h-11 w-full" disabled={loading}>
        {loading && <Loader2 className="mr-2 size-4 animate-spin" />}
        Entrar
      </Button>

      <SocialAuthButtons next={next} labelPrefix="Entrar com" />

      {esqueciSenhaComoLink ? (
        <Link
          to="/esqueci-senha"
          className="block w-full text-center text-xs text-muted-foreground underline-offset-4 hover:underline"
        >
          Esqueci minha senha
        </Link>
      ) : null}

    </form>
  );
}
