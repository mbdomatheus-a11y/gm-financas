import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { createHash, randomInt, timingSafeEqual } from "node:crypto";
import { getRequest } from "@tanstack/react-start/server";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { isValidCpf, onlyDigits } from "@/lib/cpf";

const hash = (valor: string) => createHash("sha256").update(valor).digest("hex");
const hashIdentificador = (valor: string) => hash(valor.trim().toLowerCase());
const urlBase = () => process.env["SITE_URL"] || "https://www.controlall.com.br";

type MotivoFalhaLogin =
  | "usuario_nao_cadastrado"
  | "senha_incorreta"
  | "conta_bloqueada"
  | "conta_inativa"
  | "cpf_invalido"
  | "modo_login_nao_permitido"
  | "outro";

/**
 * Registra QUALQUER tentativa de login com erro (mesmo a primeira) em
 * `login_falhas_log`: o que a pessoa digitou (nunca a senha), o motivo, o IP e
 * a localização aproximada (cabeçalhos da Vercel, sem serviço externo).
 * Nunca derruba o login: erro de gravação é ignorado.
 */
async function registrarFalhaLoginDetalhada(
  db: any,
  p: {
    identificador: string;
    motivo: MotivoFalhaLogin;
    userId?: string | null;
    tentativas?: number | null;
    bloqueou?: boolean;
  },
) {
  try {
    const h = getRequest().headers;
    const ip =
      h.get("x-forwarded-for")?.split(",")[0]?.trim() || h.get("x-real-ip") || null;
    const decodificar = (v: string | null) => {
      if (!v) return null;
      try {
        return decodeURIComponent(v);
      } catch {
        return v;
      }
    };
    const ident = p.identificador.trim().slice(0, 160);
    await db.from("login_falhas_log").insert({
      identificador: ident,
      tipo_identificador: ident.includes("@") ? "email" : /\d/.test(ident) ? "cpf" : "desconhecido",
      motivo: p.motivo,
      ip,
      cidade: decodificar(h.get("x-vercel-ip-city")),
      regiao: decodificar(h.get("x-vercel-ip-country-region")),
      pais: h.get("x-vercel-ip-country"),
      user_agent: h.get("user-agent")?.slice(0, 300) ?? null,
      user_id: p.userId ?? null,
      tentativas: p.tentativas ?? null,
      bloqueou: !!p.bloqueou,
    });
  } catch {
    // Não crítico: o log nunca pode impedir a resposta do login.
  }
}

export const iniciarLoginSeguro = createServerFn({ method: "POST" })
  .inputValidator((v: unknown) =>
    z
      .object({
        identificador: z.string().trim().min(3).max(160),
        senha: z.string().min(6).max(72),
      })
      .parse(v),
  )
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const db = supabaseAdmin as any;
    const identificadorHash = hashIdentificador(data.identificador);
    const { data: tentativaAtual, error: tentativaErro } = await db
      .from("login_tentativas")
      .select("bloqueado_ate")
      .eq("identificador_hash", identificadorHash)
      .maybeSingle();
    if (tentativaErro) throw new Error("Não foi possível verificar a segurança do acesso.");
    if (
      tentativaAtual?.bloqueado_ate &&
      new Date(tentativaAtual.bloqueado_ate).getTime() > Date.now()
    ) {
      await registrarFalhaLoginDetalhada(db, {
        identificador: data.identificador,
        motivo: "conta_bloqueada",
        bloqueou: true,
      });
      throw new Error("LOGIN_BLOQUEADO");
    }
    const { data: config } = await db
      .from("configuracoes_acesso_site")
      .select("modo_login,segundo_fator_email,sessao_maxima_minutos")
      .eq("id", true)
      .single();
    const porEmail = data.identificador.includes("@");
    if (
      (config.modo_login === "cpf" && porEmail) ||
      (config.modo_login === "email" && !porEmail)
    ) {
      await registrarFalhaLoginDetalhada(db, {
        identificador: data.identificador,
        motivo: "modo_login_nao_permitido",
      });
      throw new Error(config.modo_login === "cpf" ? "LOGIN_MODO_CPF" : "LOGIN_MODO_EMAIL");
    }
    let email = data.identificador.toLowerCase();
    if (!porEmail) {
      const cpf = onlyDigits(data.identificador);
      if (!isValidCpf(cpf)) {
        await registrarFalhaLoginDetalhada(db, {
          identificador: data.identificador,
          motivo: "cpf_invalido",
        });
        throw new Error("CPF inválido.");
      }
      const { data: perfil } = await db
        .from("profiles")
        .select("email")
        .eq("cpf", cpf)
        .eq("ativo", true)
        .maybeSingle();
      if (!perfil?.email) {
        await registrarFalhaLoginDetalhada(db, {
          identificador: data.identificador,
          motivo: "usuario_nao_cadastrado",
        });
        throw new Error("Credenciais incorretas.");
      }
      email = perfil.email.toLowerCase();
    }
    const { createClient } = await import("@supabase/supabase-js");
    const url = process.env["SUPABASE_URL"] || process.env["VITE_SUPABASE_URL"];
    const chave =
      process.env["SUPABASE_PUBLISHABLE_KEY"] || process.env["VITE_SUPABASE_PUBLISHABLE_KEY"];
    if (!url || !chave) throw new Error("Configuração de autenticação indisponível.");
    const cliente = createClient(url, chave, {
      auth: { persistSession: false, autoRefreshToken: false },
    });
    const { data: auth, error } = await cliente.auth.signInWithPassword({
      email,
      password: data.senha,
    });
    if (error || !auth.user || !auth.session) {
      const { data: tentativa } = await db.rpc("registrar_tentativa_login", {
        p_hash: identificadorHash,
        p_sucesso: false,
      });
      const retorno = Array.isArray(tentativa) ? tentativa[0] : tentativa;
      // Distingue "usuário não cadastrado" de "senha incorreta" só no LOG
      // (a mensagem mostrada à pessoa continua genérica, sem revelar contas).
      // Existe se há perfil por CPF (já achado acima), perfil por e-mail OU conta no Auth
      // (cobre contas cujo perfil está sem e-mail).
      let existente: { id: string } | null = null;
      if (!porEmail) {
        const { data: porCpf } = await db
          .from("profiles")
          .select("id")
          .eq("cpf", onlyDigits(data.identificador))
          .limit(1)
          .maybeSingle();
        existente = porCpf ?? null;
      }
      if (!existente) {
        const emailBusca = email.replace(/[\\%_]/g, (c) => `\\${c}`);
        const { data: porPerfil } = await db
          .from("profiles")
          .select("id")
          .ilike("email", emailBusca)
          .limit(1)
          .maybeSingle();
        existente = porPerfil ?? null;
      }
      if (!existente) {
        const { data: idAuth } = await db.rpc("usuario_auth_por_email", { p_email: email });
        if (idAuth) existente = { id: String(idAuth) };
      }
      await registrarFalhaLoginDetalhada(db, {
        identificador: data.identificador,
        motivo: existente ? "senha_incorreta" : "usuario_nao_cadastrado",
        userId: existente?.id ?? null,
        tentativas: retorno?.tentativas ?? null,
        bloqueou: !!retorno?.bloqueado_ate,
      });
      // Registrar tentativa de login com falha no audit log
      try {
        await db.from("admin_audit_logs").insert({
          ator_id: null,
          acao: "login_falhou",
          alvo_id: null,
          detalhes: {
            identificador_hash: identificadorHash.slice(0, 16) + "…",
            tentativas: retorno?.tentativas ?? null,
            bloqueado: !!retorno?.bloqueado_ate,
          },
        });
      } catch { /* não crítico */ }
      if (retorno?.bloqueado_ate) throw new Error("LOGIN_BLOQUEADO");
      throw new Error("Credenciais incorretas.");
    }
    const { data: perfil } = await db
      .from("profiles")
      .select("ativo,senha_temporaria")
      .eq("id", auth.user.id)
      .maybeSingle();
    if (!perfil?.ativo) {
      await registrarFalhaLoginDetalhada(db, {
        identificador: data.identificador,
        motivo: "conta_inativa",
        userId: auth.user.id,
      });
      throw new Error("Usuário inativo. Fale com um administrador.");
    }
    await db.rpc("registrar_tentativa_login", {
      p_hash: identificadorHash,
      p_sucesso: true,
    });
    if (!config.segundo_fator_email)
      return {
        exige2fa: false as const,
        accessToken: auth.session.access_token,
        refreshToken: auth.session.refresh_token,
        senhaTemporaria: !!perfil.senha_temporaria,
        sessaoMaximaMinutos: config.sessao_maxima_minutos as number,
      };
    const codigo = String(randomInt(100000, 1000000));
    const { data: desafio, error: desafioErro } = await db
      .from("login_2fa_desafios")
      .insert({ user_id: auth.user.id, codigo_hash: hash(codigo) })
      .select("id")
      .single();
    if (desafioErro) throw new Error("Não foi possível iniciar o segundo fator.");
    const { enviarEmail } = await import("@/lib/email.server");
    const enviado = await enviarEmail({
      to: email,
      subject: "Código de acesso do Control ALL",
      html: `<p>Seu código de acesso é:</p><p style="font-size:28px;letter-spacing:6px"><strong>${codigo}</strong></p><p>Ele vale por 10 minutos e pode ser usado uma única vez.</p>`,
    });
    if (!enviado.ok) {
      await db.from("login_2fa_desafios").delete().eq("id", desafio.id);
      throw new Error("Não foi possível enviar o código de segurança.");
    }
    return {
      exige2fa: true as const,
      desafioId: desafio.id as string,
      emailMascarado: email.replace(/^(.{2}).*(@.*)$/, "$1••••$2"),
      senhaTemporaria: !!perfil.senha_temporaria,
      sessaoMaximaMinutos: config.sessao_maxima_minutos as number,
    };
  });

async function enviarAlertaSenha(userId: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const db = supabaseAdmin as any;
  const { data: auth } = await supabaseAdmin.auth.admin.getUserById(userId);
  if (!auth.user?.email || auth.user.email.endsWith("@financascasal.app")) return;
  const seg = await import("@/lib/seguranca-email.server");
  const linkBloqueio = await seg.criarLinkBloqueio(db, userId);
  const { enviarEmail } = await import("@/lib/email.server");
  await enviarEmail({
    to: auth.user.email,
    subject: "Sua senha do Control ALL foi alterada",
    html: seg.layoutEmailSeguranca(
      "Sua senha foi alterada",
      `<p>A senha da sua conta foi alterada. Dados da alteração:</p>
${seg.blocoDoPedido(seg.contextoDaRequisicao())}
<p>Se foi você, nenhuma ação é necessária.</p>
<p>Se você <strong>não reconhece</strong> esta alteração, bloqueie a conta agora. O bloqueio encerra todos os acessos e abre um chamado no suporte; só o suporte desbloqueia, depois de confirmar sua identidade.</p>
${seg.botaoEmail(linkBloqueio, "Não fui eu, bloquear minha conta", "#DB2B33")}
<p style="color:#6b7280;font-size:12px">O link vale 24 horas e pede uma segunda confirmação. Você também pode escrever para <a href="mailto:privacidade@controlall.com.br">privacidade@controlall.com.br</a> ou abrir a <a href="${urlBase()}/suporte">Central de Suporte</a>.</p>`,
    ),
  });
}

export const alterarMinhaSenha = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((v: unknown) =>
    z
      .object({
        senhaAtual: z.string().min(1, "Informe sua senha atual"),
        senha: z.string().min(8, "A nova senha deve ter no mínimo 8 caracteres").max(72),
      })
      .parse(v),
  )
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: authUser, error: getUserError } = await supabaseAdmin.auth.admin.getUserById(context.userId);
    if (getUserError || !authUser?.user?.email) {
      throw new Error("Usuário não encontrado.");
    }

    // Validar a senha atual autenticando com ela
    const { createClient } = await import("@supabase/supabase-js");
    const url = process.env["SUPABASE_URL"] || process.env["VITE_SUPABASE_URL"];
    const chave =
      process.env["SUPABASE_PUBLISHABLE_KEY"] || process.env["VITE_SUPABASE_PUBLISHABLE_KEY"];
    if (!url || !chave) throw new Error("Configuração de autenticação indisponível.");
    const cliente = createClient(url, chave, {
      auth: { persistSession: false, autoRefreshToken: false },
    });
    const { error: erroSenhaAtual } = await cliente.auth.signInWithPassword({
      email: authUser.user.email,
      password: data.senhaAtual,
    });
    if (erroSenhaAtual) {
      throw new Error("A senha atual informada está incorreta.");
    }

    const { error } = await supabaseAdmin.auth.admin.updateUserById(context.userId, {
      password: data.senha,
    });
    if (error) throw new Error("Não foi possível alterar a senha.");
    await (supabaseAdmin as any)
      .from("profiles")
      .update({ senha_temporaria: false })
      .eq("id", context.userId);
    await enviarAlertaSenha(context.userId);
    return { ok: true as const };
  });

export const atualizarMeusDados = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((v: unknown) =>
    z
      .object({
        nome: z.string().trim().min(2).max(120),
        email: z.string().trim().email("E-mail inválido"),
        telefone: z.string().trim().max(20).optional().nullable(),
        dataNascimento: z.string().max(10).optional().nullable(),
        cpf: z.string().trim().optional().nullable(),
        horasTrabalhoMes: z.number().int().min(1).max(720).optional().nullable(),
      })
      .parse(v),
  )
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const db = supabaseAdmin as any;

    const { data: anterior } = await db
      .from("profiles")
      .select("nome, email, telefone, data_nascimento, cpf, horas_trabalho_mes")
      .eq("id", context.userId)
      .single();

    // Atualiza auth se o email mudou
    if (data.email.toLowerCase() !== anterior?.email?.toLowerCase()) {
      const { error: authErr } = await supabaseAdmin.auth.admin.updateUserById(context.userId, {
        email: data.email,
        email_confirm: true,
      });
      if (authErr) throw new Error(authErr.message || "Erro ao atualizar e-mail.");
    }

    // Tratamento e validação de CPF
    let cpfFinal: string | null = null;
    if (data.cpf !== undefined) {
      if (data.cpf && data.cpf.trim() !== "") {
        const digitos = onlyDigits(data.cpf);
        if (digitos.length > 0) {
          if (!isValidCpf(digitos)) {
            throw new Error("CPF inválido. Verifique os números digitados.");
          }
          const { data: existente } = await db
            .from("profiles")
            .select("id")
            .eq("cpf", digitos)
            .neq("id", context.userId)
            .maybeSingle();
          if (existente) {
            throw new Error("Este CPF já está cadastrado em outra conta.");
          }
          cpfFinal = digitos;
        }
      }
    } else {
      cpfFinal = anterior?.cpf ?? null;
    }

    const { error: perfErr } = await db
      .from("profiles")
      .update({
        nome: data.nome,
        email: data.email,
        telefone: data.telefone || null,
        data_nascimento: data.dataNascimento || null,
        ...(data.cpf !== undefined ? { cpf: cpfFinal } : {}),
        ...(data.horasTrabalhoMes !== undefined
          ? { horas_trabalho_mes: data.horasTrabalhoMes || 160 }
          : {}),
      })
      .eq("id", context.userId);
    if (perfErr) throw new Error(perfErr.message);

    await db.from("admin_audit_logs").insert({
      ator_id: context.userId,
      acao: "perfil_usuario_atualizado",
      alvo_id: context.userId,
      detalhes: {
        anterior,
        novo: data,
      },
    });

    return { ok: true as const };
  });

export const garantirPerfilUsuarioOAuth = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const db = supabaseAdmin as any;

    const { data: perfilExistente } = await db
      .from("profiles")
      .select("id, grupo_id")
      .eq("id", context.userId)
      .maybeSingle();

    // O gatilho handle_new_user já cria um perfil "casca" (sem grupo) para todo
    // usuário novo; só consideramos pronto quem já tem grupo. Antes, esta checagem
    // só olhava a existência da linha e o reparo nunca rodava no login social.
    if (perfilExistente?.grupo_id) {
      return { ok: true as const, jaExistia: true };
    }

    const { data: authUser, error: authErr } =
      await supabaseAdmin.auth.admin.getUserById(context.userId);
    if (authErr || !authUser?.user) {
      throw new Error("Usuário autenticado não encontrado.");
    }

    const email = authUser.user.email ?? "";
    const meta = (authUser.user.user_metadata ?? {}) as Record<string, any>;
    const nome = (meta["full_name"] || meta["name"] || email.split("@")[0] || "Usuário") as string;

    // Cria grupo isolado para o novo usuário OAuth
    const { data: grupoNovo, error: grupoErr } = await db
      .from("grupos")
      .insert({ nome: `Grupo de ${nome}`, criado_por: context.userId, oracle_storage_cota_bytes: 536870912 })
      .select("id")
      .single();
    if (grupoErr) throw new Error(grupoErr.message);

    // Cria perfil vinculado
    const { error: perfilErr } = await db.from("profiles").upsert(
      {
        id: context.userId,
        nome,
        email,
        grupo_id: grupoNovo.id,
        ativo: true,
        cpf: null,
        horas_trabalho_mes: 160,
        senha_temporaria: false,
      },
      { onConflict: "id" },
    );
    if (perfilErr) throw new Error(perfilErr.message);

    // Concede permissão de administrador ao seu grupo
    await db.from("user_roles").upsert(
      { user_id: context.userId, role: "admin" },
      { onConflict: "user_id,role" },
    );

    // Registra aceite dos termos legais
    await db.from("aceites_documentos").upsert(
      [
        { user_id: context.userId, documento: "termos_uso", versao: "2026-09-19" },
        { user_id: context.userId, documento: "aviso_privacidade", versao: "2026-09-19" },
      ],
      { onConflict: "user_id,documento,versao" },
    );

    return { ok: true as const, jaExistia: false };
  });

export async function notificarSenhaAlterada(userId: string) {
  await enviarAlertaSenha(userId);
}

export const solicitarSegundoFator = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const db = supabaseAdmin as any;
    const { data: config } = await db
      .from("configuracoes_acesso_site")
      .select("segundo_fator_email")
      .eq("id", true)
      .single();
    if (!config?.segundo_fator_email) return { exigido: false as const };
    const { data: auth } = await supabaseAdmin.auth.admin.getUserById(context.userId);
    if (!auth.user?.email || auth.user.email.endsWith("@financascasal.app"))
      throw new Error("Esta conta não possui e-mail real para receber o código de segurança.");
    const codigo = String(randomInt(100000, 1000000));
    const { data: desafio, error } = await db
      .from("login_2fa_desafios")
      .insert({ user_id: context.userId, codigo_hash: hash(codigo) })
      .select("id")
      .single();
    if (error) throw new Error("Não foi possível iniciar a verificação.");
    const { enviarEmail } = await import("@/lib/email.server");
    const enviado = await enviarEmail({
      to: auth.user.email,
      subject: "Código de acesso do Control ALL",
      html: `<p>Seu código de acesso é:</p><p style="font-size:28px;letter-spacing:6px"><strong>${codigo}</strong></p><p>Ele vale por 10 minutos e pode ser usado uma única vez.</p>`,
    });
    if (!enviado.ok) {
      await db.from("login_2fa_desafios").delete().eq("id", desafio.id);
      throw new Error("Não foi possível enviar o código de segurança.");
    }
    return {
      exigido: true as const,
      desafioId: desafio.id as string,
      emailMascarado: auth.user.email.replace(/^(.{2}).*(@.*)$/, "$1••••$2"),
    };
  });

export const confirmarSegundoFator = createServerFn({ method: "POST" })
  .inputValidator((v: unknown) =>
    z.object({ desafioId: z.string().uuid(), codigo: z.string().regex(/^\d{6}$/) }).parse(v),
  )
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const db = supabaseAdmin as any;
    const { data: desafio } = await db
      .from("login_2fa_desafios")
      .select("id,user_id,codigo_hash,tentativas,expira_em,usado_em")
      .eq("id", data.desafioId)
      .maybeSingle();
    if (
      !desafio ||
      desafio.usado_em ||
      desafio.tentativas >= 5 ||
      new Date(desafio.expira_em).getTime() < Date.now()
    )
      throw new Error("Código inválido ou expirado.");
    const recebido = Buffer.from(hash(data.codigo), "hex"),
      esperado = Buffer.from(desafio.codigo_hash, "hex");
    if (recebido.length !== esperado.length || !timingSafeEqual(recebido, esperado)) {
      await db
        .from("login_2fa_desafios")
        .update({ tentativas: desafio.tentativas + 1 })
        .eq("id", desafio.id);
      throw new Error("Código inválido ou expirado.");
    }
    const { data: auth } = await supabaseAdmin.auth.admin.getUserById(desafio.user_id);
    if (!auth.user?.email) throw new Error("Conta indisponível.");
    const { data: link, error } = await supabaseAdmin.auth.admin.generateLink({
      type: "magiclink",
      email: auth.user.email,
    });
    if (error || !link.properties.hashed_token)
      throw new Error("Não foi possível concluir o acesso.");
    await db
      .from("login_2fa_desafios")
      .update({ usado_em: new Date().toISOString() })
      .eq("id", desafio.id);
    return { tokenHash: link.properties.hashed_token };
  });

export const bloquearContaPorToken = createServerFn({ method: "POST" })
  .inputValidator((v: unknown) => z.object({ token: z.string().min(40) }).parse(v))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const db = supabaseAdmin as any;
    const { data: registro } = await db
      .from("bloqueio_conta_tokens")
      .select("id,user_id,expira_em,usado_em")
      .eq("token_hash", hash(data.token))
      .maybeSingle();
    if (!registro || registro.usado_em || new Date(registro.expira_em).getTime() < Date.now())
      throw new Error("Este link é inválido ou expirou.");
    const { data: siteAdmin } = await db
      .from("site_admins")
      .select("user_id")
      .eq("user_id", registro.user_id)
      .maybeSingle();
    if (siteAdmin)
      throw new Error("A conta administrativa exige atendimento manual pelo canal de privacidade.");
    // Reserva o link de forma atômica: dois cliques ao mesmo tempo não geram dois chamados.
    const { data: reservado } = await db
      .from("bloqueio_conta_tokens")
      .update({ usado_em: new Date().toISOString() })
      .eq("id", registro.id)
      .is("usado_em", null)
      .select("id");
    if (!reservado?.length) throw new Error("Este link já foi usado.");
    // Bloqueio: impede novos acessos (ban), marca a conta inativa e cancela links de senha pendentes.
    const { error: erroBan } = await supabaseAdmin.auth.admin.updateUserById(registro.user_id, { ban_duration: "876000h" });
    if (erroBan) {
      // Devolve o link para a pessoa tentar de novo.
      await db.from("bloqueio_conta_tokens").update({ usado_em: null }).eq("id", registro.id);
      throw new Error("Não foi possível bloquear agora. Tente de novo em instantes ou escreva para privacidade@controlall.com.br.");
    }
    await db.from("profiles").update({ ativo: false }).eq("id", registro.user_id);
    await db
      .from("bloqueio_conta_tokens")
      .update({ usado_em: new Date().toISOString() })
      .eq("user_id", registro.user_id)
      .is("usado_em", null);
    await db.from("password_reset_tokens").update({ usado: true }).eq("user_id", registro.user_id).eq("usado", false);
    const seg = await import("@/lib/seguranca-email.server");
    const pedido = seg.contextoDaRequisicao();
    const { data: perfil } = await db.from("profiles").select("nome,email,grupo_id").eq("id", registro.user_id).maybeSingle();
    const { data: auth } = await supabaseAdmin.auth.admin.getUserById(registro.user_id);
    const email = (auth?.user?.email ?? perfil?.email ?? "") as string;
    // Chamado automático para o suporte desbloquear depois de confirmar a identidade.
    const { data: chamado } = await db
      .from("chamados_suporte")
      .insert({
        user_id: registro.user_id,
        grupo_id: perfil?.grupo_id ?? null,
        email,
        nome: perfil?.nome ?? null,
        assunto: "Conta bloqueada a pedido do titular",
        descricao: `Bloqueio pedido pelo link "Não fui eu" do e-mail de segurança. Confirmar a identidade antes de desbloquear (Usuários > reativar). Pedido feito de: ${pedido.aparelho}, ${pedido.dataHora}, ${pedido.local}.`,
        prioridade: "reclamacao",
      })
      .select("protocolo")
      .maybeSingle();
    await db.from("admin_audit_logs").insert({
      ator_id: null,
      acao: "conta_bloqueada_pelo_titular",
      alvo_id: registro.user_id,
      detalhes: { aparelho: pedido.aparelho, local: pedido.local, protocolo: chamado?.protocolo ?? null },
    });
    if (email && !email.endsWith("@financascasal.app")) {
      const { enviarEmail } = await import("@/lib/email.server");
      await enviarEmail({
        to: email,
        subject: "Sua conta do Control ALL foi bloqueada",
        html: seg.layoutEmailSeguranca(
          "Conta bloqueada",
          `<p>Sua conta foi bloqueada a seu pedido. Ninguém consegue fazer um novo acesso, nem com a senha, e os links de troca de senha foram cancelados. Um acesso que já estava aberto em outro aparelho pode continuar por até 1 hora, até a sessão expirar.</p>
${seg.blocoDoPedido(pedido)}
<p>Abrimos um chamado no suporte${chamado?.protocolo ? ` (protocolo <strong>${chamado.protocolo}</strong>)` : ""}. Para desbloquear, o suporte vai confirmar sua identidade. Responda este e-mail ou escreva para <a href="mailto:privacidade@controlall.com.br">privacidade@controlall.com.br</a>.</p>`,
        ),
      });
    }
    return { ok: true as const, protocolo: (chamado?.protocolo as string | undefined) ?? null };
  });

/**
 * Troca da senha provisória (2026-10-24): quem entrou com senha provisória não sabe a "senha atual",
 * então não usa alterarMinhaSenha. Só funciona enquanto profiles.senha_temporaria for verdadeiro.
 */
export const definirSenhaProvisoria = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((v: unknown) =>
    z.object({ senha: z.string().min(8, "A nova senha deve ter no mínimo 8 caracteres").max(72) }).parse(v),
  )
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const db = supabaseAdmin as any;
    const { data: perfil } = await db.from("profiles").select("senha_temporaria").eq("id", context.userId).maybeSingle();
    if (!perfil?.senha_temporaria) throw new Error("Sua senha não é provisória. Troque a senha em Minha conta.");
    const { error } = await supabaseAdmin.auth.admin.updateUserById(context.userId, { password: data.senha });
    if (error) throw new Error("Não foi possível definir a senha.");
    await db.from("profiles").update({ senha_temporaria: false }).eq("id", context.userId);
    await enviarAlertaSenha(context.userId);
    return { ok: true as const };
  });
