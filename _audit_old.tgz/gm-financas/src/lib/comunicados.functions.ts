import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
export const meusComunicados = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const db = supabaseAdmin as any;
    const { data, error } = await db
      .from("comunicados")
      .select("id,titulo,mensagem,exige_aceite")
      .eq("ativo", true)
      .gt("expira_em", new Date().toISOString())
      .order("criado_em", { ascending: false });
    if (error) throw new Error(error.message);
    const { data: aceitos } = await db
      .from("comunicado_aceites")
      .select("comunicado_id")
      .eq("user_id", context.userId);
    const ids = new Set((aceitos ?? []).map((x: any) => x.comunicado_id));
    return (data ?? []).filter((x: any) => !ids.has(x.id));
  });
export const aceitarComunicado = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((v: unknown) => z.object({ id: z.string().uuid() }).parse(v))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const db = supabaseAdmin as any;
    const { data: comunicado, error: buscarErro } = await db
      .from("comunicados")
      .select("titulo,mensagem")
      .eq("id", data.id)
      .single();
    if (buscarErro) throw new Error(buscarErro.message);
    const { error } = await db
      .from("comunicado_aceites")
      .upsert({ comunicado_id: data.id, user_id: context.userId });
    if (error) throw new Error(error.message);
    const { data: jaRegistrado } = await db
      .from("historico_alertas_usuario")
      .select("id")
      .eq("user_id", context.userId)
      .eq("referencia_tipo", "comunicado")
      .eq("referencia_id", data.id)
      .maybeSingle();
    if (!jaRegistrado)
      await db.from("historico_alertas_usuario").insert({
        user_id: context.userId,
        tipo: "comunicado",
        titulo: comunicado.titulo,
        mensagem: comunicado.mensagem,
        referencia_tipo: "comunicado",
        referencia_id: data.id,
        lido_em: new Date().toISOString(),
      });
    await db.from("admin_audit_logs").insert({
      ator_id: context.userId,
      acao: "comunicado_aceito",
      alvo_id: data.id,
      detalhes: {},
    });
    return { ok: true as const };
  });

export const meuHistoricoAlertas = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const db = supabaseAdmin as any;
    // Histórico de avisos guarda só 7 dias: apaga o que passou disso (melhor esforço).
    const corte = new Date(Date.now() - 7 * 86_400_000).toISOString();
    await db.from("historico_alertas_usuario").delete().eq("user_id", context.userId).lt("exibido_em", corte);
    const { data, error } = await db
      .from("historico_alertas_usuario")
      .select("id,tipo,titulo,mensagem,exibido_em,lido_em")
      .eq("user_id", context.userId)
      .gte("exibido_em", corte)
      .order("exibido_em", { ascending: false })
      .limit(50);
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const minhasChavesAlertasLidos = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await (supabaseAdmin as any)
      .from("alertas_lidos")
      .select("chave")
      .eq("user_id", context.userId);
    if (error) throw new Error(error.message);
    return (data ?? []).map((x: any) => x.chave as string);
  });
export const marcarAlertaLido = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((v: unknown) =>
    z
      .object({
        chave: z.string().min(3).max(300),
        titulo: z.string().max(180),
        mensagem: z.string().max(1000),
      })
      .parse(v),
  )
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const db = supabaseAdmin as any;
    await db
      .from("alertas_lidos")
      .upsert({ user_id: context.userId, chave: data.chave, lido_em: new Date().toISOString() });
    await db.from("historico_alertas_usuario").insert({
      user_id: context.userId,
      tipo: "alerta",
      titulo: data.titulo,
      mensagem: data.mensagem,
      lido_em: new Date().toISOString(),
      referencia_tipo: "alerta",
      referencia_id: null,
    });
    return { ok: true as const };
  });

/** Marca vários alertas como vistos de uma vez (ao abrir o sino): somem da lista de novos e entram no histórico de 7 dias. */
export const marcarAlertasLidosLote = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((v: unknown) =>
    z
      .object({
        itens: z
          .array(
            z.object({
              chave: z.string().min(3).max(300),
              titulo: z.string().max(180),
              mensagem: z.string().max(1000),
            }),
          )
          .max(60),
      })
      .parse(v),
  )
  .handler(async ({ data, context }) => {
    if (data.itens.length === 0) return { ok: true as const };
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const db = supabaseAdmin as any;
    const agora = new Date().toISOString();
    await db.from("alertas_lidos").upsert(
      data.itens.map((i) => ({ user_id: context.userId, chave: i.chave, lido_em: agora })),
    );
    await db.from("historico_alertas_usuario").insert(
      data.itens.map((i) => ({
        user_id: context.userId,
        tipo: "alerta",
        titulo: i.titulo,
        mensagem: i.mensagem,
        lido_em: agora,
        referencia_tipo: "alerta",
        referencia_id: null,
      })),
    );
    return { ok: true as const };
  });

export const sincronizarVersaoSite = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((v: unknown) =>
    z.object({ versao: z.string().min(3).max(80), buildEm: z.string().datetime() }).parse(v),
  )
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await (supabaseAdmin as any)
      .from("versoes_site")
      .upsert({ versao: data.versao, build_em: data.buildEm });
    if (error) throw new Error(error.message);
    return { ok: true as const };
  });

export const versoesAtivasSite = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    // Avisos de "nova versão publicada" são do admin master do site; usuários
    // comuns (e admins de grupo) nunca recebem esse alerta.
    const { data: siteAdmin } = await (supabaseAdmin as any)
      .from("site_admins")
      .select("user_id")
      .eq("user_id", context.userId)
      .maybeSingle();
    if (!siteAdmin) return [];
    const { data, error } = await (supabaseAdmin as any)
      .from("versoes_site")
      .select("versao,build_em,criado_em")
      .eq("ativo", true)
      .order("criado_em", { ascending: false })
      .limit(30);
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const limparVersoesSite = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const db = supabaseAdmin as any;
    // Versões do site são globais: só o admin MASTER do site (site_admins) pode limpar.
    const { data: siteAdmin } = await db
      .from("site_admins")
      .select("user_id")
      .eq("user_id", context.userId)
      .maybeSingle();
    if (!siteAdmin) throw new Error("Apenas o administrador do site pode limpar o histórico de versões.");
    const { error } = await db
      .from("versoes_site")
      .update({ ativo: false, limpo_em: new Date().toISOString(), limpo_por: context.userId })
      .eq("ativo", true);
    if (error) throw new Error(error.message);
    return { ok: true as const };
  });
