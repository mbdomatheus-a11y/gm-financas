import { monthKey } from "@/lib/format";

export type Periodicidade = "mensal" | "semestral" | "anual";

/** Horizonte padrão (em meses) para materializar ocorrências de uma recorrência sem prazo. */
export const HORIZONTE_SEM_PRAZO = 36;

export const PERIODICIDADES: { value: Periodicidade; label: string; meses: number }[] = [
  { value: "mensal", label: "Mensal", meses: 1 },
  { value: "semestral", label: "Semestral", meses: 6 },
  { value: "anual", label: "Anual", meses: 12 },
];

export function mesesDaPeriodicidade(p: Periodicidade): number {
  return p === "mensal" ? 1 : p === "semestral" ? 6 : 12;
}

/** "percentual": reajuste composto (%); "fixo": incremento fixo em R$ a cada aplicação. */
export type ModoReajuste = "percentual" | "fixo";

export interface ReajusteConfig {
  /** Padrão "percentual" quando ausente, para compatibilidade com dados existentes. */
  modo?: ModoReajuste;
  percentual: number;
  /** Usado somente quando modo === "fixo": incremento em R$ aplicado a cada período. */
  valorFixo?: number;
  periodicidade: Periodicidade;
  /** Competência (ou data) do primeiro reajuste. Sem valor, usa o mês seguinte ao início. */
  inicio?: string | null;
  indice?: string | null;
}

/** Verifica se a configuração de reajuste realmente produz algum efeito. */
function reajusteAtivo(cfg: ReajusteConfig | null | undefined): boolean {
  if (!cfg) return false;
  if (cfg.modo === "fixo") return Number.isFinite(cfg.valorFixo) && cfg.valorFixo !== 0;
  return Number.isFinite(cfg.percentual) && cfg.percentual !== 0;
}

export interface RecorrenciaFixa {
  /** Valor mensal inicial, na competência de início. */
  valor: number;
  /** Data (ou competência) em que a recorrência começa. */
  inicio: string;
  semPrazo: boolean;
  /** Quantidade de competências quando há prazo determinado. */
  meses?: number | null;
  reajuste?: ReajusteConfig | null;
}

/** Normaliza uma data ISO ou competência "AAAA-MM" para a chave de competência. */
export function competenciaDe(value: string | Date): string {
  if (typeof value === "string" && /^\d{4}-\d{2}$/.test(value)) return value;
  return monthKey(value);
}

/** Diferença em meses entre duas competências (b - a). */
export function mesesEntreCompetencias(a: string, b: string): number {
  const [ay, am] = competenciaDe(a).split("-").map(Number);
  const [by, bm] = competenciaDe(b).split("-").map(Number);
  return (by! - ay!) * 12 + (bm! - am!);
}

export function somarMeses(competencia: string, n: number): string {
  const [y, m] = competenciaDe(competencia).split("-").map(Number);
  const total = y! * 12 + (m! - 1) + n;
  const ano = Math.floor(total / 12);
  const mes = total % 12;
  return `${ano}-${String(mes + 1).padStart(2, "0")}`;
}

/** Arredonda para centavos evitando erro de ponto flutuante. */
function paraCentavos(valor: number): number {
  return Math.round((valor + Number.EPSILON) * 100);
}

/** Quantas vezes o reajuste já foi aplicado até a competência informada. */
export function aplicacoesDeReajuste(r: RecorrenciaFixa, competencia: string): number {
  const cfg = r.reajuste;
  if (!cfg || !reajusteAtivo(cfg)) return 0;
  const inicioReajuste = cfg.inicio
    ? competenciaDe(cfg.inicio)
    : somarMeses(competenciaDe(r.inicio), mesesDaPeriodicidade(cfg.periodicidade));
  const diff = mesesEntreCompetencias(inicioReajuste, competenciaDe(competencia));
  if (diff < 0) return 0;
  return Math.floor(diff / mesesDaPeriodicidade(cfg.periodicidade)) + 1;
}

/** Índice da competência dentro da recorrência (0 = primeira); -1 quando fora. */
export function ordemDaCompetencia(r: RecorrenciaFixa, competencia: string): number {
  const diff = mesesEntreCompetencias(r.inicio, competencia);
  if (diff < 0) return -1;
  if (!r.semPrazo && r.meses && diff >= r.meses) return -1;
  return diff;
}

export function ativaNaCompetencia(r: RecorrenciaFixa, competencia: string): boolean {
  return ordemDaCompetencia(r, competencia) >= 0;
}

/**
 * Valor vigente da recorrência na competência informada, com reajuste composto
 * sempre aplicado sobre o último valor reajustado. Retorna null fora do período.
 */
export function valorNaCompetencia(r: RecorrenciaFixa, competencia: string): number | null {
  if (!ativaNaCompetencia(r, competencia)) return null;
  let cents = paraCentavos(r.valor);
  const n = aplicacoesDeReajuste(r, competencia);
  if (r.reajuste?.modo === "fixo") {
    cents += paraCentavos(r.reajuste.valorFixo ?? 0) * n;
  } else {
    const fator = 1 + (r.reajuste?.percentual ?? 0) / 100;
    for (let i = 0; i < n; i++) cents = Math.round(cents * fator);
  }
  return cents / 100;
}

export interface CompetenciaProjetada {
  competencia: string;
  valor: number;
  ordem: number;
  /** Total de competências quando há prazo determinado. */
  total: number | null;
}

/** Projeta as competências da recorrência dentro de um intervalo (inclusive). */
export function projetarCompetencias(
  r: RecorrenciaFixa,
  de: string,
  ate: string,
): CompetenciaProjetada[] {
  const inicio = competenciaDe(r.inicio);
  const primeira = mesesEntreCompetencias(de, inicio) > 0 ? inicio : competenciaDe(de);
  const ultimaPorPrazo = !r.semPrazo && r.meses ? somarMeses(inicio, r.meses - 1) : null;
  const limite =
    ultimaPorPrazo && mesesEntreCompetencias(ultimaPorPrazo, competenciaDe(ate)) > 0
      ? ultimaPorPrazo
      : competenciaDe(ate);
  const qtd = mesesEntreCompetencias(primeira, limite);
  const out: CompetenciaProjetada[] = [];
  for (let i = 0; i <= qtd; i++) {
    const competencia = somarMeses(primeira, i);
    const valor = valorNaCompetencia(r, competencia);
    if (valor == null) continue;
    out.push({
      competencia,
      valor,
      ordem: ordemDaCompetencia(r, competencia),
      total: r.semPrazo ? null : (r.meses ?? null),
    });
  }
  return out;
}

/** Lê a recorrência a partir de uma linha de `despesas`. */
export function recorrenciaDaDespesa(d: any): RecorrenciaFixa | null {
  if ((d?.tipo ?? "") !== "fixa") return null;
  // 2026-10-10: economia conquistada marca um gasto que deixou de existir.
  // Ela continua visível para o histórico, mas não se repete todo mês: vale
  // só na competência em que foi conquistada.
  if (d?.economia_conquistada) return null;
  const valor = Number(d.valor_total) || 0;
  const inicio = d.recorrencia_inicio ?? d.data_primeira_parcela ?? d.data_compra;
  if (!inicio) return null;
  const semPrazo = d.recorrencia_sem_prazo !== false && !d.recorrencia_meses;
  const percentual = Number(d.reajuste_percentual);
  return {
    valor,
    inicio,
    semPrazo,
    meses: d.recorrencia_meses ?? null,
    reajuste:
      Number.isFinite(percentual) && percentual !== 0 && d.reajuste_periodicidade
        ? {
            percentual,
            periodicidade: d.reajuste_periodicidade as Periodicidade,
            inicio: d.reajuste_inicio ?? null,
            indice: d.reajuste_indice ?? null,
          }
        : null,
  };
}

/** Lê a recorrência a partir de uma linha de `receitas` (mensal recorrente, sem prazo). */
export function recorrenciaDaReceita(r: any): RecorrenciaFixa | null {
  const valor = Number(r.valor) || 0;
  const inicio = r.recorrencia_inicio ?? r.data_recebimento;
  if (!inicio) return null;
  const semPrazo = r.recorrencia_sem_prazo !== false && !r.recorrencia_meses;
  const modo: ModoReajuste = r.reajuste_modo === "fixo" ? "fixo" : "percentual";
  const percentual = Number(r.reajuste_percentual);
  const valorFixo = Number(r.reajuste_valor_fixo);
  const ativo =
    !!r.reajuste_periodicidade &&
    (modo === "fixo"
      ? Number.isFinite(valorFixo) && valorFixo !== 0
      : Number.isFinite(percentual) && percentual !== 0);
  return {
    valor,
    inicio,
    semPrazo,
    meses: r.recorrencia_meses ?? null,
    reajuste: ativo
      ? {
          modo,
          percentual: modo === "percentual" ? percentual : 0,
          valorFixo: modo === "fixo" ? valorFixo : 0,
          periodicidade: r.reajuste_periodicidade as Periodicidade,
          inicio: r.reajuste_inicio ?? null,
          indice: r.reajuste_indice ?? null,
        }
      : null,
  };
}

export interface LancamentoCompetencia {
  id: string;
  despesa_id: string;
  numero: number;
  total: number;
  valor: number;
  moeda: string;
  vencimento: string;
  paga: boolean;
  data_pagamento: string | null;
  competencia: string;
  projetada: boolean;
  despesa: any;
}

export function vencimentoDaCompetencia(inicio: string, competencia: string): string {
  const dia = Math.min(28, Number(inicio.slice(8, 10)) || 1);
  return `${competencia}-${String(dia).padStart(2, "0")}`;
}

/**
 * Monta uma única ocorrência por despesa e competência. Recorrências novas são
 * calculadas pela regra; parcelas persistidas servem apenas para recuperar o pagamento.
 * Despesas variáveis e fixas legadas continuam usando suas parcelas existentes.
 */
export function lancamentosPorCompetencias(
  despesas: any[],
  competencias: string[],
): LancamentoCompetencia[] {
  const desejadas = new Set(competencias.map(competenciaDe));
  const out: LancamentoCompetencia[] = [];

  for (const despesa of despesas) {
    const parcelas = (despesa.parcelas ?? []) as any[];
    const recorrencia = despesa.recorrencia_inicio ? recorrenciaDaDespesa(despesa) : null;

    if (!recorrencia) {
      for (const parcela of parcelas) {
        const competencia = competenciaDe(parcela.vencimento);
        if (!desejadas.has(competencia)) continue;
        out.push({
          ...parcela,
          id: String(parcela.id),
          despesa_id: String(parcela.despesa_id ?? despesa.id),
          valor: Number(parcela.valor),
          moeda: parcela.moeda ?? despesa.moeda,
          paga: Boolean(parcela.paga),
          data_pagamento: parcela.data_pagamento ?? null,
          competencia,
          projetada: false,
          despesa,
        });
      }
      continue;
    }

    const existentes = new Map(
      parcelas.map((parcela) => [competenciaDe(parcela.vencimento), parcela] as const),
    );
    for (const competencia of desejadas) {
      const valor = valorNaCompetencia(recorrencia, competencia);
      if (valor == null) continue;
      const existente = existentes.get(competencia);
      const ordem = ordemDaCompetencia(recorrencia, competencia);
      out.push({
        id: existente?.id ?? `rec:${despesa.id}:${competencia}`,
        despesa_id: String(despesa.id),
        numero: ordem + 1,
        total: recorrencia.semPrazo ? 0 : (recorrencia.meses ?? 0),
        valor: existente?.origem === "importacao_substituicao"
          ? Number(existente.valor)
          : valor,
        moeda: despesa.moeda,
        vencimento:
          existente?.vencimento ?? vencimentoDaCompetencia(recorrencia.inicio, competencia),
        paga: Boolean(existente?.paga),
        data_pagamento: existente?.data_pagamento ?? null,
        competencia,
        projetada: !existente,
        despesa,
      });
    }
  }

  return out;
}

export interface ReceitaCompetencia {
  id: string;
  receita_id: string;
  descricao: string;
  valor: number;
  moeda: string;
  categoria: string;
  responsavel: string;
  data_recebimento: string;
  competencia: string;
  recorrente: boolean;
  tipo: "fixa" | "variavel";
  frequencia?: string | null;
  observacoes?: string | null;
  cartao_id?: string | null;
  projetada: boolean;
  receitaOriginal: any;
  possivel_duplicidade?: boolean;
}

/**
 * Projeta receitas para as competências solicitadas.
 * Receitas pontuais/variáveis aparecem em sua respectiva data de recebimento.
 * Receitas fixas (recorrentes sem prazo ou com prazo) projetam para qualquer mês
 * futuro ou presente selecionado (ex: 2026, 2029, 2030), aplicando reajustes se configurados.
 */
/**
 * Open Finance prevalece (2026-10-24): se o banco já trouxe uma entrada no mês com o mesmo valor
 * de uma receita fixa prevista (e o nome do responsável ou da receita aparece no extrato, ou a data
 * é próxima), a previsão daquele mês sai da conta para não somar em dobro.
 * Ex.: "Guilherme - Dia 30" R$ 2.874 previsto e "PIX RECEBIDO GUILHERME" R$ 2.874 do banco.
 * Cada entrada do banco substitui no máximo uma previsão.
 */
function normalizarTexto(t: string): string {
  return String(t ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toUpperCase();
}

function suprimirFixasRecebidasPeloBanco(lista: ReceitaCompetencia[]): ReceitaCompetencia[] {
  const doBanco = lista.filter((r) => !r.projetada && (r.receitaOriginal as any)?.origem === "pluggy");
  if (!doBanco.length) return lista;
  const remover = new Set<string>();
  type Par = { proj: string; banco: string; nota: number };
  const pares: Par[] = [];
  for (const b of doBanco) {
    const texto = normalizarTexto(`${b.descricao ?? ""} ${(b.receitaOriginal as any)?.observacoes ?? ""}`);
    for (const p of lista) {
      // Prevista: projeção de receita fixa ou a própria ocorrência recorrente lançada à mão.
      const prevista = p.projetada || (!!(p.receitaOriginal as any)?.recorrente && (p.receitaOriginal as any)?.origem !== "pluggy");
      if (!prevista || p.id === b.id || p.competencia !== b.competencia) continue;
      if (((p as any).moeda ?? "BRL") !== ((b as any).moeda ?? "BRL")) continue;
      if (Math.abs(Number(p.valor) - Number(b.valor)) > 0.01) continue;
      const nomes = [p.responsavel, ...(String(p.descricao ?? "").split(/[^A-Za-zÀ-ÿ]+/))]
        .map((n) => normalizarTexto(n).trim())
        .filter((n) => n.length >= 4);
      const temNome = nomes.some((n) => texto.includes(n));
      const d1 = new Date(`${String(p.data_recebimento).slice(0, 10)}T12:00:00`).getTime();
      const d2 = new Date(`${String(b.data_recebimento).slice(0, 10)}T12:00:00`).getTime();
      const dias = Number.isFinite(d1) && Number.isFinite(d2) ? Math.abs(d1 - d2) / 86400000 : 99;
      if (!temNome && dias > 5) continue;
      pares.push({ proj: p.id, banco: b.id, nota: (temNome ? 100 : 0) - dias });
    }
  }
  pares.sort((a, b) => b.nota - a.nota);
  const usados = new Set<string>();
  for (const par of pares) {
    if (remover.has(par.proj) || usados.has(par.banco)) continue;
    remover.add(par.proj);
    usados.add(par.banco);
  }
  return remover.size ? lista.filter((r) => !remover.has(r.id)) : lista;
}

export function receitasPorCompetencias(
  receitas: any[],
  competencias: string[],
): ReceitaCompetencia[] {
  const desejadas = Array.from(new Set(competencias.map(competenciaDe))).sort();
  const out: ReceitaCompetencia[] = [];

  // Mapeia receitas recorrentes e seu início mais antigo para projetar nos meses futuros onde não há registro no banco
  // Agrupamos por chave única: descricao + responsavel + frequencia
  const recorrentes = new Map<string, any>();
  const inicios = new Map<string, string>();

  for (const r of receitas) {
    if (r.recorrente) {
      const chave = `${(r.descricao ?? "").toLowerCase().trim()}::${(r.responsavel ?? "").toLowerCase().trim()}::${r.frequencia ?? "mensal"}`;
      const dataInicio = r.recorrencia_inicio ?? r.data_recebimento;
      const inicioAtual = inicios.get(chave);
      if (!inicioAtual || dataInicio < inicioAtual) {
        inicios.set(chave, dataInicio);
      }

      const anterior = recorrentes.get(chave);
      // Mantemos o registro mais recente para parâmetros de valor e reajuste
      if (
        !anterior ||
        (r.recorrencia_inicio && !anterior.recorrencia_inicio) ||
        r.data_recebimento > anterior.data_recebimento
      ) {
        recorrentes.set(chave, r);
      }
    }
  }

  for (const competencia of desejadas) {
    // 1. Lançamentos que realmente existem no banco nesta competência
    const noBancoDesteMes = receitas.filter(
      (r) => competenciaDe(r.data_recebimento) === competencia,
    );

    const chavesNoMes = new Set<string>();

    for (const r of noBancoDesteMes) {
      const ehFixa = Boolean(r.recorrente);
      const chave = `${(r.descricao ?? "").toLowerCase().trim()}::${(r.responsavel ?? "").toLowerCase().trim()}::${r.frequencia ?? "mensal"}`;
      if (ehFixa) {
        chavesNoMes.add(chave);
      }
      out.push({
        id: String(r.id),
        receita_id: String(r.id),
        descricao: r.descricao,
        valor: Number(r.valor),
        moeda: r.moeda ?? "BRL",
        categoria: r.categoria ?? "Outros",
        responsavel: r.responsavel ?? "",
        data_recebimento: r.data_recebimento,
        competencia,
        recorrente: ehFixa,
        tipo: ehFixa ? "fixa" : "variavel",
        frequencia: r.frequencia ?? (ehFixa ? "mensal" : null),
        observacoes: r.observacoes ?? null,
        cartao_id: r.cartao_id ?? null,
        projetada: false,
        possivel_duplicidade: !!r.possivel_duplicidade,
        receitaOriginal: r,
      });
    }

    // 2. Projeta receitas fixas para competências onde AINDA NÃO EXISTE lançamento gravado no banco
    for (const [chave, rec] of recorrentes.entries()) {
      if (chavesNoMes.has(chave)) {
        // Já tem registro no banco para este mês, não projeta duplicata!
        continue;
      }
      const dataInicio = inicios.get(chave) ?? rec.recorrencia_inicio ?? rec.data_recebimento;
      // Não projeta em meses anteriores à data de início da receita
      if (mesesEntreCompetencias(competenciaDe(dataInicio), competencia) < 0) {
        continue;
      }

      const recorrencia = recorrenciaDaReceita({ ...rec, recorrencia_inicio: dataInicio });
      if (!recorrencia) continue;

      const valor = valorNaCompetencia(recorrencia, competencia);
      if (valor == null) continue;

      const dataRecebimento = vencimentoDaCompetencia(recorrencia.inicio, competencia);
      out.push({
        id: `rec_proj:${rec.id}:${competencia}`,
        receita_id: String(rec.id),
        descricao: rec.descricao,
        valor,
        moeda: rec.moeda ?? "BRL",
        categoria: rec.categoria ?? "Outros",
        responsavel: rec.responsavel ?? "",
        data_recebimento: dataRecebimento,
        competencia,
        recorrente: true,
        tipo: "fixa",
        frequencia: rec.frequencia ?? "mensal",
        observacoes: rec.observacoes ?? null,
        cartao_id: rec.cartao_id ?? null,
        projetada: true,
        receitaOriginal: rec,
      });
    }
  }

  return suprimirFixasRecebidasPeloBanco(out);
}

