import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import crypto from "node:crypto";
import { CPF_EMAIL_DOMAIN } from "@/lib/cpf";
import { aplicarLimite, aplicarLimitePorIp } from "@/lib/rate-limit.server";

/** Quanto tempo o link de redefinição vale, depois disso precisa pedir outro. */
const EXPIRACAO_MINUTOS = 10;

function gerarToken(): string {
  return crypto.randomBytes(32).toString("hex");
}

function hashToken(token: string): string {
  return crypto.createHash("sha256").update(token).digest("hex");
}

/** URL base do site pra montar o link do e-mail. Configure SITE_URL na Vercel
 * quando trocar de domínio — sem isso cai no domínio oficial atual (mesmo
 * fallback usado em convites.functions.ts/seguranca-conta.functions.ts;
 * antes este arquivo sozinho apontava pro domínio antigo da Vercel). */
function urlBase(): string {
  return process.env["SITE_URL"] || "https://www.controlall.com.br";
}

/**
 * Pede o link de redefinição de senha por e-mail — endpoint PÚBLICO (o
 * usuário ainda não está logado, por definição).
 *
 * Sempre retorna `{ ok: true }`, exista ou não o e-mail, pra não revelar se
 * uma conta existe (evita enumeração). Contas antigas criadas por CPF usam
 * um e-mail sintético (`@financascasal.app`, ver src/lib/cpf.ts) que ninguém
 * lê de verdade — pra essas, não tem o que enviar, mesma resposta genérica.
 *
 * Item 15 do backlog (revisão de segurança, 2026-09-26): limitado por IP
 * (evita flood geral) e por e-mail (evita "email bombing" — mandar
 * centenas de e-mails de redefinição pro mesmo destinatário-vítima).
 */
export const solicitarRecuperacaoSenha = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => z.object({ email: z.string().trim().email() }).parse(d))
  .handler(async ({ data }) => {
    const email = data.email.trim().toLowerCase();

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const db = supabaseAdmin as any;
    await aplicarLimitePorIp(db, "solicitar-recuperacao-senha", 20, 60);
    await aplicarLimite(db, {
      rota: "solicitar-recuperacao-senha-email",
      chave: email,
      maxPorJanela: 5,
      janelaMinutos: 60,
    });

    if (email.endsWith(`@${CPF_EMAIL_DOMAIN}`)) {
      return { ok: true as const };
    }

    // Busca pelo perfil (listUsers() devolve só a primeira página de 50 usuários).
    const { data: perfil } = await db
      .from("profiles")
      .select("id,email")
      .ilike("email", email)
      .maybeSingle();
    let usuario: { id: string; email?: string | undefined } | null = perfil
      ? { id: perfil.id as string, email: (perfil.email as string | null) ?? email }
      : null;
    if (!usuario) {
      const { data: lista } = await supabaseAdmin.auth.admin.listUsers({ page: 1, perPage: 1000 });
      const achado = lista?.users.find((u) => u.email?.toLowerCase() === email);
      if (achado) usuario = { id: achado.id, email: achado.email };
    }
    if (!usuario) return { ok: true as const };

    // Um novo pedido invalida os links anteriores ainda não usados.
    await supabaseAdmin
      .from("password_reset_tokens")
      .update({ usado: true })
      .eq("user_id", usuario.id)
      .eq("usado", false);
    const token = gerarToken();
    const { error: insertError } = await supabaseAdmin.from("password_reset_tokens").insert({
      user_id: usuario.id,
      token_hash: hashToken(token),
      expira_em: new Date(Date.now() + EXPIRACAO_MINUTOS * 60_000).toISOString(),
    });
    if (insertError) throw new Error(insertError.message);

    const link = `${urlBase()}/redefinir-senha?token=${token}`;
    const { enviarEmail } = await import("@/lib/email.server");
    const seg = await import("@/lib/seguranca-email.server");
    // Dados de quem pediu (aparelho, data, local) e o link "Não fui eu" para bloquear a conta.
    const pedido = seg.contextoDaRequisicao();
    const linkBloqueio = await seg.criarLinkBloqueio(db, usuario.id);
    const envio = await enviarEmail({
      to: usuario.email ?? email,
      subject: "Redefinição de senha do Control ALL",
      html: seg.layoutEmailSeguranca(
        "Pedido de redefinição de senha",
        `<p>Recebemos um pedido para redefinir a senha da sua conta. Confira de onde ele veio:</p>
${seg.blocoDoPedido(pedido)}
<p><strong>Foi você?</strong> Crie a nova senha pelo botão abaixo. O link vale ${EXPIRACAO_MINUTOS} minutos e pode ser usado uma vez.</p>
${seg.botaoEmail(link, "Criar nova senha")}
<p><strong>Não foi você?</strong> Sua senha continua a mesma. Se achar que alguém está tentando entrar na sua conta, bloqueie agora. O bloqueio encerra todos os acessos, cancela este link e abre um chamado no suporte; só o suporte desbloqueia, depois de confirmar sua identidade.</p>
${seg.botaoEmail(linkBloqueio, "Não fui eu, bloquear minha conta", "#DB2B33")}
<p style="color:#6b7280;font-size:12px">O link de bloqueio vale 24 horas e pede uma segunda confirmação antes de bloquear.</p>`,
      ),
    });

    // A resposta ao usuário continua genérica (não revela se a conta existe), mas a
    // falha de envio fica registrada para o administrador enxergar.
    if (!envio.ok) {
      console.error("[recuperar-senha] e-mail não enviado:", envio.erro);
      await db.from("admin_audit_logs").insert({
        ator_id: usuario.id,
        acao: "email_recuperacao_senha_falhou",
        detalhes: { erro: envio.erro },
      });
    }

    return { ok: true as const };
  });

/**
 * Confirma a redefinição usando o token recebido por e-mail — endpoint
 * PÚBLICO. Token é validado por hash (nunca fica em texto puro no banco),
 * checa expiração e uso único.
 */
export const redefinirSenhaComToken = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) =>
    z
      .object({
        token: z.string().min(20),
        novaSenha: z.string().min(8).max(72),
      })
      .parse(d),
  )
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const tokenHash = hashToken(data.token);

    const { data: registro, error } = await supabaseAdmin
      .from("password_reset_tokens")
      .select("id, user_id, expira_em, usado")
      .eq("token_hash", tokenHash)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!registro || registro.usado) {
      throw new Error("Este link é inválido ou já foi usado. Peça um novo.");
    }
    if (new Date(registro.expira_em).getTime() < Date.now()) {
      throw new Error("Este link expirou (vale por 10 minutos). Peça um novo.");
    }

    const { error: updError } = await supabaseAdmin.auth.admin.updateUserById(registro.user_id, {
      password: data.novaSenha,
    });
    if (updError) throw new Error(updError.message);

    await supabaseAdmin.from("password_reset_tokens").update({ usado: true }).eq("id", registro.id);
    await supabaseAdmin
      .from("profiles")
      .update({ senha_temporaria: false })
      .eq("id", registro.user_id);

    const { notificarSenhaAlterada } = await import("@/lib/seguranca-conta.functions");
    await notificarSenhaAlterada(registro.user_id);

    return { ok: true as const };
  });
